#from numpy import matrix
#from numpy import matlib
#from numpy import math
class arquivo1:
	def __init__(self):
		self.posicao0='Pedro'
		self.regressor0=45
		#print('Construtor chamado com sucesso')
        #manipulador=open('regressores.txt','r')
        #manipulador2=open('referencia.txt','r')
        # retorna_regressor(self,posicao):
		#for linha in range(1,posicao+1):
        #for linha in manipulador:
        #    linha.rstrip()
		#	print(linha)
        #    #print(linha.rstrip())
		#manipulador.close()
        #return 0
        # retorna_referencia(self,narq):
        #
		#for linha in range(1,posicao+1):
        #for linha in manipulador2:
        #    linha.rstrip()
    	# 	print(linha)
        #    #print(linha.rstrip())
		#manipulador.close()        
    def entra_matriz(self):
        a=int(raw_input("Enter the no. of rows:"))
        b=int(raw_input("Enter the no. of columns:"))
        c=[[input("Enter the element:")for j in range(a)]for i in range(b)]
        for i in range(a):
            for j in range(b):
                print c[i][j],
            print
        return 0