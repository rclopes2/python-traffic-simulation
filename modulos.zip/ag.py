from numpy import matrix
from numpy import matlib
from numpy import math
#import random
from modulos.modulos0 import arquivo
#from math import random
#from modulos.modulos0 import arquivo
#from modulos1 import arquivo2
import numpy as np
import matplotlib.pyplot as plt
from pylab import *       
import statistics
import random as rnd
#from mpl_toolkits.basemap import Basemap
aa1=arquivo()
#from matplotlib import pyplot
#from numpy import arange
font = {'family': 'serif',
        'color':  'darkred',
        'weight': 'normal',
        'size': 16,
        }
#aa1=arquivo()
#aa2b=arquivo2()
class genetico:
    def __init__(self):
        self.posicao0='Pedro'
        self.regressor0=45
        #print('Construtor chamado com sucesso')
        #def zeros(self,n_linhas, n_colunas):
        #madj=matrix([[0,0,0],[0,0,0],[0,0,0]])        #print(matriz(5,4))    
        #for linha in range(1,2):
        #    for coluna in range(1,2):
        #madj[[linha][coluna]]=1
        #madj[[1],[1]]=1
        #matriz = [] # Matriz
        #linha = [] # Linha

        #while len(matriz) != n_linhas: # Quando o número de elementos da matriz(linhas) forem diferentes da quantidade máxima definida pelo usuário, ele ficará rodando.
        #    n = 0 # Utilizei random para adicionar os valores
        #    linha.append(n) # Adiciono n à linha

        #    if len(linha) == n_colunas: # Se a quantidade de elementos for igual à quantidade de colunas definida pelo usuário :
        #        matriz.append(linha) # Adiciono a linha à matriz
        #        linha = [] # E zero a "linha" para adicionar outra à matriz
        #return madj # Retorno a mesma
    def individuo(self,max,dec):
        #import random as rnd
        #function [ind]=individuo(max,dec)
        #ind=round(rand*max*10^dec)/10^dec;
        #ind=aproxima(ind);
        ind=rnd.randint(0,10**dec)*max/10**dec
        #ind=matrix([[rnd.randint(0,10**dec)*max/10**dec]])
        return ind
        #return 0
        #function [pop]=populacao(nind,ncd)
        #%function [pop]=populacao(nind)
        #%ncd=>número de casas decimais
        #pop=[];
        #for(c=1:nind)
        #pop=[pop;individuo(1,ncd)];
        #end;
    def populacao(self,nind,ncd):
        #pop=self.individuo(10,7)
        pop=matrix([[self.individuo(.1,7),self.individuo(.1,7),self.individuo(.1,7)]])
        for nlinha in range(1,nind):
            #pop=aa1.insere_matrix_down(pop,self.individuo(10,7))
            pop=aa1.insere_matrix_down(pop,matrix([[self.individuo(.1,7),self.individuo(.1,7),self.individuo(.1,7)]]))
        return pop
    def populacao2(self,nind,ncd,ncrom):
        #pop=self.individuo(10,7)
        pop=matlib.zeros((nind,ncrom))
        argumento='self.individuo(.1,7)'
        argumentoac='self.individuo(.1,7)'
        for ccrom in range(0,ncrom-1):
            argumentoac=argumentoac+','+argumento
        #pop=matrix([[self.individuo(.1,7),self.individuo(.1,7),self.individuo(.1,7)]])
        exec('pop=matrix([['+argumentoac+']])')
        for nlinha in range(1,nind):
            #pop=aa1.insere_matrix_down(pop,self.individuo(10,7))
            #pop=aa1.insere_matrix_down(pop,matrix([[self.individuo(.1,7),self.individuo(.1,7),self.individuo(.1,7)]]))
            exec('pop=aa1.insere_matrix_down(pop,matrix([['+argumentoac+']]))')
        return pop
    
    def testevalidadeltaMPC(self,cncross):
        mDx0=matlib.zeros((14,1));
        mDy0=matlib.zeros((14,1));
        mDx1=matlib.zeros((14,1));
        mDy1=matlib.zeros((14,1));
        mDx0[0,0]=2
        mDy0[0,0]=1
        mDx0[1,0]=1
        mDy0[1,0]=2
        mDx0[2,0]=-1
        mDy0[2,0]=2
        mDx0[3,0]=-2
        mDy0[3,0]=1
        mDx0[4,0]=-2
        mDy0[4,0]=-1
        mDx0[5,0]=-1
        mDy0[5,0]=-2
        mDx0[6,0]=1
        mDy0[6,0]=-2
        mDx0[7,0]=2
        mDy0[7,0]=-1
        mDx1[0,0]=math.cos(math.atan2(1,1))
        mDy1[0,0]=math.sin(math.atan2(1,1))
        mDx1[1,0]=math.cos(math.atan2(-1,-1))
        mDy1[1,0]=math.sin(math.atan2(-1,-1))
        mDx1[2,0]=math.cos(math.atan2(1,-1))
        mDy1[2,0]=math.sin(math.atan2(1,-1))
        mDx1[3,0]=math.cos(math.atan2(-1,1))
        mDy1[3,0]=math.sin(math.atan2(-1,1))
        mDx1[4,0]=math.cos(math.atan2(-1,-1))
        mDy1[4,0]=math.sin(math.atan2(-1,-1))
        mDx1[5,0]=math.cos(math.atan2(1,1))
        mDy1[5,0]=math.sin(math.atan2(1,1))
        mDx1[6,0]=math.cos(math.atan2(-1,1))
        mDy1[6,0]=math.sin(math.atan2(-1,1))
        mDx1[7,0]=math.cos(math.atan2(1,-1))
        mDy1[7,0]=math.sin(math.atan2(1,-1))
        retorno=self.validadeltaMPC(cncross,mDx0,mDy0,mDx1,mDy1,200,math.pi/2)
        return retorno    
    
    
    def validadeltaMPC(self,cncross,mDx0,mDy0,mDx1,mDy1,toleranciaT,toleranciaA):
        normaS=0
        lm=len(mDx0)
        for clm in range(0,lm):
            norma=math.sqrt(mDx0[clm,0]**2+mDy0[clm,0]**2)
            distancia=math.sqrt((mDx0[clm,0]-mDx0[cncross,0])**2+(mDy0[clm,0]-mDy0[cncross,0])**2)
            #toleranciaT=200#metros
            if distancia<math.sqrt(toleranciaT**2+toleranciaT**2) and clm!=cncross:
                direcao1=math.atan2(mDy1[clm,0],mDx1[clm,0])
                direcao2=math.atan2(mDy1[cncross,0],mDx1[cncross,0])
                #toleranciaA=math.pi/2
                if direcao2>direcao1-toleranciaA and direcao2<direcao1+toleranciaA:
                    #direcao3=math.atan2(mDy1[cncross,0]-mDy1[clm,0],mDx1[cncross,0]-mDx1[clm,0])
                    direcao3=math.atan2(mDy0[cncross,0]-mDy0[clm,0],mDx0[cncross,0]-mDx0[clm,0])
                    if direcao3>direcao1-toleranciaA and direcao3<direcao1+toleranciaA and distancia>0 and norma>0:# and direcao3>0 and distancia>0:
                    #if direcao3>direcao2-toleranciaA and direcao3<direcao2+toleranciaA and distancia>0 and norma>0:# and direcao3>0 and distancia>0:
                        print('mDx0='+str(mDx0[clm,0])+', mDy0='+str(mDy0[clm,0])+', clm='+str(clm))
                        normaS=normaS+math.sqrt(mDx1[clm,0]**2+mDy1[clm,0]**2)
        return normaS
    
    

    def testevalidadeltaMPC2(self):
        retorno=0
        mDx0=matlib.zeros((14,1));
        mDy0=matlib.zeros((14,1));
        mD0=matlib.zeros((14,1));
        mDx1=matlib.zeros((14,1));
        mDy1=matlib.zeros((14,1));
        mD1=matlib.zeros((14,1));
        mDx0[0,0]=2
        mDy0[0,0]=1
        mD0[0,0]=math.pi/4
        mDx0[1,0]=1
        mDy0[1,0]=2
        mD0[1,0]=-3*math.pi/4
        mDx0[2,0]=-1
        mDy0[2,0]=2
        mD0[2,0]=-math.pi/4
        mDx0[3,0]=-2
        mDy0[3,0]=1
        mD0[3,0]=3*math.pi/4
        mDx0[4,0]=-2
        mDy0[4,0]=-1
        mD0[4,0]=-3*math.pi/4
        mDx0[5,0]=-1
        mDy0[5,0]=-2
        mD0[5,0]=math.pi/4
        mDx0[6,0]=1
        mDy0[6,0]=-2
        mD0[6,0]=3*math.pi/4
        mDx0[7,0]=2
        mDy0[7,0]=-1
        mD0[7,0]=-math.pi/4
        mDx1[0,0]=math.cos(math.atan2(1,2))
        mDy1[0,0]=math.sin(math.atan2(1,2))
        mDx1[1,0]=math.cos(math.atan2(-2,-1))
        mDy1[1,0]=math.sin(math.atan2(-2,-1))
        mDx1[2,0]=math.cos(math.atan2(-2,1))
        mDy1[2,0]=math.sin(math.atan2(-2,1))
        mDx1[3,0]=math.cos(math.atan2(1,-2))
        mDy1[3,0]=math.sin(math.atan2(1,-2))
        mDx1[4,0]=math.cos(math.atan2(-1,-2))
        mDy1[4,0]=math.sin(math.atan2(-1,-2))
        mDx1[5,0]=math.cos(math.atan2(2,1))
        mDy1[5,0]=math.sin(math.atan2(2,1))
        mDx1[6,0]=math.cos(math.atan2(2,-1))
        mDy1[6,0]=math.sin(math.atan2(2,-1))
        mDx1[7,0]=math.cos(math.atan2(1,-2))
        mDy1[7,0]=math.sin(math.atan2(1,-2))
        mDx1=mDx0
        mDy1=mDy0
        mD1=mD0
        for v1 in range(0,8):
            for v2 in range(0,8):
                retorno=self.validadeltaMPC2(mDx0[v1,0],mDy0[v1,0],mD0[v1,0],mDx1[v2,0],mDy1[v2,0],mD1[v2,0],200,math.pi/6)
                print('mDx0=',mDx0[v1,0],', mDy0=',mDy0[v1,0],', mD0=',mD0[v1,0],', mDx1=',mDx1[v2,0],', mDy1=',mDy1[v2,0],', mD1=',mD1[v2,0],', retorno=',retorno)
                if retorno==1:
                    retorno=v2
        return retorno    

    def validadeltaMPC2(self,mDx0,mDy0,D0,mDx1,mDy1,D1,toleranciaT,toleranciaA):
        mDx0b=mDx0
        mDy0b=mDy0
        mDx1b=mDx1
        mDy1b=mDy1
        minmDx=min(mDx0,mDx1)
        minmDy=min(mDy0,mDy1)
        #if minmDx<0:
        mDx0=mDx0+2*abs(minmDx)
        mDx1=mDx1+2*abs(minmDx)
        #if minmDy<0:
        mDy0=mDy0+2*abs(minmDy)
        mDy1=mDy1+2*abs(minmDy)
        teste1=0#verificar tolerância do ângulo (direção dos vetores)
        teste2=1#verificar dominância
        teste3=0#verificar tolerância da norma (distância entre os vetores)
        D2=math.atan2(mDy1-mDy0,mDx1-mDx0)
        p1v0=D0-toleranciaA
        p2v0=D0+toleranciaA
        p1v1=D1-toleranciaA
        p2v1=D1+toleranciaA
        p1v2=D2-D0
        p2v2=D2+D1
        if not((p1v1<p1v0 and p2v1<p1v0)or(p1v1>p2v0 and p2v1>p2v0)):
            if not((p1v2<p1v0 and p2v2<p1v0)or(p1v2>p2v0 and p2v2>p2v0)):
                teste1=1
        #if ((mDx0<=mDx1 and mDy0<=mDy1) or (mDx0>=mDx1 and mDy0>=mDy1)) and teste1==1:
        #if (mDx0<=mDx1 and mDy0<=mDy1) and teste1==1 and
        if math.cos(abs(D0-D1))>0:# and D0>=0 and D0<=math.pi/2:
            teste2=1
        if math.sqrt((mDx0-mDx1)**2+(mDy0-mDy1)**2)<=toleranciaT:
            teste3=1
        # mDx0=mDx0b
        # mDy0=mDy0b
        # mDx1=mDx1b
        # mDy1=mDy1b
        # maxmDx=max(mDx0,mDx1)
        # maxmDy=max(mDy0,mDy1)
        # #if minmDx<0:
        # mDx0=mDx0-2*abs(minmDx)
        # mDx1=mDx1-2*abs(minmDx)
        # #if minmDy<0:
        # mDy0=mDy0-2*abs(minmDy)
        # mDy1=mDy1-2*abs(minmDy)
        # teste4=0#verificar dominância
        # teste5=0#verificar tolerância da norma (distância entre os vetores)
        # teste6=0#verificar tolerância do ângulo (direção dos vetores)
        # p1v0=D0-toleranciaA
        # p2v0=D0+toleranciaA
        # p1v1=D1-toleranciaA
        # p2v1=D1+toleranciaA
        # if not((p1v1<p1v0 and p2v1<p1v0)or(p1v1>p2v0 and p2v1>p2v0)):
        #     teste4=1
        # #if ((mDx0<=mDx1 and mDy0<=mDy1) or (mDx0>=mDx1 and mDy0>=mDy1)) and teste1==1:
        # if (mDx0>=mDx1 and mDy0>=mDy1) and teste1==1 and math.cos(D0-D1)>0 and D0<=-math.pi/2 and D0<=-math.pi:
        #     teste5=1
        # if math.sqrt((mDx0-mDx1)**2+(mDy0-mDy1)**2)<=toleranciaT:
        #     teste6=1

        return teste1*teste2*teste3#+teste4*teste5*teste6
    
    #def melhor(self,f,pop,mfa,mia):
    def aptidao(self,mx,my):
        menor=math.sqrt(mx[0,0]**2+my[0,0]**2)
        maior=math.sqrt(mx[0,0]**2+my[0,0]**2)
        for cl in range(0,len(mx)):
            if math.sqrt(mx[cl,0]**2+my[cl,0]**2)<menor:
                menor=math.sqrt(mx[cl,0]**2+my[cl,0]**2)
            if math.sqrt(mx[cl,0]**2+my[cl,0]**2)>maior:
                maior=math.sqrt(mx[cl,0]**2+my[cl,0]**2)
        #f=math.sqrt((menor-maior)**2)
        f=math.sqrt((menor+maior)**2)
        return f
    def melhor2(self,f,pop,vmfa,vmia1,vmia2,vmia3):
        estado=0
        for contador in range(0,len(f)):
            #if f[contador,0]<vmfa and f[contador,0]>0:
            if f[contador,0]>vmfa and f[contador,0]>0:
                mf=f[contador]
                mi=pop[contador]#[:]
                estado=1
        if estado==0:
            mf=matrix([[vmfa]])
            mi=matrix([[vmia1,vmia2,vmia3]])
        return mf,mi

    def melhor(self,f,pop,vmfa,vmia1):
        estado=0
        for contador in range(0,len(f)):
            #if f[contador,0]<vmfa and f[contador,0]>0:
            if f[contador,0]>vmfa and f[contador,0]>0:
                mf=f[contador]
                mi=pop[contador]#[:]
                estado=1
        if estado==0:
            mf=matrix([[vmfa]])
            #mi=matrix([[vmia1,vmia2,vmia3]])
            mi=vmia1
        return mf,mi

    def pior(self,f,pop):
        ipi=0
        pf=f[0]
        pi=pop[0]
        for contador in range(1,len(f)):
            if f[contador]>pf:
                pf=f[contador]
                pi=pop[contador]
                ipi=contador
        return pf,pi,ipi
    
    def selecao(self,f,pop):
        r=f/sum(f)
        rs=self.ordena(r)
        ra=matlib.zeros((len(r),1))
        #ra[0,0]=rs[0,0]
        for contador in range(0,len(r)):
            #ra[contador,0]=sum(rs[0:contador,0])
            ra[contador,0]=sum(rs[0:contador+1,0])
            #ra[contador,0]=ra[contador]+ra[contador-1]
        ind=rnd.randint(0,100)/100
        n=1
        for contador in range(0,len(r)-2):
            if ind<ra[contador,0]:
                n=(len(r))-contador
                break
        if n>=len(r):
            n=len(r)-1
        print('n='+str(n))
        for contador in range(0,len(r)):
            #print('n='+str(n)+', rs='+str(rs)+', contador='+str(contador)+', r='+str(r))
            if rs[n,0]==r[contador,0]:
                ni=contador
            else:
                ni=n
        return ni
    
    def ordena(self,matriz):
        for indice in range(0,len(matriz)-1):
            for indice2 in range(indice,len(matriz)):
                if matriz[indice]>matriz[indice2]:
                    temp=matriz[indice]
                    matriz[indice]=matriz[indice2]
                    matriz[indice2]=temp
        return matriz
    def trunca(self,dec):
        dec=int(dec*1000)
        return dec/1000
    def dec2bin(self,dec):
        dec=self.trunca(dec)
        #dec=dec*10**(len(str(dec))-2)
        dec=dec*10**(3)
        tam=len(str(dec))-2
        if dec==0:
            m=matlib.zeros((1,1))
            m[0]=0
        else:
            if dec==1:
                m=matlib.zeros((1,1))
                m[0]=1
            else:
                if dec==2:
                    m=matlib.zeros((2,1))
                    m[0]=0
                    m[1]=1
                else:
                    e=0
                    while dec>2**e:
                        e=e+1
                        tam=e
                        m=matlib.zeros((tam,1))
                        contador=0
                        #while dec>3:
                    for pos in range(0,tam):
                        m[contador]=dec%2
                        contador=contador+1
                        dec=int(dec/2)
        return m
    def mutacaoP(self,m):
        ind=rnd.randint(0,len(m)-1)
        if m[ind,0]==0:
            m[ind,0]=1
        else:
            m[ind,0]=0
        return m    
    def mutacao(self,pop,pm,ni):
        ind=rnd.randint(0,100)/100
        if ind<pm:
            m=self.dec2bin(pop[ni,0])
            m2=self.mutacaoP(m)
            m3=self.bin2dec(m2)
            pop[ni,0]=m3[0,0]
        ind=rnd.randint(0,100)/100
        if ind<pm:
            m=self.dec2bin(pop[ni,1])
            m2=self.mutacaoP(m)
            m3=self.bin2dec(m2)
            pop[ni,1]=m3[0,0]
        ind=rnd.randint(0,100)/100
        if ind<pm:
            m=self.dec2bin(pop[ni,2])
            m2=self.mutacaoP(m)
            m3=self.bin2dec(m2)
            pop[ni,2]=m3[0,0]
        return pop
    def cruzamentoP(self,p,m):
        ind=rnd.randint(0,len(m)-1)
        f1=p
        f2=m
        f1[ind:min(len(p),len(m))]=m[ind:min(len(p),len(m))]
        f2[ind:min(len(p),len(m))]=f1[ind:min(len(p),len(m))]
        return f1,f2    
    def cruzamento(self,pop,pc,np,nm):
        ind=rnd.randint(0,100)/100
        if ind<pc:
            p=self.dec2bin(pop[np,0])
            m=self.dec2bin(pop[nm,0])
            f1,f2=self.cruzamentoP(p,m)
            mf1=self.bin2dec(f1)
            mf2=self.bin2dec(f2)
            pop[np,0]=mf1[0,0]
            pop[nm,0]=mf2[0,0]
        ind=rnd.randint(0,100)/100
        if ind<pc:
            p=self.dec2bin(pop[np,1])
            m=self.dec2bin(pop[nm,1])
            f1,f2=self.cruzamentoP(p,m)
            mf1=self.bin2dec(f1)
            mf2=self.bin2dec(f2)
            pop[np,1]=mf1[0,0]
            pop[nm,1]=mf2[0,0]
        ind=rnd.randint(0,100)/100
        if ind<pc:
            p=self.dec2bin(pop[np,2])
            m=self.dec2bin(pop[nm,2])
            f1,f2=self.cruzamentoP(p,m)
            mf1=self.bin2dec(f1)
            mf2=self.bin2dec(f2)
            pop[np,2]=mf1[0,0]
            pop[nm,2]=mf2[0,0]
        return pop
    def bin2dec(self,binario):
        expoente=0
        dec=0
        for contador in range(0,len(binario)):
            dec=dec+binario[contador]*pow(2,expoente)
            expoente=expoente+1
        #dec=bin
        return dec/1000
        #bin=dec
        #m[contador]=dec%2
            
        #contador=contador+1
        #dec=int(dec/2)        
        #return m
    def tf2ssR(self, R01a,R01b,ns,ni,no,madj):
        #A=self.zeros(ns,ns)
        A=matlib.zeros((ns,ns))
        for i in range(0,ns):
            #print('i=',i)
            A[[i],[i]]=-R01b;
        #B=self.zeros(ns,ni);
        B=matlib.zeros((ns,ni))
        LB=0;
        CB=0;
        #[Lmadj,Cmadj]=size(madj);
        s=madj.shape#eq. size
        Lmadj=s[0]
        Cmadj=s[1]
        for cCmadj in range(0,Cmadj):
            for cLmadj in range(0,Lmadj):
                if(madj[[cLmadj],[cCmadj]]==1):
                    B[[LB],[CB]]=R01a;
                    LB=LB+1;
            CB=CB+1;
        #C=self.zeros(no,ns);
        C=matlib.zeros((no,ns))
        CC=0;
        for cCmadj in range(0,Cmadj):
            for cLmadj in range(0,Lmadj):
                if(madj[[cLmadj],[cCmadj]]==1):
                    C[[cLmadj],[CC]]=1;
                    CC=CC+1;
        #D=self.zeros(no,ni);        
        D=matlib.zeros((no,ni))
        return A,B,C,D
    def ss2ssR3e(self,Ap,Bp,Cp,Dp,beta,kappa):
        De=matlib.zeros((3*Dp.shape[0],Dp.shape[1]))
        Ce=matlib.zeros((3*Cp.shape[0],3*Cp.shape[1]))
        Be=matlib.zeros((3*Bp.shape[0],Bp.shape[1]))
        Ae=matlib.zeros((3*Ap.shape[0],3*Ap.shape[1]))
        #De=zeros(3*size(Dp,1),size(Dp,2));
        #[LCp,CCp]=size(Cp);
        sCp=Cp.shape
        LCp=sCp[0]
        CCp=sCp[1]
        #Ce=[];
        for cLCp in range(0,LCp):
            for cCCp in range(0,CCp):
                #LCe[=[LCe,[Cp(cLCp,cCCp),0,0;0,Cp(cLCp,cCCp),0;0,0,Cp(cLCp,cCCp)]];
                #Ce[3*cLCp:3*cLCp+3][3*cCCp:3*cCCp+3]=matrix([[Cp[cLCp][cCCp],0,0],[0,Cp[cLCp][cCCp],0],[0,0,Cp[cLCp][cCCp]]])
                Ce[[3*cLCp],[3*cCCp]]=Cp[[cLCp],[cCCp]]
                Ce[[3*cLCp],[3*cCCp+1]]=0
                Ce[[3*cLCp],[3*cCCp+2]]=0
                Ce[[3*cLCp+1],[3*cCCp]]=0
                Ce[[3*cLCp+1],[3*cCCp+1]]=Cp[[cLCp],[cCCp]]
                Ce[[3*cLCp+1],[3*cCCp+2]]=0
                Ce[[3*cLCp+2],[3*cCCp]]=0
                Ce[[3*cLCp+2],[3*cCCp+1]]=0
                Ce[[3*cLCp+2],[3*cCCp+2]]=Cp[[cLCp],[cCCp]]
                
                #end;
                #Ce=[Ce;LCe];
                #end;
        #[LBp,CBp]=size(Bp);
        sBp=Bp.shape
        LBp=sBp[0]
        CBp=sBp[1]
        #Be=[]
        #for(cLBp=1:LBp)
        for cLBp in range(0,LBp):
            for cCBp in range(0,CBp):
                Be[[3*cLBp],[cCBp]]=Bp[[cLBp],[cCBp]]
                Be[[3*cLBp+1],[cCBp]]=Bp[[cLBp],[cCBp]]
                Be[[3*cLBp+2],[cCBp]]=Bp[[cLBp],[cCBp]]
        #    #Be=[Be;
        #    #Bp(cLBp,:);
        #    #zeros(2,CBp)];
        #    for cCBp in range(0,CBp):
        #        Be[3*cLBp][:]=matrix([Bp[cLBp][cCBp],[0],[0]])
        #    #end;
        #Ae=[];
        #[LAp,CAp]=size(Ap);
        #for(cLAp=1:LAp)
        #    LAe=[];
        #    for(cCAp=1:CAp)
        #        LAe=[LAe,[Ap(cLAp,cCAp),0,0;0,Ap(cLAp,cCAp),0;kappa*Ap(cLAp,cCAp),0,beta*Ap(cLAp,cCAp)]];
        #    end;
        #    Ae=[Ae;LAe];
        #end;        
        #sAp=Ap.shape
        #LAp=sAp[0]
        #CAp=sAp[1]
        #for cLAp in range(0,LAp):
        #    for cCAp in range(0,CAp):
        #        #LCe[=[LCe,[Cp(cLCp,cCCp),0,0;0,Cp(cLCp,cCCp),0;0,0,Cp(cLCp,cCCp)]];
        #        print('L=',3*cLAp,3*cLAp+3,'C=',3*cCAp,3*cCAp+3)
        #        Ae[3*cLAp:3*cLAp+3][3*cCAp:3*cCAp+3]=matrix([[Ap[cLAp][cCAp],0,0],[0,Ap[cLAp][cCAp],0],[0,0,Ap[cLAp][cCAp]]])
        sAp=Ap.shape
        LAp=sAp[0]
        CAp=sAp[1]
        #Ce=[];
        for cLAp in range(0,LAp):
            for cCAp in range(0,CAp):
                #LCe[=[LCe,[Cp(cLCp,cCCp),0,0;0,Cp(cLCp,cCCp),0;0,0,Cp(cLCp,cCCp)]];
                #Ce[3*cLCp:3*cLCp+3][3*cCCp:3*cCCp+3]=matrix([[Cp[cLCp][cCCp],0,0],[0,Cp[cLCp][cCCp],0],[0,0,Cp[cLCp][cCCp]]])
                Ae[[3*cLAp],[3*cCAp]]=Ap[[cLAp],[cCAp]]
                Ae[[3*cLAp],[3*cCAp+1]]=Ap[[cLAp],[cCAp]]
                Ae[[3*cLAp],[3*cCAp+2]]=0
                Ae[[3*cLAp+1],[3*cCAp]]=0
                Ae[[3*cLAp+1],[3*cCAp+1]]=Ap[[cLAp],[cCAp]]
                Ae[[3*cLAp+1],[3*cCAp+2]]=0
                Ae[[3*cLAp+2],[3*cCAp]]=kappa
                Ae[[3*cLAp+2],[3*cCAp+1]]=0
                Ae[[3*cLAp+2],[3*cCAp+2]]=beta
        
        return Ae,Be,Ce,De
    def retorna_regressor(self,posicao):
        contador=0
        manipulador=open('regressores.txt','r')
        for linha in manipulador:
            linha=linha.rstrip()
            #print(linha)
            contador+=1
            if contador==posicao:
                break
        manipulador.close()
        return linha
    
    def insere_matrix(self,m1,m2,LIo,CIo,LFo,CFo,LId,CId):#inser m2 em m1
        #m1 - arrive matrix, m2 - depature matrix
        #LFo=LFo+1
        #CFo=CFo+1
        LFo=LFo
        CFo=CFo
        cCd=CId
        for cCo in range(CIo,CFo):
            cLd=LId
            for cLo in range(LIo,LFo):
                m1[[cLd],[cCd]]=m2[[cLo],[cCo]]
                #m1[cLd,cCd]=m2[cLo,cCo]
                cLd=cLd+1
            cCd=cCd+1
        return m1
    
    def insere_matrix_down(self,m1,m2):#insere m2 abaixo de m1
        #m1 - arrive matrix, m2 - depature matrix
        sm1=m1.shape
        sm2=m2.shape
        m3=matlib.zeros((sm1[0]+sm2[0],sm1[1]))
        m3=self.insere_matrix(m3,m1,0,0,sm1[0],sm1[1],0,0)
        m3=self.insere_matrix(m3,m2,0,0,sm2[0],sm2[1],sm1[0],0)
        return m3
    
    def dmpc(self,A_e,B_e,a,N,Np,Q,R):
        #[n,n_in]=size(B_e);
        s=B_e.shape
        n=s[0]
        n_in=s[1]
        #print('n=',n,'n_in=',n_in)
        #N_pa=sum(N); %the dimension of eta
        N_pa=matlib.sum(N)
        #print('N_pa=',N_pa)
        #print('n=',n,'n_in=',n_in,'N_pa=',N_pa)
        #E=zeros(N_pa,N_pa);
        E=matlib.zeros((N_pa,N_pa))
        #H=zeros(N_pa,n);
        H=matlib.zeros((N_pa,n))
        #R_para=zeros(N_pa,N_pa);
        R_para=matlib.zeros((N_pa,N_pa))
        n0=0;
        #ne=N(1);
        ne=N.item(0)
        #print('E=',E,'H=',H,'R_para=',R_para,'ne=',ne)
        #print('E=',E.shape,'H=',H.shape,'R_para=',R_para.shape)
        #for i=1:n_in-1;
        #print('N_pa=',N_pa,'n_in=',n_in)
        #print('N=',N)
        for i in range(0,n_in-1):
            #R_para(n0:ne,n0:ne)= R(i,i)*eye(N(i),N(i));
            #matriz=R.item(i,i)*matlib.eye(N.item(i),N.item(i))
            #Sm=matriz.shape
            #R_para=self.insere_matrix(R_para,matriz,0,0,Sm[0],Sm[1],n0,n0)
            #(R_para[n0:ne,n0:ne].shape)
            R_para[n0:ne,n0:ne]=R.item(i,i)*matlib.eye(N.item(i),N.item(i))
            #n0=n0+N(i);
            n0=n0+N.item(i)
            #ne=ne+N(i+1);
            ne=ne+N.item(i+1)
            #print('i=',i,'n0=',n0,'ne=',ne,'I=',matlib.eye(N.item(i),N.item(i)).shape,'R_para=',R_para[n0:ne,n0:ne].shape)
            #end
        #print('R_para=',R_para,'n0=',n0,'ne=',ne)
        #print('R_para=',R_para.shape)
        #R_para(n0:N_pa,n0:N_pa)=R(n_in,n_in)*eye(N(n_in),N(n_in));
        #print('R.shape=',R.shape,'n_in=',n_in,'N=',N.shape,'n_in=',n_in)
        #print('N.item(0,n_in-1)=',N.item(0,n_in-1))
        #matriz=R.item(n_in-1,n_in-1)*matlib.eye(N.item(0,n_in-1),N.item(0,n_in-1))
        #print('matriz=',matriz)
        #print('R_para=',R_para.shape,'matriz=',matriz.shape,'Sm[0]=',Sm[0],'Sm[1]=',Sm[1],'n0=',n0)
        #print('N_pa=',N_pa)
        #R_para=self.insere_matrix(R_para,matriz,0,0,Sm[0]-1,Sm[1]-1,n0,n0)
        print('N_pa=',N_pa,'n_in=',n_in,'R_para=',R_para.shape,'R=',R.shape,'N=',N.shape)
        print('N=',N.item(n_in-1))
        print('R=',R.item(n_in-1,n_in-1))
        print('R_para',R_para[n0:N_pa,n0:N_pa])
        R_para[n0:N_pa+1,n0:N_pa+1]=R.item(n_in-1,n_in-1)*matlib.eye(N.item(n_in-1),N.item(n_in-1))
        #print('R_para=',R_para.shape,R_para)
        #print('ne=',ne)
        #print('n0=',n0)#,'N_pa=',N_pa,'n_in=',n_in,'R_para=',R_para.shape)
        #print('R_para=',R_para)#[n0:N_pa,n0:N_pa].shape,R_para[n0:N_pa,n0:N_pa])#,'R=',R.item(n_in,n_in)*matlib.eye(N.item(n_in),N.item(n_in)).shape)
        #R_para[n0:N_pa,n0:N_pa]=R.item(n_in,n_in)*matlib.eye(N.item(n_in),N.item(n_in))
        #S_in=zeros(n,N_pa);
        S_in=matlib.zeros((n,N_pa))
        #print('S_in=',S_in,'n=',n,'N_pa=',N_pa)
        #[Al,L0]=lagd(a(1),N(1));
        [Al,L0]=self.lagd(a.item(0),N.item(0))
        #print('L0=',L0.shape)
        #print('R_para=',R_para,'S_in=',S_in,'Al=',Al,'L0=',L0)
        #print('R_para=',R_para.shape,'S_in=',S_in.shape,'Al=',Al.shape,'L0=',L0.shape)
        #S_in(:,1:N(1))=B_e(:,1)*L0';
        #matriz=B_e.item()
        #S_in=self.insere_matrix(S_in,matriz,0,0,Sm[0]-1,Sm[1]-1,n0,n0)
        #print('S_in=',S_in[:,0:N.item(0)].shape,'B_e=',B_e[:,0].shape,'L0t=',L0.transpose().shape)
        S_in[:,0:N.item(0)]=B_e[:,0]*L0.transpose()
        #print(S_in,S_in.shape)
        In_s=0
        #for jj=2:n_in;
        for jj in range(1,n_in):
            #   [Al,L0]=lagd(a(jj),N(jj));
            [Al,L0]=self.lagd(a.item(jj),N.item(jj))
            #   In_s=N(jj-1)+In_s;
            In_s=N.item(jj-1)+In_s
            #   In_e=In_s+N(jj)-1;
            In_e=In_s+N.item(jj)-1
            #   S_in(:,In_s:In_e)=B_e(:,jj)*L0';
            #print('In_s=',In_s,'In_e=',In_e)
            #print('S_in=',S_in[:,In_s:In_e].shape,' B_e=',B_e[:,jj].shape,'L0t=',L0.transpose().shape)
            S_in[:,In_s:In_e+1]=B_e[:,jj]*L0.transpose()
            #print(S_in[:,In_s:In_e].shape,B_e[:,jj].shape,L0.transpose().shape)
            #end
        #print('Al=',Al)
        #print('In_s=',In_s)
        #print('In_e=',In_e)
        #print('S_in=',S_in.shape)
        #print('i=',i)
        #print('S_in=',S_in,S_in.shape)
        #print('S_in=',S_in[:,0:11])
        #print('S_in=',S_in[:,11:21])
        #print('S_in=',S_in[:,21:31])
        #print('S_in=',S_in[:,31:41])
        #print('S_in=',S_in[:,41:51])
        #print('S_in=',S_in[:,51:61])
        #print('S_in=',S_in[:,61:71])
        #print('S_in=',S_in[:,71:81])
        #print('S_in=',S_in[:,81:91])
        S_sum=S_in
        phi=S_in
        #E=(phi)'*Q*(phi);
        E=phi.transpose()*Q*(phi)
        #H=phi'*Q*A_e;
        H=phi.transpose()*Q*A_e
        #print('E=',E,E.shape,'H=',H,H.shape)
        #print('In_s=',In_s,'In_e=',In_e)
        #for i=2:Np;
        for i in range(2,Np):
            #print(A_e**)
            #for i in range(1,2):
            #Eae=A_e^i;
            Eae=A_e**(i)
            #print('Eae=',Eae)
            #if i==3:
            #    print('Eae=',Eae)
            #%calculate the finite sum S for each input
            #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            #%For each sample i
            #%%%%%%%%%%%%calculate input number 1
            #%specify the L0 and state matrix Al
            #%associated with the first input
            #[Al,L0]=lagd(a(1),N(1));
            [Al,L0]=self.lagd(a.item(0),N.item(0))
            #if i==3:
            #    print('L0=',L0)
            #print('Al=', Al.shape,Al,'L0=',L0.shape,L0)
            #% Laguerre function associated with input number 1
            #S_sum(:,1:N(1))=A_e*S_sum(:,1:N(1))+S_in(:,1:N(1))*(Al^(i-1))';
            #print('S_sum=',S_sum[:,0:N.item(0)].shape,'A_e=',A_e.shape,'S_sum=',S_sum[:,0:N.item(0)].shape,'S_in=',S_in[:,0:N.item(0)].shape,'A1t=',(Al**(i-1)).transpose().shape)
            #S_sum[:,1:N.item(0)]=A_e*S_sum[:,1:N.item(0)]+S_in[:,1:N.item(0)]*(Al**(i-1)).transpose()
            #print('S_sum=',S_sum.shape,S_sum[17:21,0:4])#[:,1:N.item(0)].shape,'A_e=',A_e.shape,'S_sum=',S_sum[:,1:N.item(0)].shape,'S_in=',S_in[:,1:N.item(0)].shape,'A1t=',(Al**(i-1)).transpose().shape)
            S_sum[:,0:N.item(0)]=A_e*S_sum[:,0:N.item(0)]+S_in[:,0:N.item(0)]*(Al**(i)).transpose()
            #print('S_sum=',S_sum)
            #print('S_sum=',S_sum.shape,S_sum[17:21,0:4])#[:,1:N.item(0)].shape,'A_e=',A_e.shape,'S_sum=',S_sum[:,1:N.item(0)].shape,'S_in=',S_in[:,1:N.item(0)].shape,'A1t=',(Al**(i-1)).transpose().shape)
            #%%move on to input number 2 and so on
            In_s=0;
            #for kk=2:n_in;
            for kk in range(1,n_in):
                #for kk in range(1,2):
                #[Al,L0]=lagd(a(kk),N(kk));
                [Al,L0]=self.lagd(a.item(kk),N.item(kk))
                #print('Al=',Al)
                #print('L0=',L0)
                #print('L0=',L0)
                #print('i=',i)
                #print('Al=', Al.shape,Al,'L0=',L0.shape,L0)
                #In_s=N(kk-1)+In_s;
                In_s=N.item(kk-1)+In_s
                #print('In_s=',In_s)
                #In_e=In_s+N(kk)-1;
                In_e=In_s+N.item(kk)-1
                #print('*n_e=',In_e)
                #S_sum(:,In_s:In_e)=A_e*S_sum(:,In_s:In_e)+S_in(:,In_s:In_e)*(Al^(i-1))';
                #print('S_sum=',S_sum[:,In_s:In_e].shape,'A_e=',A_e.shape,'S_sum=',S_sum[:,In_s:In_e].shape,'S_in=',S_in[:,In_s:In_e].shape,'Alt=',(Al**(i-1)).transpose().shape)
                #print('i=',i,'In_s=',In_s,'In_e=',In_e)
                #print('i=',i)
                #print('S_sum=',S_sum.shape,S_sum[0:5,0:5])#[:,1:N.item(0)].shape,'A_e=',A_e.shape,'S_sum=',S_sum[:,1:N.item(0)].shape,'S_in=',S_in[:,1:N.item(0)].shape,'A1t=',(Al**(i-1)).transpose().shape)
                #if i==3 and kk==1:
                #    print('In_s=',In_s,'In_e=',In_e,'S_sum=',S_sum[:,In_s:In_e+1],'S_in=',S_in[:,In_s:In_e+1])
                #S_sum[:,In_s:In_e+1]=A_e*S_sum[:,In_s:In_e+1]+S_in[:,In_s:In_e+1]*(Al**(i-1)).transpose()
                S_sum[:,In_s:In_e+1]=A_e*S_sum[:,In_s:In_e+1]+S_in[:,In_s:In_e+1]*(Al**(i)).transpose()
                #print('S_sum=',S_sum)
                #S_sum[:,In_s:In_e]=A_e*S_sum[:,In_s:In_e]+S_in[:,In_s:In_e]*(Al**(i-1)).transpose()
                #print('S_sum=',S_sum.shape,S_sum[0:5,0:5])#[:,1:N.item(0)].shape,'A_e=',A_e.shape,'S_sum=',S_sum[:,1:N.item(0)].shape,'S_in=',S_in[:,1:N.item(0)].shape,'A1t=',(Al**(i-1)).transpose().shape)
            #end
            #print('i=',i)
            #print('phi=',phi)
            phi=S_sum;
            #print('phi=',phi)
            #E=E+phi'*Q*phi;
            #print('E=',E)
            E=E+phi.transpose()*Q*phi
            #print('E=',E)
            #H=H+phi'*Q*Eae;
            #print('H=',H)
            H=H+phi.transpose()*Q*Eae
            #print('H=',H)
            #print('Q=',Q)
        #end
        #E=E+R_para; 
        E=E+R_para
        return E,H
    
    def lagd(self,a,N):
        #v(1,1)=a;#m[[1],[2]]=5
        v=matlib.zeros((N,1))
        v[[0],[0]]=a
        #L0(1,1)=1;
        L0=matlib.zeros((N,1))
        L0[[0],[0]]=1
        #for k=2:N
        for k in range(1,N):
            #v(k,1)=(-a).^(k-2)*(1-a*a);
            v[[k],[0]]=((-a)**(k+1-2))*(1-a*a)
            #print(v[[k],[0]])
            #L0(k,1)=(-a).^(k-1);
            L0[[k],[0]]=(-a)**(k+1-1)
            #print(L0[[k],[0]])
            #end
        #L0=sqrt((1-a*a))*L0;
        L0=math.sqrt(1-a*a)*L0
        #print(L0)
        #A(:,1)=v;
        A=matlib.zeros((N,N))
        A=self.insere_matrix(A,v,0,0,N,0+1,0,0)
        #A=self.insere_matrix(A,v,0,0,N-1,0+1,1,1)
        #A=self.insere_matrix(A,v,0,0,N-2,0+1,2,2)
        #A=self.insere_matrix(A,v,0,0,N-3,0+1,3,3)
        #A=self.insere_matrix(A,v,0,0,N-4,0+1,4,4)
        #A=self.insere_matrix(A,v,0,0,N-5,0+1,5,5)
        #print(N)
        #print('A=',A)
        #for i=2:N
        for i in range(1,N):
            #A(:,i)=[zeros(i-1,1);v(1:N-i+1,1)];
            #matriz=matlib.zeros((i,1))
            #s=matriz.shape
            #A=self.insere_matrix(A,matriz,0,0,i,0,0,0)
            #print('i=',i)
            #print('v=',v)
            #print('A=',A)
            A=self.insere_matrix(A,v,0,0,N-i,0+1,i,i)
            #A=self.insere_matrix(A,v,0,0,N-i+1,0,i+1,0)#+1 porque o range(vi,vo) não vai até vo e sim até vo-1
        #end
        return A,L0
    
    def Mdu(self,a,N,n_in,Nc):
        #%a and N are for the Laguerre functions
        #%n_in is the number of inputs
        #%Nc is the number of constraints
        #N_pa=sum(N);
        N_pa=N.sum()
        #print('N_pa=',N_pa)
        M=matlib.zeros((n_in,N_pa));
        #print(M.shape)
        M_du1=matlib.zeros((n_in,N_pa));
        k0=0;
        #[Al,L0]=lagd(a(k0),N(k0));
        [Al,L0]=self.lagd(a.item(k0),N.item(k0));
        #print('Al=',Al,'L0=',L0)
        #M_du1(1,1:N(1))=L0';
        M_du1[0,0:N.item(0)]=L0.transpose()
        #cc=N(1);
        cc=N.item(0)
        #print('M_du1=',M_du1,'cc=',cc)
        #for k0=2:n_in;
        #[Al,L0]=lagd(a(k0),N(k0));
        #M_du1(k0,cc+1:cc+N(k0))=L0';
        #cc=cc+N(k0);
        #end
        for k0 in range(1,n_in):
            [Al,L0]=self.lagd(a.item(k0),N.item(k0))
            #print(L0.transpose().shape)
            #
            M_du1[k0,cc:cc+N.item(k0)]=L0.transpose()
            cc=cc+N.item(k0)
        #print('M_du1=',M_du1,'cc=',cc)
        #Lzerot=M_du1;
        Lzerot=M_du1
        #M=M_du1;
        M=M_du1
        #for kk=2:Nc
        #k0=1;
        #[Al,L0]=lagd(a(k0),N(k0));
        #L=Al^(kk-1)*L0;
        #M_du1(1,1:N(1))=L';
        #cc=N(1);
        #for k0=2:n_in;
        #[Al,L0]=lagd(a(k0),N(k0));
        #L=Al^(kk-1)*L0;
        #M_du1(k0,cc+1:cc+N(k0))=L';
        #cc=cc+N(k0);
        #end
        #M=[M;M_du1];   
        #end;
        for kk in range(1,Nc):
            k0=0
            [Al,L0]=self.lagd(a.item(k0),N.item(k0))
            L=Al**(kk-1)*L0
            M_du1[0,0:N.item(0)]=L.transpose()
            cc=N.item(0)
            for k0 in range(1,n_in):
                [Al,L0]=self.lagd(a.item(k0),N.item(k0))
                L=Al**(kk-1)*L0
                M_du1[k0,cc+1:cc+N.item(k0)]=L.transpose()
                cc=cc+N.item(k0)
            M=self.insere_matrix_down(M,M_du1)
        return M,Lzerot

    def Ikpi(self,S,zeta,I,zk):
        #I=S-S*exp(-(zeta+I)/(S*zk));
        I=0
        return I
    
    
    
    
    
    
    
    def py6(self,a,b):#coluna,linha
        #a=int(input("Enter the no. of rows:"))
        #b=int(input("Enter the no. of columns:"))
        #c=[[input("Enter the element:")for j in range(a)]for i in range(b)]
        manipulador=open('referencia.txt','r')
        #for linha in manipulador:
        #    linha=linha.rstrip()
        c=[[linha.rstrip() for j in range(a)] for linha in manipulador]
        return c

    def retorna_referencia(self):
        cc=self.py6(1,3)
        #print(cc)
        #print(cc.count)
        import matplotlib.pyplot as plt
        import numpy as np
        import pandas as pd
        #tcc=cc.shape
        for i in range(0,4506):
            n=cc[i]
            cc[i]=int(n[0])    
        return cc
    def retorna_int(self,vetor):
        sv=vetor.shape
        cc=matlib.zeros((sv[0]))
        #print(cc.shape)
        for i in range(0,sv[0]):
            n=vetor[i]
            cc[0,i]=int(n[0])    
        return cc
    def converte_tupla_matrix(self,vetor):
        contador=0
        for elemento in vetor:
            contador=contador+1
        cc=matlib.zeros((contador,1))
        for i in range(0,contador):
            n=vetor[i]
            cc[i,0]=n 
        return cc        
    def converte_matrix_tupla(self,vetor):
        sv=vetor.shape
        x=[]
        contador=0
        for elemento in vetor:
            #x.append(vetor[0][contador])
            x.append(0)
            contador=contador+1        
        contador=0
        for elemento in vetor:
            #x.append(vetor[0][contador])
            if sv[0]>sv[1]:
                x[contador]=vetor[contador,0]
            else:
                x[contador]=vetor[0,contador]
            contador=contador+1
        return x
    def calcula_energia(self,rho,upsilon,rhoc,c):
        et=1/2*rho*upsilon**2+c**2/(2*rhoc)*(rho-rhoc)**2
        return et
    def plota_grafico(self,y1):
        sy=y1.shape
        if sy[0]>sy[1]:
            msy=sy[0]
        else:
            msy=sy[1]
            y1=y1.transpose()#transforma vetor coluna em vetor linha
        x = np.linspace(0.0, 1.0, msy)

        #y = np.cos(2*np.pi*x) * np.exp(-x)
        #yy=aa1.converte_matrix_tupla(y)
        #print('y1=',y1,'yy=',yy)
        plt.plot(x, y1, 'k')
        plt.title('Damped exponential decay', fontdict=font)
        plt.text(2, 0.65, r'$\cos(2 \pi t) \exp(-t)$', fontdict=font)
        plt.xlabel('time (s)', fontdict=font)
        plt.ylabel('voltage (mV)', fontdict=font)
        
        # Tweak spacing to prevent clipping of ylabel
        plt.subplots_adjust(left=0.15)
        plt.show()

    def plota_grafico2(self,y1,title,text,xlabel,ylabel):
        sy=y1.shape
        if sy[0]>sy[1]:
            msy=sy[0]
        else:
            msy=sy[1]
            y1=y1.transpose()#transforma vetor coluna em vetor linha
        x = np.linspace(0.0, 1.0, msy)

        #y = np.cos(2*np.pi*x) * np.exp(-x)
        #yy=aa1.converte_matrix_tupla(y)
        #print('y1=',y1,'yy=',yy)
        plt.plot(x, y1, 'k')
        #plt.title('Damped exponential decay', fontdict=font)
        plt.title(title, fontdict=font)
        plt.text(x[1], y1[y1.shape[0]-1], text, fontdict=font)
        plt.xlabel(xlabel, fontdict=font)
        plt.ylabel(ylabel, fontdict=font)
        
        # Tweak spacing to prevent clipping of ylabel
        plt.subplots_adjust(left=0.15)
        plt.show()

    def quick_sort(self,x,i,f):
        e=i
        d=f
        k=x[int((i+f)/2),0]
        while True:
            while x[e,0]<k:
                e=e+1
            while x[d,0]>k:
                d=d-1
            if e<=d:
                c0temp=x[e,0]
                c1temp=x[e,1]
                c2temp=x[e,2]
                c3temp=x[e,3]
                c4temp=x[e,4]
                x[e,:]=x[d,:]
                e=e+1
                x[d,0]=c0temp
                x[d,1]=c1temp
                x[d,2]=c2temp
                x[d,3]=c3temp
                x[d,4]=c4temp
                d=d-1
            if e>d:
                break
        if i<d:
            self.quick_sort(x,i,d)
        if e<f:
            self.quick_sort(x,e,f)
        return x

#Recursividade
    def countdown(self,n):
        #from modulos.modulos0 import arquivo
        #aa1=arquivo()
        #base case
        if n<=0:
            print("End!")
        else:
            print(n)
            self.countdown(n-1)

#Laço infinito
        #while True:
         #   nota=float(input("Nota? "))
         #   if nota>=0 and nota<=10:
          #      print("sua nota:",nota)
           #     break
            #else:
                #print("digite um valor entre 0 e 10")

    def valida_angulo(self,teta0,teta1,tolerancia):
        if teta0 >= tolerancia and teta0 <=math.pi-tolerancia:
            if teta1 >= teta0-tolerancia and teta1 <= teta0+tolerancia:
                return True
        if teta0 >= -math.pi+tolerancia and teta0 <= -tolerancia:
            if teta1 >= teta0 -tolerancia and teta1 <= teta0+tolerancia:
                return True
        if teta0 > 0 and teta0 < tolerancia:
            if teta1 > teta0-tolerancia and teta1 < teta0+tolerancia:
                return True
        if teta0 > -tolerancia and teta0 < 0:
            if teta1 > teta0-tolerancia and teta1 < teta0+tolerancia:
                return True
        if teta0 > math.pi-tolerancia and teta0 < math.pi:
            if (teta1 > teta0-tolerancia and teta1 < math.pi) or (teta1 > -math.pi and teta1 < -teta0+tolerancia):
                return True
        if teta0 > -math.pi and teta0 < -math.pi+tolerancia:
            if (teta1 > -math.pi and teta1 < teta0+tolerancia) or (teta1 < math.pi and teta1 > -teta0-tolerancia):
                return True
        return False

    def valida_jus(self,x0,y0,x1,y1,teta0,teta1):
        if teta0 >= 0 and teta0 <= math.pi/2:
            if teta1 >=0 and teta1 <=math.pi/2:
                if x1 >= x0 and y1 >= y0:
                    return True
        if teta0 >= math.pi/2 and teta0 <= math.pi:
            if teta1 >= math.pi/2 and teta1 <= math.pi:
                if x1 <= x0 and y1 >= y0:
                    return True
        if teta0 >= -math.pi and teta0 <= -math.pi/2:
            if teta1 >= -math.pi and teta1 <= -math.pi/2:
                if x1 <= x0 and y1 <= y0:
                    return True
        if teta0 >=-math.pi/2 and teta0 <=0:
            if teta1 >=-math.pi/2 and teta1 <=0:
                if x1 >= x0 and y1 <= y0:
                    return True
        return False
#=matrix([D,E,X,Y,ncross,tve]), tve:tempo de verde estimado

    def valida_jus2(self,x0,y0,x1,y1,teta0,teta1):
        #if self.valida_angulo(teta0,teta1,tolerancia)
        if math.sqrt(x1*x1+y1*y1)>=math.sqrt(x0*x0+y0*y0):
                return True
        return False
#=matrix([D,E,X,Y,ncross,tve]), tve:tempo de verde estimado



    def atualiza_tv(self,mD0,incremento,tolerancia):
        [lmD0,cmD0]=mD0.shape
        for i1 in range(0,lmD0):
            for i2 in range(0,lmD0):
                if i1 != i2:
                    #print('jusante=',self.valida_jus(mD0[i1,2],mD0[i1,3],mD0[i2,2],mD0[i2,3],mD0[i1,0],mD0[i2,0]))
                    #print('angulo=',self.valida_angulo(mD0[i1,0],mD0[i2,0],tolerancia))
                    if self.valida_jus(mD0[i1,2],mD0[i1,3],mD0[i2,2],mD0[i2,3],mD0[i1,0],mD0[i2,0]) and self.valida_angulo(mD0[i1,0],mD0[i2,0],tolerancia):
                        mD0[i2,5]=mD0[i2,5]+incremento
        return mD0

    def atualiza_tv2(self,mD0,incremento,tolerancia):
        [lmD0,cmD0]=mD0.shape
        for i1 in range(0,lmD0):
            for i2 in range(0,lmD0):
                if i1 != i2:
                    #print('jusante=',self.valida_jus2(mD0[i1,2],mD0[i1,3],mD0[i2,2],mD0[i2,3],mD0[i1,0],mD0[i2,0]))
                    #print('angulo=',self.valida_angulo(mD0[i1,0],mD0[i2,0],tolerancia))
                    if self.valida_jus2(mD0[i1,2],mD0[i1,3],mD0[i2,2],mD0[i2,3],mD0[i1,0],mD0[i2,0]) and self.valida_angulo(mD0[i1,0],mD0[i2,0],tolerancia):
                        mD0[i2,5]=mD0[i2,5]+incremento
        return mD0


    def teste_tv(self):
        t=math.pi/3
        mD99=matrix([[1e-3, 1e2, 1e2, 2, 2, 8],[1e-3,1e2,1e2, 2, 2, 8]])
        print(self.atualiza_tv(mD99,1,t))
        mD99=matrix([[1.23, 1, 1, 2, 2, 8],[.7, 1, 1, 2, 2, 8]])
        print(self.atualiza_tv(mD99,1,t))
        mD99=matrix([[.71, 1, 1, 2, 2, 8],[2.3, 1, 1, 2, 2, 8]])
        print(self.atualiza_tv(mD99,1,t))
        mD99=matrix([[2.31, 1, 1, 2, 2, 8],[2.3, 1, 1, 2, 2, 8]])
        print(self.atualiza_tv(mD99,1,t))
        mD99=matrix([[2.31, 1, 1, 2, 2, 8],[-2.3, 1, 1, 2, 2, 8]])
        print(self.atualiza_tv(mD99,1,t))
        mD99=matrix([[-2.31, 1, 1, 2, 2, 8],[-2.3, 1, 1, 2, 2, 8]])
        print(self.atualiza_tv(mD99,1,t))
        mD99=matrix([[-.71, 1, 1, 2, 2, 8],[-2.3, 1, 1, 2, 2, 8]])
        print(self.atualiza_tv(mD99,1,t))
        mD99=matrix([[-.71, 1, 1, 2, 2, 8],[-2.3, 1, 1, 2, 2, 8]])
        print(self.atualiza_tv(mD99,1,t))
        mD99=matrix([[-2.31, 1, 1, 2, 2, 8],[-2.3, 1, 1, 2, 2, 8]])
        print(self.atualiza_tv(mD99,1,t))
        mD99=matrix([[.71, 1, 1, 2, 2, 8],[-2.3, 1, 1, 2, 2, 8]])
        print(self.atualiza_tv(mD99,1,t))
        mD99=self.atualiza_tv(mD99,1,t)
        return mD99
    
    def teste_tv2(self):
        t=math.pi/3
        mD99=matrix([[1e-3, 1e2, 1e2, 2, 2, 8],[1e-3,1e2,1e2, 2, 2, 8]])
        print(self.atualiza_tv2(mD99,1,t))
        mD99=matrix([[1.23, 1, 1, 2, 2, 8],[.7, 1, 1, 2, 2, 8]])
        print(self.atualiza_tv2(mD99,1,t))
        mD99=matrix([[.71, 1, 1, 2, 2, 8],[2.3, 1, 1, 2, 2, 8]])
        print(self.atualiza_tv2(mD99,1,t))
        mD99=matrix([[2.31, 1, 1, 2, 2, 8],[2.3, 1, 1, 2, 2, 8]])
        print(self.atualiza_tv2(mD99,1,t))
        mD99=matrix([[2.31, 1, 1, 2, 2, 8],[-2.3, 1, 1, 2, 2, 8]])
        print(self.atualiza_tv2(mD99,1,t))
        mD99=matrix([[-2.31, 1, 1, 2, 2, 8],[-2.3, 1, 1, 2, 2, 8]])
        print(self.atualiza_tv2(mD99,1,t))
        mD99=matrix([[-.71, 1, 1, 2, 2, 8],[-2.3, 1, 1, 2, 2, 8]])
        print(self.atualiza_tv2(mD99,1,t))
        mD99=matrix([[-.71, 1, 1, 2, 2, 8],[-2.3, 1, 1, 2, 2, 8]])
        print(self.atualiza_tv2(mD99,1,t))
        mD99=matrix([[-2.31, 1, 1, 2, 2, 8],[-2.3, 1, 1, 2, 2, 8]])
        print(self.atualiza_tv2(mD99,1,t))
        mD99=matrix([[.71, 1, 1, 2, 2, 8],[-2.3, 1, 1, 2, 2, 8]])
        print(self.atualiza_tv(mD99,1,t))
        mD99=self.atualiza_tv2(mD99,1,t)
        return mD99
    
    def plota_mapas_de_calor(self):
        import matplotlib.pyplot as plt
        import seaborn as sns
        from numpy import math
        dados_brutos=sns.load_dataset("flights")
        dados=dados_brutos.pivot(index="month",columns="year",values="passengers")
        plt.figure(figsize=(8,5))
        sns.heatmap(data=dados,annot=False,fmt='d')
        xx=[1.1,2.1]#2=e*cos(angulo)
        yy=[1.1,2.1]#2=e*sin(angulo)
        e=1
        #angulo=atan2((yD-yO),(xD-xO))
        angulo=math.atan2((yy[1]-yy[0]),(xx[1]-xx[0]))
        sns.lineplot(x=xx,y=yy,size_norm=e)
        #sns.lineplot(x=[xx[0]+.2,xx[1]+.2],y=[yy[0]+.2,yy[1]+.2],size_norm=e)
        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo+5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo+5*pi/6)],cor);
        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo+5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo+5*math.pi/6)],size_norm=1)
        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo-5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo-5*pi/6)],cor);
        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo-5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo-5*math.pi/6)],size_norm=1)

        #g.map(plt.axhline, y=0.1, color="k", ls=":");
        plt.show()


    def plota_mapas_de_calor2(self,xx,yy):
        import matplotlib.pyplot as plt
        import seaborn as sns
        from numpy import math
        dados_brutos=sns.load_dataset("flights")
        dados=dados_brutos.pivot(index="month",columns="year",values="passengers")
        plt.figure(figsize=(8,5))
        sns.heatmap(data=dados,annot=False,fmt='d')
        #xx=[1.1,2.1]#2=e*cos(angulo)
        #yy=[1.1,2.1]#2=e*sin(angulo)
        e=1
        #angulo=atan2((yD-yO),(xD-xO))
        angulo=math.atan2((yy[1]-yy[0]),(xx[1]-xx[0]))
        sns.lineplot(x=xx,y=yy,size_norm=e)
        #sns.lineplot(x=[xx[0]+.2,xx[1]+.2],y=[yy[0]+.2,yy[1]+.2],size_norm=e)
        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo+5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo+5*pi/6)],cor);
        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo+5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo+5*math.pi/6)],size_norm=1)
        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo-5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo-5*pi/6)],cor);
        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo-5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo-5*math.pi/6)],size_norm=1)

        #g.map(plt.axhline, y=0.1, color="k", ls=":");
        plt.show()
        
    def plota_mapas_de_calor3(self,xx,yy,dados_brutos):
        import matplotlib.pyplot as plt
        import seaborn as sns
        from numpy import math
        #dados_brutos=sns.load_dataset("flights")
        dados=dados_brutos.pivot(index="xlon",columns="ylat",values="Energia")
        plt.figure(figsize=(8,5))
        sns.heatmap(data=dados,annot=False,fmt='d')
        #xx=[1.1,2.1]#2=e*cos(angulo)
        #yy=[1.1,2.1]#2=e*sin(angulo)
        #e=1
        e=math.sqrt((yy[1]-yy[0])**2,(xx[1]-xx[0])**2)
        #angulo=atan2((yD-yO),(xD-xO))
        angulo=math.atan2((yy[1]-yy[0]),(xx[1]-xx[0]))
        sns.lineplot(x=xx,y=yy,size_norm=e)
        #sns.lineplot(x=[xx[0]+.2,xx[1]+.2],y=[yy[0]+.2,yy[1]+.2],size_norm=e)
        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo+5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo+5*pi/6)],cor);
        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo+5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo+5*math.pi/6)],size_norm=1)
        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo-5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo-5*pi/6)],cor);
        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo-5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo-5*math.pi/6)],size_norm=1)

        #g.map(plt.axhline, y=0.1, color="k", ls=":");
        plt.show()
        
    def plota_mapa_de_calor(self,dados):
        import matplotlib.pyplot as plt
        import seaborn as sns
        #dados_brutos=sns.load_dataset("flights")
        #dados=dados_brutos.pivot(index="month",columns="year",values="passengers")
        plt.figure(figsize=(8,5))
        #sns.heatmap(data=dados,annot=True,fmt='d')
        sns.heatmap(data=dados)
        #sns.lineplot(x=1,y=1)
        plt.show()

    def plota_mapa_de_calor2(self,dados_brutos,m,ncelulas):
        import matplotlib.pyplot as plt
        import seaborn as sns
        import pandas as pd
        (lm,cm)=m.shape
        (ldb,cdb)=dados_brutos.shape
        xmin=float(min(m[:,0]))
        xmax=float(max(m[:,0]))
        ymin=float(min(m[:,1]))
        ymax=float(max(m[:,1]))
        #ncelulas=33
        cx=0
        x=[]
        valor=xmin*.9
        for ccdb in range(0,cdb):
            valor=valor+(xmax*1.1-xmin*.9)/ncelulas
            for cldb in range(0,ldb):
                if valor<1000:
                    x.append('_'+str(valor))
                else:
                    x.append(str(valor))
        #y=[]
        #valor=ymin*.9
        #for ccdb in range(0,cdb):
        #    valor=valor+(ymax*1.1-ymin*.9)/ncelulas
        #    for cldb in range(0,ldb):
        #        y.append(str(valor))
        
        #for ccx in range(ncelulas,2*ncelulas):
        #    x.append(str(valor))
        #for cc in range(2,ncelulas):
        #    for ccx in range((cc-1)*ncelulas,cc*ncelulas):
        #        x.append(x[cc-1])
        #    x.append(str(float(x[cc-1])+(xmax*1.1-xmin*.9)/ncelulas))
        #for cx in range(10,2*ncelulas):
        #    x.append(x[ccx-1])
        y=[]
        valor=ymin*.9
        #cab=99
        #y.append(str(valor))
        for cldb in range(0,ldb):
            valor=valor+(ymax*1.1-ymin*.9)/ncelulas
            if(valor>999):
                #y.append(str(cab)+'+_'+str(valor))
                y.append('_'+str(valor))
            else:
                #y.append(str(cab)+'_'+str(valor))
                y.append(str(valor))
            #cab=cab-1
        for ccdb in range(1,cdb):
            for cldb in range(0,ldb):
                y.append(y[cldb])
        e=[]
        #dados_brutos=dados_brutos*0
        #dados_brutos[0,1]=1
        for ccdb in range(0,cdb):
            for cldb in range(0,ldb):
                e.append(dados_brutos[cldb,ccdb])
        #        x.append(x[cx+ccx-1])
        #    cx=cx+ncelulas
        #dados={'xlon':['Bélgica','Índia','Brasil'],'ylat':['Bruxelas','Nova Delhi','Brasília'],'Energia':[123465,456789,987654]}
#        ir=len(x)-1
#        for i in range(0,len(x)):
#            temp=x[ir]
#            x[ir]=x[i]
#            x[ir]=temp
#            ir=ir-1
#        ir=len(y)-1
#        for i in range(0,len(y)):
#            temp=y[ir]
#            y[ir]=y[i]
#            y[ir]=temp
#            ir=ir-1
        ir=len(e)-1
        for i in range(0,len(e)):
            temp=e[ir]
            e[ir]=e[i]
            e[ir]=temp
            ir=ir-1
        dados={'xlon':x,'ylat':y,'Energia':e}
        dfb=pd.DataFrame(dados,columns=['xlon','ylat','Energia'])
        df=dfb.pivot(index='ylat',columns='xlon',values='Energia')
        #self.plota_mapa_de_calor(df)
        self.plota_mapa_de_calor3(df,m,ncelulas)
        #plt.show()
        return x,y,e#dados


    def converte_mapa_de_calor2(self,dados_brutos,m,ncelulas):
        import matplotlib.pyplot as plt
        import seaborn as sns
        import pandas as pd
        (lm,cm)=m.shape
        (ldb,cdb)=dados_brutos.shape
        xmin=float(min(m[:,0]))
        xmax=float(max(m[:,0]))
        ymin=float(min(m[:,1]))
        ymax=float(max(m[:,1]))
        #ncelulas=33
        cx=0
        x=[]
        valor=xmin*.9
        for ccdb in range(0,cdb):
            valor=valor+(xmax*1.1-xmin*.9)/ncelulas
            for cldb in range(0,ldb):
                x.append(str(valor))
        #y=[]
        #valor=ymin*.9
        #for ccdb in range(0,cdb):
        #    valor=valor+(ymax*1.1-ymin*.9)/ncelulas
        #    for cldb in range(0,ldb):
        #        y.append(str(valor))
        
        #for ccx in range(ncelulas,2*ncelulas):
        #    x.append(str(valor))
        #for cc in range(2,ncelulas):
        #    for ccx in range((cc-1)*ncelulas,cc*ncelulas):
        #        x.append(x[cc-1])
        #    x.append(str(float(x[cc-1])+(xmax*1.1-xmin*.9)/ncelulas))
        #for cx in range(10,2*ncelulas):
        #    x.append(x[ccx-1])
        y=[]
        valor=ymin*.9
        cab=99
        #y.append(str(valor))
        for cldb in range(0,ldb):
            valor=valor+(ymax*1.1-ymin*.9)/ncelulas
            if(valor>999):
                y.append(str(cab)+'__'+str(valor))
            else:
                y.append(str(cab)+'_'+str(valor))
#        yy=[]
#        cab=99
#        for cldb in range(ldb,0,-1):
#            yy.append(str(cab)+'+'+y[cldb])
#            cab=cab-1
        y=yy
        for ccdb in range(1,cdb):
            for cldb in range(0,ldb):
                y.append(y[cldb])
        e=[]
        #dados_brutos=dados_brutos*0
        #dados_brutos[0,1]=1
        for ccdb in range(0,cdb):
            for cldb in range(0,ldb):
                e.append(dados_brutos[cldb,ccdb])
        #        x.append(x[cx+ccx-1])
        #    cx=cx+ncelulas
        #dados={'xlon':['Bélgica','Índia','Brasil'],'ylat':['Bruxelas','Nova Delhi','Brasília'],'Energia':[123465,456789,987654]}
#        ir=len(x)-1
#        for i in range(0,len(x)):
#            temp=x[ir]
#            x[ir]=x[i]
#            x[ir]=temp
#            ir=ir-1
#        ir=len(y)-1
#        for i in range(0,len(y)):
#            temp=y[ir]
#            y[ir]=y[i]
#            y[ir]=temp
#            ir=ir-1
        ir=len(e)-1
        for i in range(0,len(e)):
            temp=e[ir]
            e[ir]=e[i]
            e[ir]=temp
            ir=ir-1
        dados={'xlon':x,'ylat':y,'Energia':e}
        dfb=pd.DataFrame(dados,columns=['xlon','ylat','Energia'])
        df=dfb.pivot(index='ylat',columns='xlon',values='Energia')
        #self.plota_mapa_de_calor(df)
        self.plota_mapa_de_calor3(df,m,ncelulas)
        #plt.show()
        return x,y,e,dados


    def plota_mapa_de_calor3(self,dados,m,ncelulas):
        import matplotlib.pyplot as plt
        import seaborn as sns
        #dados_brutos=sns.load_dataset("flights")
        #dados=dados_brutos.pivot(index="month",columns="year",values="passengers")
        plt.figure(figsize=(8,5))
        #sns.heatmap(data=dados,annot=True,fmt='d')
        print('dados=',dados)
        sns.heatmap(data=dados)
        xmin=float(min(m[:,0]))
        xmax=float(max(m[:,0]))
        ymin=float(min(m[:,1]))
        ymax=float(max(m[:,1]))
        #sns.lineplot(x=1,y=1)
#        xx=[m[0,0],m[0,0]*5]#2=e*cos(angulo)
#        yy=[m[0,1],m[0,1]*5]#2=e*sin(angulo)
#        e=1000
#        xx=[1.1,2.1]#2=e*cos(angulo)
#        yy=[1.1,2.1]#2=e*sin(angulo)
#        e=1        #angulo=atan2((yD-yO),(xD-xO))
#        xx=[3.00,4.00]#2=e*cos(angulo)
#        yy=[3.00,4.00]#2=e*sin(angulo)
#        e=5        #angulo=atan2((yD-yO),(xD-xO))
#        xx=[(33-1)*(m[3,0]-xmin)/(xmax-xmin)+1,(33-1)*(m[3,0]*1.1-xmin)/(xmax-xmin)+1]
#        yy=[(33-1)*(m[3,1]-ymin)/(ymax-ymin)+1,(33-1)*(m[3,1]*1.1-ymin)/(ymax-ymin)+1]
#        angulo=math.atan2((yy[1]-yy[0]),(xx[1]-xx[0]))
#        sns.lineplot(x=xx,y=yy,size_norm=e)
#        #sns.lineplot(x=[xx[0]+.2,xx[1]+.2],y=[yy[0]+.2,yy[1]+.2],size_norm=e)
#        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo+5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo+5*pi/6)],cor);
#        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo+5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo+5*math.pi/6)],size_norm=1)
#        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo-5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo-5*pi/6)],cor);
#        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo-5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo-5*math.pi/6)],size_norm=1)
        #xx=[1.1,2.1]#2=e*cos(angulo)
        #yy=[1.1,2.1]#2=e*sin(angulo)
#        xx=[294.40,294.40*1.5]
#        yy=[876.59,876.59*1.5]
#        e=1        #angulo=atan2((yD-yO),(xD-xO))
#        e=3
#        xx=[(33-1)*(m[0,0]-xmin)/(xmax-xmin)+1,(33-1)*(m[0,0]*1.1-xmin)/(xmax-xmin)+1]
#        yy=[(33-1)*(m[0,1]-ymin)/(ymax-ymin)+1,(33-1)*(m[0,1]*1.1-ymin)/(ymax-ymin)+1]
#        #xx=15-xx
#        #yy=15-yy
#        #xx=[10,15]
#        #yy=[20,25]
#        angulo=math.atan2((yy[1]-yy[0]),(xx[1]-xx[0]))
#        e=math.sqrt((yy[1]-yy[0])**2+(xx[1]-xx[0])**2)
#        sns.lineplot(x=xx,y=yy,size_norm=e)
#        print('xx=',xx,'yy=',yy)
#        #sns.lineplot(x=[xx[0]+.2,xx[1]+.2],y=[yy[0]+.2,yy[1]+.2],size_norm=e)
#        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo+5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo+5*pi/6)],cor);
#        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo+5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo+5*math.pi/6)],size_norm=1)
#        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo-5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo-5*pi/6)],cor);
#        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo-5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo-5*math.pi/6)],size_norm=1)
        #seta superior esquerda
        #xx=[(33-1)*(m[1,0]-xmin)/(xmax-xmin)+1,(33-1)*(m[1,0]*1.1-xmin)/(xmax-xmin)+1]
        ncel=5
        #xx=[(ncelulas-1)*(m[ncel,0]*1.1-xmin)/(xmax-xmin)+1,(ncelulas-1)*(m[ncel,0]-xmin)/(xmax-xmin)+1]
        #yy=[(ncelulas-1)*(m[ncel,1]-ymin)/(ymax-ymin)+1,(ncelulas-1)*(m[ncel,1]*1.1-ymin)/(ymax-ymin)+1]
        xx=[(ncelulas-1)*(m[ncel,0]-xmin)/(xmax-xmin)+1,m[ncel,2]*math.cos(m[ncel,4])+(ncelulas-1)*(m[ncel,0]-xmin)/(xmax-xmin)+1]
        yy=[(ncelulas-1)*(m[ncel,1]-ymin)/(ymax-ymin)+1,m[ncel,2]*math.sin(m[ncel,4])+(ncelulas-1)*(m[ncel,1]-ymin)/(ymax-ymin)+1]
        #xx=15-xx
        #yy=15-yy
        xx=[50,10]
        yy=[20,50]
        #xx=33-[xx[1],xx[0]]
        #xx=[xx[0]+25,xx[1]+25]
        #yy=[yy[1],yy[0]]
        angulo=math.atan2((yy[1]-yy[0]),(xx[1]-xx[0]))
        e=math.sqrt((yy[1]-yy[0])**2+(xx[1]-xx[0])**2)
        sns.lineplot(x=xx,y=yy,size_norm=e)
        print('xx=',xx,'yy=',yy)
        #sns.lineplot(x=[xx[0]+.2,xx[1]+.2],y=[yy[0]+.2,yy[1]+.2],size_norm=e)
        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo+5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo+5*pi/6)],cor);
        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo+5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo+5*math.pi/6)],size_norm=1)
        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo-5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo-5*pi/6)],cor);
        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo-5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo-5*math.pi/6)],size_norm=1)
        #seta embaixo à direita
        #xx=[(33-1)*(m[2,0]-xmin)/(xmax-xmin)+1,(33-1)*(m[2,0]*1.1-xmin)/(xmax-xmin)+1]
        ncel=9
        xx=[(ncelulas-1)*(m[ncel,0]*1.1-xmin)/(xmax-xmin)+1,(ncelulas-1)*(m[ncel,0]-xmin)/(xmax-xmin)+1]
        yy=[(ncelulas-1)*(m[ncel,1]-ymin)/(ymax-ymin)+1,(ncelulas-1)*(m[ncel,1]*1.1-ymin)/(ymax-ymin)+1]
        #xx=15-xx
        #yy=15-yy
        xx=[25,20]
        yy=[15,10]
        #xx=33-xx
        #xx=33-[xx[1],xx[0]]
        xx=[xx[0]-25,xx[1]-25]
        #yy=[yy[1],yy[0]]
        angulo=math.atan2((yy[1]-yy[0]),(xx[1]-xx[0]))
        e=math.sqrt((yy[1]-yy[0])**2+(xx[1]-xx[0])**2)
        sns.lineplot(x=xx,y=yy,size_norm=e)
        print('xx=',xx,'yy=',yy)
        #sns.lineplot(x=[xx[0]+.2,xx[1]+.2],y=[yy[0]+.2,yy[1]+.2],size_norm=e)
        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo+5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo+5*pi/6)],cor);
        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo+5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo+5*math.pi/6)],size_norm=1)
        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo-5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo-5*pi/6)],cor);
        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo-5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo-5*math.pi/6)],size_norm=1)
#        xx=[(33-1)*(m[3,0]-xmin)/(xmax-xmin)+1,(33-1)*(m[3,0]*1.1-xmin)/(xmax-xmin)+1]
#        yy=[(33-1)*(m[3,1]-ymin)/(ymax-ymin)+1,(33-1)*(m[3,1]*1.1-ymin)/(ymax-ymin)+1]
#        #xx=15-xx
#        #yy=15-yy
#        #xx=[10,15]
#        #yy=[20,25]
#        angulo=math.atan2((yy[1]-yy[0]),(xx[1]-xx[0]))
#        e=math.sqrt((yy[1]-yy[0])**2+(xx[1]-xx[0])**2)
#        sns.lineplot(x=xx,y=yy,size_norm=e)
#        print('xx=',xx,'yy=',yy)
#        #sns.lineplot(x=[xx[0]+.2,xx[1]+.2],y=[yy[0]+.2,yy[1]+.2],size_norm=e)
#        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo+5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo+5*pi/6)],cor);
#        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo+5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo+5*math.pi/6)],size_norm=1)
#        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo-5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo-5*pi/6)],cor);
#        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo-5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo-5*math.pi/6)],size_norm=1)
        #sns.axes_style()
        plt.show()
        #sns.
        #sns.color_palette()
        #sns.set_palettea()
        #sns.colors()
        
    def plota_exemplo(self):
        import matplotlib.pyplot as plt
        import seaborn as sns
        import pandas as pd
        #dados_brutos=sns.load_dataset("flights")
        #dados=dados_brutos.pivot(index="month",columns="year",values="passengers")
        data={'País':['Bélgica','Índia','Brasil'],'Capital':['Bruxelas','Nova Delhi','Brasília'],'População':[123465,456789,987654]}
        dfb=pd.DataFrame(data,columns=['País','Capital','População'])
        df=dfb.pivot(index='Capital',columns='País',values='População')
        self.plota_mapa_de_calor(df)

    def plota_exemplo2(self):
        import matplotlib.pyplot as plt
        import seaborn as sns
        import pandas as pd
        #dados_brutos=sns.load_dataset("flights")
        #dados=dados_brutos.pivot(index="month",columns="year",values="passengers")
        data={'x':['x1','x1','x1','x2','x2','x2','x3','x3','x3'],'y':['y1','y2','y3','y1','y2','y3','y1','y2','y3'],'z':[1,2,3,4,5,6,7,8,9]}
        #data={'x':['x1','x1','x1','x2','x2','x2','x3','x3','x3'],'y':['y3','y2','y1','y3','y2','y1','y3','y2','y1'],'z':[1,2,3,4,5,6,7,8,9]}
        #exec('data={\'x\':[\'x1\',\'x1\',\'x1\',\'x2\',\'x2\',\'x2\',\'x3\',\'x3\',\'x3\'],\'y\':[\'y3\',\'y2\',\'y1\',\'y3\',\'y2\',\'y1\',\'y3\',\'y2\',\'y1\'],\'z\':['+str(1)+','+str(2)+','+str(3)+','+str(4)+','+str(5)+','+str(6)+','+str(7)+','+str(8)+','+str(9)+']}')
        dfb=pd.DataFrame(data,columns=['x','y','z'])
        df=dfb.pivot(index='y',columns='x',values='z')
        self.plota_mapa_de_calor(df)

    def plota_exemplo3(self): 
        import matplotlib.pyplot as plt
        import seaborn as sns
        sns.set()
        # Load the example flights dataset and conver to long-form
        flights_long = sns.load_dataset("flights")
        flights = flights_long.pivot("month", "year", "passengers")
        # Draw a heatmap with the numeric values in each cell
        f, ax = plt.subplots(figsize=(9, 6))
        sns.heatmap(flights, annot=True, fmt="d", linewidths=.5, ax=ax)
        return f,ax
    
    
    
    def plota_exemplo4(self,x,y,dados):
        import matplotlib.pyplot as plt
        import seaborn as sns
        import pandas as pd
        #dados_brutos=sns.load_dataset("flights")
        #dados=dados_brutos.pivot(index="month",columns="year",values="passengers")
        #data={'x':['x1','x1','x1','x2','x2','x2','x3','x3','x3'],'y':['y1','y2','y3','y1','y2','y3','y1','y2','y3'],'z':[1,2,3,4,5,6,7,8,9]}
        data={'x':x,'y':y,'z':dados}#funcionou
        #data={'x':[x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],x[8]],'y':[y[0],y[1],y[2],y[3],y[4],y[5],y[6],y[7],y[8]],'z':[dados[0],dados[1],dados[2],dados[3],dados[4],dados[5],dados[6],dados[7],dados[8]]}#funcionou
        #data={'x':['x1','x1','x1','x2','x2','x2','x3','x3','x3'],'y':['y3','y2','y1','y3','y2','y1','y3','y2','y1'],'z':[1,2,3,4,5,6,7,8,9]}
        #exec('data={\'x\':[\'x1\',\'x1\',\'x1\',\'x2\',\'x2\',\'x2\',\'x3\',\'x3\',\'x3\'],\'y\':[\'y3\',\'y2\',\'y1\',\'y3\',\'y2\',\'y1\',\'y3\',\'y2\',\'y1\'],\'z\':['+str(1)+','+str(2)+','+str(3)+','+str(4)+','+str(5)+','+str(6)+','+str(7)+','+str(8)+','+str(9)+']}')
        dfb=pd.DataFrame(data,columns=['x','y','z'])
        df=dfb.pivot(index='y',columns='x',values='z')
        self.plota_mapa_de_calor(df)


    def plota_exemplo5(self):
        import matplotlib.pyplot as plt
        import seaborn as sns
        import pandas as pd
        #dados_brutos=sns.load_dataset("flights")
        #dados=dados_brutos.pivot(index="month",columns="year",values="passengers")
        data={'x':['x1','x1','x1','x2','x2','x2','x3','x3','x3'],'y':['y1','y2','y3','y1','y2','y3','y1','y2','y3'],'z':[1,2,3,4,5,6,7,8,9]}
        #data={'x':['x1','x1','x1','x2','x2','x2','x3','x3','x3'],'y':['y3','y2','y1','y3','y2','y1','y3','y2','y1'],'z':[1,2,3,4,5,6,7,8,9]}
        #exec('data={\'x\':[\'x1\',\'x1\',\'x1\',\'x2\',\'x2\',\'x2\',\'x3\',\'x3\',\'x3\'],\'y\':[\'y3\',\'y2\',\'y1\',\'y3\',\'y2\',\'y1\',\'y3\',\'y2\',\'y1\'],\'z\':['+str(1)+','+str(2)+','+str(3)+','+str(4)+','+str(5)+','+str(6)+','+str(7)+','+str(8)+','+str(9)+']}')
        dfb=pd.DataFrame(data,columns=['x','y','z'])
        df=dfb.pivot(index='y',columns='x',values='z')
        self.plota_mapa_de_calor(df)


        xx=[1.1,2.1]#2=e*cos(angulo)
        yy=[1.1,2.1]#2=e*sin(angulo)
#        xx=[294.40,294.40*1.5]
#        yy=[876.59,876.59*1.5]
#        e=1        #angulo=atan2((yD-yO),(xD-xO))
#        e=3
#        xx=[(33-1)*(m[0,0]-xmin)/(xmax-xmin)+1,(33-1)*(m[0,0]*1.1-xmin)/(xmax-xmin)+1]
#        yy=[(33-1)*(m[0,1]-ymin)/(ymax-ymin)+1,(33-1)*(m[0,1]*1.1-ymin)/(ymax-ymin)+1]
#        #xx=15-xx
#        #yy=15-yy
#        #xx=[10,15]
#        #yy=[20,25]
#        angulo=math.atan2((yy[1]-yy[0]),(xx[1]-xx[0]))
#        e=math.sqrt((yy[1]-yy[0])**2+(xx[1]-xx[0])**2)
#        sns.lineplot(x=xx,y=yy,size_norm=e)
#        print('xx=',xx,'yy=',yy)
#        #sns.lineplot(x=[xx[0]+.2,xx[1]+.2],y=[yy[0]+.2,yy[1]+.2],size_norm=e)
#        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo+5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo+5*pi/6)],cor);
#        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo+5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo+5*math.pi/6)],size_norm=1)
#        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo-5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo-5*pi/6)],cor);
#        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo-5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo-5*math.pi/6)],size_norm=1)
        #seta superior esquerda
        #xx=[(33-1)*(m[1,0]-xmin)/(xmax-xmin)+1,(33-1)*(m[1,0]*1.1-xmin)/(xmax-xmin)+1]
        xx=[(33-1)*(m[1,0]*1.1-xmin)/(xmax-xmin)+1,(33-1)*(m[1,0]-xmin)/(xmax-xmin)+1]
        yy=[(33-1)*(m[1,1]-ymin)/(ymax-ymin)+1,(33-1)*(m[1,1]*1.1-ymin)/(ymax-ymin)+1]
        #xx=15-xx
        #yy=15-yy
        #xx=[10,15]
        #yy=[20,25]
        #xx=33-[xx[1],xx[0]]
        xx=[xx[0]+25,xx[1]+25]
        #yy=[yy[1],yy[0]]
        angulo=math.atan2((yy[1]-yy[0]),(xx[1]-xx[0]))
        e=math.sqrt((yy[1]-yy[0])**2+(xx[1]-xx[0])**2)
        sns.lineplot(x=xx,y=yy,size_norm=e)
        print('xx=',xx,'yy=',yy)
        #sns.lineplot(x=[xx[0]+.2,xx[1]+.2],y=[yy[0]+.2,yy[1]+.2],size_norm=e)
        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo+5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo+5*pi/6)],cor);
        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo+5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo+5*math.pi/6)],size_norm=1)
        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo-5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo-5*pi/6)],cor);
        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo-5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo-5*math.pi/6)],size_norm=1)
        #seta embaixo à direita
        #xx=[(33-1)*(m[2,0]-xmin)/(xmax-xmin)+1,(33-1)*(m[2,0]*1.1-xmin)/(xmax-xmin)+1]
        xx=[(33-1)*(m[2,0]*1.1-xmin)/(xmax-xmin)+1,(33-1)*(m[2,0]-xmin)/(xmax-xmin)+1]
        yy=[(33-1)*(m[2,1]-ymin)/(ymax-ymin)+1,(33-1)*(m[2,1]*1.1-ymin)/(ymax-ymin)+1]
        #xx=15-xx
        #yy=15-yy
        #xx=[25,20]
        #yy=[15,10]
        #xx=33-xx


        xx=[xx[0]-25,xx[1]-25]
        #yy=[yy[1],yy[0]]
        angulo=math.atan2((yy[1]-yy[0]),(xx[1]-xx[0]))
        e=math.sqrt((yy[1]-yy[0])**2+(xx[1]-xx[0])**2)
        sns.lineplot(x=xx,y=yy,size_norm=e)
        print('xx=',xx,'yy=',yy)
        #sns.lineplot(x=[xx[0]+.2,xx[1]+.2],y=[yy[0]+.2,yy[1]+.2],size_norm=e)
        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo+5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo+5*pi/6)],cor);
        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo+5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo+5*math.pi/6)],size_norm=1)
        #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo-5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo-5*pi/6)],cor);
        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo-5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo-5*math.pi/6)],size_norm=1)

#function [r]=coef_correlacao(peso,altura)
#xb=sum(peso)/length(peso);yb=sum(altura)/length(altura);
#r=sum((peso-xb).*(altura-yb))/sqrt(sum((peso-xb).^2)*sum((altura-yb).^2));
    def extrai_pontos(self,ncelulas):
        #m=matrix([[294.40,876.59,5000,7e4],#xlon,ylat,E,var,D
        #          [294.40,276.59,5000,7e3],
        #          [404.40,576.59,5000,7e3],
        #     [442.93,875.61,5000,7e4],
        #     [446.85,741.11,5000,7e4]])#C3_7x5
#        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
#                  #[294.40,276.59,5000,7e1]#,
#                  #[404.40,576.59,5000,7e3]#,
#             #[442.93,875.61,5000,7e3]#,
#             #[446.85,741.11,5000,7e4]])#C3_7x5
#             [880,440,5000,7e2],
#             [440,880,5000,7e2],
#             [440,440,5000,7e3],
#             [880,880,5000,7e2]
#             ])
#        var1=7e1
#        var2=7e3
#        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
#                  #[294.40,276.59,5000,7e1]#,
#                  #[404.40,576.59,5000,7e3]#,
#             #[442.93,875.61,5000,7e3]#,
#             #[446.85,741.11,5000,7e4]])#C3_7x5
#             [880,440,5000,var2],
#             [440,880,5000,var1],
#             [440,440,5000,var1],
#             [880,880,5000,var1]
#             ])
#        var1=7e-1
#        var2=7e-1
#        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
#                   #[294.40,276.59,5000,7e1]#,
#                   #[404.40,576.59,5000,7e3]#,
#              #[442.93,875.61,5000,7e3]#,
#              #[446.85,741.11,5000,7e4]])#C3_7x5
#              [1.1601,0.7288,2.4379,var1,-0.0024],
#              [1.0761,1.1687,3.4757,var1,-0.0016],
#              [1.2722,0.8977,3.6822,var2,-0.0003],
#              [1.3343,0.8655,2.8989,var2,-0.0018],
#              [1.4799,0.8717,3.9109,var2,0.0031],
#              [3.0293,1.2215,5.0887,var2,-0.0028],
#              [1.1608,0.7276,3.7854,var2,-0.0027],
#              [1.2359,0.7239,3.1507,var2,-0.0009],
#              [1.2760,0.6455,2.8063,var2,-0.0018],
#              [1.3505,0.8710,4.5099,var2,0.0022],
#              [1.1397,0.6941,3.6077,var2,0.0006],
#              [1.5543,0.6872,4.0385,var2,0.0029],
#              [1.6899,0.2857,4.1559,var1,0.0021]
#              ])
        var1=1e6
        var2=1e6
        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
                  #[294.40,276.59,5000,7e1]#,
                  #[404.40,576.59,5000,7e3]#,
             #[442.93,875.61,5000,7e3]#,
             #[446.85,741.11,5000,7e4]])#C3_7x5
             [1160.1,728.8,2437.9,var1,-2.4],
             [1076.1,1168.7,3475.7,var1,-1.6],
             [1272.2,897.7,3682.2,var2,-0.3],
             [1334.3,865.5,2898.9,var2,-1.8],
             [1479.9,871.7,3910.9,var2,3.1],
             [3029.3,1221.5,5088.7,var2,-2.8],
             [1160.8,727.6,3785.4,var2,-2.7],
             [1235.9,723.9,3150.7,var2,-0.9],
             [1276.0,645.5,2806.3,var2,-1.8],
             [1350.5,871.0,4509.9,var2,2.2],
             [1139.7,694.1,3607.7,var2,0.6],
             [1554.3,687.2,4038.5,var2,2.9],
             [1689.9,285.7,4155.9,var1,2.1]
             ])
        #m=matrix([[1555.04,690.13,4699.612806597489,7e3,2.8896096688675086],#0_1
        #          [1555.04,690.13,742.8886410821425,7e3,2.8896096688675086],#1_1
        #          [1555.04,690.13,5271.083729712643,7e3,2.8896096688675086],#2_1
        #          [1555.04,690.13,2725.239656558208,7e3,2.8896096688675086],#3_1
        #          [1555.04,690.13,1044.9348806980345,7e3,2.8896096688675086],#4_1
        #          [1555.04,690.13,5623.1102290741765,7e3,2.8896096688675086],#5_1
        #          [0,0,0,0,0],#6_1
        #          [1555.04,690.13,1766.511028259003,7e3,2.8896096688675086],#7_1
        #          [0,0,0,0,0],#8_1
        #          [1555.04,690.13,4503.995771674371,7e3,2.8896096688675086],#9_1
        #          [0,0,0,0,0],#10_1
        ##          [1555.04,690.13,1241.2930646677798,7e3,2.8896096688675086],#11_1
        #         [0,0,0,0,0],#12_1
        #         [0,0,0,0,0]])#13_1
        xmin=float(min(m[:,0]))
        xmax=float(max(m[:,0]))
        ymin=float(min(m[:,1]))
        ymax=float(max(m[:,1]))
        (linhas,colunas)=m.shape
        #ncelulas=33
        #dados_brutos=matlib.zeros((ncelulas*linhas,ncelulas*linhas))
        dados_brutos=matlib.zeros((ncelulas,ncelulas))
        ncoluna=0
        #lin=ymax*1.1
        lin=ymin*.9
        #for lin in range(ymax*1.1,ymin*.9,-(ymax*1.1-ymin*.9)/ncelulas):
        for clin in range(0,ncelulas):
            lin=lin+(ymax*1.1-ymin*.9)/ncelulas
            nlinha=0
            col=xmin*.9
            #for col in range(xmin*.9,xmax*1.1,(xmax*1.1-xmin*.9)/ncelulas):
            for ccol in range(0,ncelulas):
                col=col+(xmax*1.1-xmin*.9)/ncelulas
                linha=0
                dados_brutos[nlinha,ncoluna]=m[linha,2]*math.exp(-(lin-m[linha,0])**2/m[linha,3])*math.exp(-(col-m[linha,1])**2/m[linha,3])
                #print(dados_brutos[nlinha,ncoluna])
                for linha in range(1,linhas):
                    dados_brutos[nlinha,ncoluna]=dados_brutos[nlinha,ncoluna]+m[linha,2]*math.exp(-(lin-m[linha,0])**2/m[linha,3])*math.exp(-(col-m[linha,1])**2/m[linha,3])
                    #print(dados_brutos[nlinha,ncoluna])
                dados_brutos[nlinha,ncoluna]=dados_brutos[nlinha,ncoluna]/linhas
                nlinha=nlinha+1
            ncoluna=ncoluna+1
        #dfb=pd.DataFrame(data,columns=['x','y','z'])
        #exec('data={\'x\':[\'x1\',\'x1\',\'x1\',\'x2\',\'x2\',\'x2\',\'x3\',\'x3\',\'x3\'],\'y\':[\'y3\',\'y2\',\'y1\',\'y3\',\'y2\',\'y1\',\'y3\',\'y2\',\'y1\'],\'z\':[1,2,3,4,5,6,7,8,9]}')
        #df=dfb.pivot(index='y',columns='x',values='z')
        #self.plota_mapa_de_calor(df)
        return dados_brutos,m
        

        
    def mapa_de_calor(self,ncelulas):
        #ncelulas=33
        (dados_brutos,m)=self.extrai_pontos(ncelulas)
        self.plota_mapa_de_calor2(dados_brutos,m,ncelulas)
        return dados_brutos,m

    
    def mapa_de_calor2(self,ncelulas):
        #ncelulas=33
        (dados_brutos,m)=self.extrai_pontos(ncelulas)
        (x,y,e,dados)=self.converte_mapa_de_calor2(dados_brutos,m,ncelulas)
        self.plota_mapas_de_calor3([1.1,2.1],[1.1,2.1],dados)
        self.plota_mapas_de_calor3([2.2,4.2],[2.2,4.2],dados)
        self.plota_mapas_de_calor3([.55,1.05],[.55,1.05],dados)
        #self.plota_mapa_de_calor2(dados_brutos,m,ncelulas)
        return dados_brutos,m
    
    def extrai_pontos2(self,ncelulas,narquivo):
        #narquivo=0
        #for cncross in range(0,len(l18)):
        for cncross in range(0,1):
            exec('arquivoT'+str(cncross)+'=open(\'c:\\\\install\\\\sumo\\\\tutorial_04ceem4vC1vC2kC3kE\\\\dadostraci1201e2e3sc2\\\\aT'+str(cncross)+'_'+str(narquivo)+'.m\',\'r\')')
            exec('arquivoV'+str(cncross)+'=open(\'c:\\\\install\\\\sumo\\\\tutorial_04ceem4vC1vC2kC3kE\\\\dadostraci1201e2e3sc2\\\\aV'+str(cncross)+'_'+str(narquivo)+'.m\',\'r\')')
            exec('arquivoO'+str(cncross)+'=open(\'c:\\\\install\\\\sumo\\\\tutorial_04ceem4vC1vC2kC3kE\\\\dadostraci1201e2e3sc2\\\\aO'+str(cncross)+'_'+str(narquivo)+'.m\',\'r\')')
            exec('arquivoD'+str(cncross)+'=open(\'c:\\\\install\\\\sumo\\\\tutorial_04ceem4vC1vC2kC3kE\\\\dadostraci1201e2e3sc2\\\\aD'+str(cncross)+'_'+str(narquivo)+'.m\',\'r\')')
            exec('arquivoY'+str(cncross)+'=open(\'c:\\\\install\\\\sumo\\\\tutorial_04ceem4vC1vC2kC3kE\\\\dadostraci1201e2e3sc2\\\\aY'+str(cncross)+'_'+str(narquivo)+'.m\',\'r\')')
            exec('arquivoE'+str(cncross)+'=open(\'c:\\\\install\\\\sumo\\\\tutorial_04ceem4vC1vC2kC3kE\\\\dadostraci1201e2e3sc2\\\\aE'+str(cncross)+'_'+str(narquivo)+'.m\',\'r\')')
            exec('arquivoxlon'+str(cncross)+'=open(\'c:\\\\install\\\\sumo\\\\tutorial_04ceem4vC1vC2kC3kE\\\\dadostraci1201e2e3sc2\\\\axlon'+str(cncross)+'_'+str(narquivo)+'.m\',\'r\')')
            exec('arquivoylat'+str(cncross)+'=open(\'c:\\\\install\\\\sumo\\\\tutorial_04ceem4vC1vC2kC3kE\\\\dadostraci1201e2e3sc2\\\\aylat'+str(cncross)+'_'+str(narquivo)+'.m\',\'r\')')
            #for cncross in range(0,len(l18)):
        exec('MaT=[]')
        exec('MaV=[]')
        exec('MaO=[]')
        exec('MaD=[]')
        exec('MaY=[]')
        exec('MaE=[]')
        exec('Maxlon=[]')
        exec('Maylat=[]')
        exec('aT'+str(cncross)+'=arquivoT'+str(cncross)+'.readline()')
        exec('aV'+str(cncross)+'=arquivoV'+str(cncross)+'.readline()')
        exec('aO'+str(cncross)+'=arquivoO'+str(cncross)+'.readline()')
        exec('aD'+str(cncross)+'=arquivoD'+str(cncross)+'.readline()')
        exec('aY'+str(cncross)+'=arquivoY'+str(cncross)+'.readline()')
        exec('aE'+str(cncross)+'=arquivoE'+str(cncross)+'.readline()')
        exec('axlon'+str(cncross)+'=arquivoxlon'+str(cncross)+'.readline()')
        exec('aylat'+str(cncross)+'=arquivoylat'+str(cncross)+'.readline()')
        exec('MaT.append(aT'+str(cncross)+')')
        exec('MaV.append(aV'+str(cncross)+')')
        exec('MaO.append(aO'+str(cncross)+')')
        exec('MaD.append(aD'+str(cncross)+')')
        exec('MaY.append(aY'+str(cncross)+')')
        exec('MaE.append(aE'+str(cncross)+')')
        exec('Maxlon.append(axlon'+str(cncross)+')')
        exec('Maylat.append(aylat'+str(cncross)+')')
        for cncross in range(0,1):
            exec('aT'+str(cncross)+'=arquivoT'+str(cncross)+'.readline()')
            exec('aV'+str(cncross)+'=arquivoV'+str(cncross)+'.readline()')
            exec('aO'+str(cncross)+'=arquivoO'+str(cncross)+'.readline()')
            exec('aD'+str(cncross)+'=arquivoD'+str(cncross)+'.readline()')
            exec('aY'+str(cncross)+'=arquivoY'+str(cncross)+'.readline()')
            exec('aE'+str(cncross)+'=arquivoE'+str(cncross)+'.readline()')
            exec('axlon'+str(cncross)+'=arquivoxlon'+str(cncross)+'.readline()')
            exec('aylat'+str(cncross)+'=arquivoylat'+str(cncross)+'.readline()')
            exec('MaT.append(aT'+str(cncross)+')')
            exec('MaV.append(aV'+str(cncross)+')')
            exec('MaO.append(aO'+str(cncross)+')')
            exec('MaD.append(aD'+str(cncross)+')')
            exec('MaY.append(aY'+str(cncross)+')')
            exec('MaE.append(aE'+str(cncross)+')')
            exec('Maxlon.append(axlon'+str(cncross)+')')
            exec('Maylat.append(aylat'+str(cncross)+')')
        exec('arquivoT'+str(cncross)+'.close()')
        exec('arquivoV'+str(cncross)+'.close()')
        exec('arquivoO'+str(cncross)+'.close()')
        exec('arquivoD'+str(cncross)+'.close()')
        exec('arquivoY'+str(cncross)+'.close()')
        exec('arquivoE'+str(cncross)+'.close()')
        exec('arquivoxlon'+str(cncross)+'.close()')
        exec('arquivoylat'+str(cncross)+'.close()')
        exec('print(MaT)')
        narquivo+=1
       #m=matrix([[294.40,876.59,5000,7e4],#xlon,ylat,E,var(desv.p.),D
        #          [294.40,276.59,5000,7e3],
        #          [404.40,576.59,5000,7e3],
        #     [442.93,875.61,5000,7e4],
        #     [446.85,741.11,5000,7e4]])#C3_7x5
        #return MaT,MaV,MaO,MaD,MaY,MaE,Mxlon,Mylat

    def extrai_pontos3(self,ncelulas,narquivo,S1,S2,S3,S4,S5,S6,S7,S8):
        #narquivo=0
        #for cncross in range(0,len(l18)):
        #for cncross in range(0,1):
        MaT=[]
        MaV=[]
        MaO=[]
        MaD=[]
        MaY=[]
        MaE=[]
        Maxlon=[]
        Maylat=[]
        arquivoT=open(S1)
        arquivoV=open(S2)
        arquivoO=open(S3)
        arquivoD=open(S4)
        arquivoY=open(S5)
        arquivoE=open(S6)
        arquivoxlon=open(S7)
        arquivoylat=open(S8)
        #for cncross in range(0,len(l18)):
        for l1 in arquivoT:
            MaT.append(arquivoT.readline())
        for l2 in arquivoV:
            MaV.append(arquivoV.readline())
        for l3 in arquivoO:
            MaO.append(arquivoO.readline())
        for l4 in arquivoD:
            MaD.append(arquivoD.readline())
        for l5 in arquivoY:
            MaY.append(arquivoY.readline())
        for l6 in arquivoE:
            MaE.append(arquivoE.readline())
        for l7 in arquivoxlon:
            Maxlon.append(arquivoxlon.readline())
        for l8 in arquivoylat:
            Maylat.append(arquivoylat.readline())
       #m=matrix([[294.40,876.59,5000,7e4],#xlon,ylat,E,var(desv.p.),D
        #          [294.40,276.59,5000,7e3],
        #          [404.40,576.59,5000,7e3],
        #     [442.93,875.61,5000,7e4],
        #     [446.85,741.11,5000,7e4]])#C3_7x5
        #return aT,aV,aO,aD,aY,aE,axlon,aylat
        return MaT,MaV,MaO,MaD,MaY,MaE,Maxlon,Maylat


    def extrai_pontos4(self,ncelulas):
        #narquivo=0
        #for cncross in range(0,len(l18)):
        #for cncross in range(0,1):
        cncross=0
        narquivo=0

        #S1='c:\\\\install\\\\sumo\\\\tutorial_04ceem4vC1vC2kC3kE\\\\dadostraci1201e2e3sc2\\\\aT'+str(cncross)+'_'+str(narquivo)+'.m'
        #arquivoT=open(S1)
        #for line in arquivoT:
        S1='c:\\\\install\\\\sumo\\\\tutorial_04ceem4vC1vC2kC3kE\\\\dadostraci1201e2e3sc2\\\\aT'+str(cncross)+'_'+str(narquivo)+'.m'
        S2='c:\\\\install\\\\sumo\\\\tutorial_04ceem4vC1vC2kC3kE\\\\dadostraci1201e2e3sc2\\\\aV'+str(cncross)+'_'+str(narquivo)+'.m'
        S3='c:\\\\install\\\\sumo\\\\tutorial_04ceem4vC1vC2kC3kE\\\\dadostraci1201e2e3sc2\\\\aO'+str(cncross)+'_'+str(narquivo)+'.m'
        S4='c:\\\\install\\\\sumo\\\\tutorial_04ceem4vC1vC2kC3kE\\\\dadostraci1201e2e3sc2\\\\aD'+str(cncross)+'_'+str(narquivo)+'.m'
        S5='c:\\\\install\\\\sumo\\\\tutorial_04ceem4vC1vC2kC3kE\\\\dadostraci1201e2e3sc2\\\\aY'+str(cncross)+'_'+str(narquivo)+'.m'
        S6='c:\\\\install\\\\sumo\\\\tutorial_04ceem4vC1vC2kC3kE\\\\dadostraci1201e2e3sc2\\\\aE'+str(cncross)+'_'+str(narquivo)+'.m'
        S7='c:\\\\install\\\\sumo\\\\tutorial_04ceem4vC1vC2kC3kE\\\\dadostraci1201e2e3sc2\\\\axlon'+str(cncross)+'_'+str(narquivo)+'.m'
        S8='c:\\\\install\\\\sumo\\\\tutorial_04ceem4vC1vC2kC3kE\\\\dadostraci1201e2e3sc2\\\\aylat'+str(cncross)+'_'+str(narquivo)+'.m'
        (aT,aV,aO,aD,aY,aE,axlon,aylat)=self.extrai_pontos3(ncelulas,narquivo,S1,S2,S3,S4,S5,S6,S7,S8)
        #if narquivo>=1:
         #   MaT.append(aT)
          #  MaV.append(aV)
         #   MaO.append(aO)
         #   MaD.append(aD)
         #   MaY.append(aY)
         #   MaE.append(aE)
         #   Maxlon.append(axlon)
         #   Maylat.append(aylat)
        #narquivo=narquivo+1
       #m=matrix([[294.40,876.59,5000,7e4],#xlon,ylat,E,var(desv.p.),D
        #          [294.40,276.59,5000,7e3],
        #          [404.40,576.59,5000,7e3],
        #     [442.93,875.61,5000,7e4],
        #     [446.85,741.11,5000,7e4]])#C3_7x5
        #return MaT,MaV,MaO,MaD,MaY,MaE,Maxlon,Maylat
        return aT,aV,aO,aD,aY,aE,axlon,aylat
    
    
    def extrai_pontos5(self,ncelulas):
        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
                  #[294.40,276.59,5000,7e1]#,
                  #[404.40,576.59,5000,7e3]#,
             #[442.93,875.61,5000,7e3]#,
             #[446.85,741.11,5000,7e4]])#C3_7x5
             [880,440,5000,7e2],
             [440,880,5000,7e2],
             [440,440,5000,7e3],
             [880,880,5000,7e2]
             ])
        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
                  #[294.40,276.59,5000,7e1]#,
                  #[404.40,576.59,5000,7e3]#,
             #[442.93,875.61,5000,7e3]#,
             #[446.85,741.11,5000,7e4]])#C3_7x5
             [1.1601,0.7288,2.4379,7e2,-0.0024],
             [1.0761,1.1687,3.4757,7e2,-0.0016],
             [1.2722,0.8977,3.6822,7e3,-0.0003],
             [1.3343,0.8655,2.8989,7e3,-0.0018],
             [1.4799,0.8717,3.9109,7e3,0.0031],
             [3.0293,1.2215,5.0887,7e3,-0.0028],
             [1.1608,0.7276,3.7854,7e3,-0.0027],
             [1.2359,0.7239,3.1507,7e3,-0.0009],
             [1.2760,0.6455,2.8063,7e3,-0.0018],
             [1.3505,0.8710,4.5099,7e3,0.0022],
             [1.1397,0.6941,3.6077,7e3,0.0006],
             [1.5543,0.6872,4.0385,7e3,0.0029],
             [1.6899,0.2857,4.1559,7e2,0.0021]
             ])
        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
                  #[294.40,276.59,5000,7e1]#,
                  #[404.40,576.59,5000,7e3]#,
             #[442.93,875.61,5000,7e3]#,
             #[446.85,741.11,5000,7e4]])#C3_7x5
             [1160.1,728.8,2437.9,7e2,-2.4],
             [1076.1,1168.7,3475.7,7e2,-1.6],
             [1272.2,897.7,3682.2,7e3,-0.3],
             [1334.3,865.5,2898.9,7e3,-1.8],
             [1479.9,871.7,3910.9,7e3,3.1],
             [3029.3,1221.5,5088.7,7e3,-2.8],
             [1160.8,727.6,3785.4,7e3,-2.7],
             [1235.9,723.9,3150.7,7e3,-0.9],
             [1276.0,645.5,2806.3,7e3,-1.8],
             [1350.5,871.0,4509.9,7e3,2.2],
             [1139.7,694.1,3607.7,7e3,0.6],
             [1554.3,687.2,4038.5,7e3,2.9],
             [1689.9,285.7,4155.9,7e2,2.1]
             ])
        #m=matrix([[1555.04,690.13,4699.612806597489,7e3,2.8896096688675086],#0_1
        #          [1555.04,690.13,742.8886410821425,7e3,2.8896096688675086],#1_1
        #          [1555.04,690.13,5271.083729712643,7e3,2.8896096688675086],#2_1
        #          [1555.04,690.13,2725.239656558208,7e3,2.8896096688675086],#3_1
        #          [1555.04,690.13,1044.9348806980345,7e3,2.8896096688675086],#4_1
        #          [1555.04,690.13,5623.1102290741765,7e3,2.8896096688675086],#5_1
        #          [0,0,0,0,0],#6_1
        #          [1555.04,690.13,1766.511028259003,7e3,2.8896096688675086],#7_1
        #          [0,0,0,0,0],#8_1
        #          [1555.04,690.13,4503.995771674371,7e3,2.8896096688675086],#9_1
        #          [0,0,0,0,0],#10_1
        ##          [1555.04,690.13,1241.2930646677798,7e3,2.8896096688675086],#11_1
         #         [0,0,0,0,0],#12_1
         #         [0,0,0,0,0]])#13_1
        xmin=float(min(m[:,0]))
        xmax=float(max(m[:,0]))
        ymin=float(min(m[:,1]))
        ymax=float(max(m[:,1]))
        (linhas,colunas)=m.shape
        #ncelulas=33
        #dados_brutos=matlib.zeros((ncelulas*linhas,ncelulas*linhas))
        dados_brutos=matlib.zeros((ncelulas,ncelulas))
        ncoluna=0
        lin=ymax*1.1
        #for lin in range(ymax*1.1,ymin*.9,-(ymax*1.1-ymin*.9)/ncelulas):
        for clin in range(0,ncelulas):
            lin=lin-(ymax*1.1-ymin*.9)/ncelulas
            nlinha=0
            col=xmin*.9
            #for col in range(xmin*.9,xmax*1.1,(xmax*1.1-xmin*.9)/ncelulas):
            for ccol in range(0,ncelulas):
                col=col+(xmax*1.1-xmin*.9)/ncelulas
                linha=0
                dados_brutos[nlinha,ncoluna]=m[linha,2]*math.exp(-(lin-m[linha,0])**2/m[linha,3])*math.exp(-(col-m[linha,1])**2/m[linha,3])
                #print(dados_brutos[nlinha,ncoluna])
                for linha in range(1,linhas):
                    dados_brutos[nlinha,ncoluna]=dados_brutos[nlinha,ncoluna]+m[linha,2]*math.exp(-(lin-m[linha,0])**2/m[linha,3])*math.exp(-(col-m[linha,1])**2/m[linha,3])
                    #print(dados_brutos[nlinha,ncoluna])
                dados_brutos[nlinha,ncoluna]=dados_brutos[nlinha,ncoluna]/linhas
                nlinha=nlinha+1
            ncoluna=ncoluna+1
        #dfb=pd.DataFrame(data,columns=['x','y','z'])
        #exec('data={\'x\':[\'x1\',\'x1\',\'x1\',\'x2\',\'x2\',\'x2\',\'x3\',\'x3\',\'x3\'],\'y\':[\'y3\',\'y2\',\'y1\',\'y3\',\'y2\',\'y1\',\'y3\',\'y2\',\'y1\'],\'z\':[1,2,3,4,5,6,7,8,9]}')
        #df=dfb.pivot(index='y',columns='x',values='z')
        #self.plota_mapa_de_calor(df)
        return dados_brutos,m

    
    def coef_correlacao(self,peso,altura):
        from numpy import matlib
        xb=matlib.sum(peso)/max(peso.shape)
        yb=matlib.sum(altura)/max(altura.shape)
        r=matlib.sum(self.produtott(peso-xb,altura-yb))/math.sqrt(matlib.sum(self.produtott(peso-xb,peso-xb))*matlib.sum(self.produtott(altura-yb,altura-yb)))
        return r
        
    def produtott(self,a,b):
        [la,ca]=a.shape
        c=matlib.zeros((la,ca))
        for cla in range(0,la):
            for cca in range(0,ca):
                c[cla,cca]=a[cla,cca]*b[cla,cca]
        return c
    
    def calculaAB(self,x,y):
        from numpy import matlib
        n=max(x.shape)
        a=(n*matlib.sum(self.produtott(x,y))-matlib.sum(x)*matlib.sum(y))/(n*matlib.sum(self.produtott(x,x))-matlib.sum(x)*matlib.sum(x))
        b=(matlib.sum(y)-a*matlib.sum(x))/n
        return a,b
    
    def teste_calculaAB(self):
        x=matrix([np.linspace(0,10,11)])
        y=x+1
        (a,b)=self.calculaAB(x,y)
        print('a=',a,'b=',b)
        
    def le_arquivo(self):
        arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3kE\\floresta2.net.xml','r')
        #arquivoTT.close()
       #arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3k\\dadostraci1201e2e3sc\\aT1_'+str(narquivo)+'.m','a+')
        texto=arquivoTT.read()
        #print('texto=',texto)
        arquivoTT.close()
        chave='<edge id='
        chave1='<junction id='
        chave2='<lane id='
        lchave1=[]
        for i in range(0,len(texto)-9):
            #print(texto[i:i+8])
            if chave1==texto[i:i+13]:
                #print(texto[i:i+13])
                n=0
                while texto[i+14+n]!='"':
                    n=n+1
                if  texto[i+14]!=':':
                    lchave1.append(texto[i+14:i+14+n])
                nn=0
                while texto[i+14+n+nn:i+14+n+nn+2]!='x=':
                    nn=nn+1
                #print(texto[i+14+n+nn:i+14+n+nn+2])
                #print(texto[i:i+13])
                nnn=0
                while texto[i+14+n+nn+3+nnn]!='"':
                        nnn=nnn+1
                #print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                lchave1.append(texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                pp=0
                while texto[i+14+n+nn+3+nnn+pp:i+14+n+nn+3+nnn+pp+2]!='y=':
                    pp=pp+1
                #print(texto[i+14+n+nn:i+14+n+nn+2])
                #print(texto[i:i+13])
                ppp=0
                while texto[i+14+n+nn+3+nnn+pp+3+ppp]!='"':
                        ppp=ppp+1
                #print('y=',texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                lchave1.append(texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                #    #if  texto[i+3]!=':':
                #print(texto[i+14+nn+3:i+14+nn+nnn])
                #lchave1.append(texto[i+14+nn+3:i+14+nn+nnn])
                #lchave1.append('1')
            #if texto[i:i+2]=='y=':
            #    #print(texto[i:i+13])
            #    n=0
            #    while texto[i+3+n]!='"':
            #        n=n+1
            #    lchave1.append(texto[i+3:i+3+n])
            #    #lchave1.append('2')
            #if chave==texto[i:i+9]:
            #    m=0
            #    while texto[i+10+m]!='"':
            #        m=m+1
                #print('chave1=',texto[i:i+9],':',texto[i+10:i+10+m])
                #lchave1.append(texto[i+10:i+10+m])
            #    for j in range(i+9,len(texto)-9):
            #        if chave2==texto[j:j+9]:
            #            k=0
            #            while texto[j+10+k]!='"':
            #                k=k+1
                        #print('   chave2=',texto[j:j+9],':',texto[j+10:j+10+k])
                        #print('    ',texto[j:j+12])
            #        if chave==texto[j:j+9]:
            #            break
        return lchave1
    
    def le_arquivo2(self):
        arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3kE\\floresta2.net.xml','r')
        #arquivoTT.close()
       #arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3k\\dadostraci1201e2e3sc\\aT1_'+str(narquivo)+'.m','a+')
        texto=arquivoTT.read()
        #print('texto=',texto)
        arquivoTT.close()
        chave1='<edge id='
        #chave1='<junction id='
        chave2='<lane id='
        lchave1=[]
        for i in range(0,len(texto)-9):
            #print(texto[i:i+8])
            if chave1==texto[i:i+9]:
                #print(texto[i:i+13])
                n=0
                while texto[i+10+n]!='"':
                    n=n+1
                if  texto[i+10]!=':' and texto[i+10]!='-':
                    lchave1.append(texto[i+10:i+10+n])
                for j in range(i+9,len(texto)-9):
                    if chave2==texto[j:j+9]:
                       k=0
                       while texto[j+10+k]!='"':
                           k=k+1
                       #print('   chave2=',texto[j:j+9],':',texto[j+10:j+10+k])
                       if  texto[j+10]!=':' and texto[j+10]!='-':
                           #print('    ',texto[j+10:j+10+k])
                           lchave1.append(texto[j+10:j+10+k])
                       nn=0
                       while texto[j+14+n+nn:j+14+n+nn+6]!='shape=':
                           nn=nn+1
                       #print(texto[i+14+n+nn:i+14+n+nn+2])
                       #print(texto[i:i+13])
                       nnn=0
                       while texto[j+14+n+nn+7+nnn]!='"':
                           nnn=nnn+1
                       #print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                       lchave1.append(texto[j+14+n+nn+7:j+14+n+nn+7+nnn])
                       #pp=0
                       #while texto[j+14+n+nn+3+nnn+pp:j+14+n+nn+3+nnn+pp+2]!='y=':
                       #    pp=pp+1
                       ##print(texto[i+14+n+nn:i+14+n+nn+2])
                       ##print(texto[i:i+13])
                       #ppp=0
                       #while texto[j+14+n+nn+3+nnn+pp+3+ppp]!='"':
                       #    ppp=ppp+1
                       ##print('y=',texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                       #lchave1.append(texto[j+14+n+nn+3+nnn+pp+3:j+14+n+nn+3+nnn+pp+3+ppp])
                    if chave1==texto[j:j+9]:
                        break
                    #nn=0
                    #while texto[i+10+n:i+10+n+9]!=chave1:
                    #nn=0
                    #while texto[i+10+n+nn:i+10+n+nn+9]!=chave2:
                    #    nn=nn+1
                    #    ##print(texto[i+14+n+nn:i+14+n+nn+2])
                    #    ##print(texto[i:i+13])
                    #nnn=0
                    #while texto[i+10+n+nn+10+nnn]!='"':
                    #    nnn=nnn+1
                    #    ##print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                    #lchave1.append(texto[i+10+n+nn+10:i+10+n+nn+10+nnn])
        return lchave1    
    
    def le_arquivo3(self):
        arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3kE\\floresta2.net.xml','r')
        #arquivoTT.close()
       #arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3k\\dadostraci1201e2e3sc\\aT1_'+str(narquivo)+'.m','a+')
        texto=arquivoTT.read()
        #print('texto=',texto)
        arquivoTT.close()
        chave1='<edge id='
        #chave1='<junction id='
        chave2='<lane id='
        lchave1=[]
        for i in range(0,len(texto)-9):
            #print(texto[i:i+8])
            if chave1==texto[i:i+9]:
                #print(texto[i:i+13])
                n=0
                while texto[i+10+n]!='"':
                    n=n+1
                #if  texto[i+10]!=':' and texto[i+10]!='-':
                #    lchave1.append(texto[i+10:i+10+n])
                for j in range(i+9,len(texto)-9):
                    if chave2==texto[j:j+9]:
                       k=0
                       while texto[j+10+k]!='"':
                           k=k+1
                       #print('   chave2=',texto[j:j+9],':',texto[j+10:j+10+k])
                       if  texto[j+10]!=':' and texto[j+10]!='-':
                           #print('    ',texto[j+10:j+10+k])
                           lchave1.append(texto[j+10:j+10+k])
                       nn=0
                       while texto[j+14+n+nn:j+14+n+nn+6]!='shape=':
                           nn=nn+1
                       #print(texto[i+14+n+nn:i+14+n+nn+2])
                       #print(texto[i:i+13])
                       nnn=0
                       while texto[j+14+n+nn+7+nnn]!='"':
                           nnn=nnn+1
                       #print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                       lchave1.append(texto[j+14+n+nn+7:j+14+n+nn+7+nnn])
                       #pp=0
                       #while texto[j+14+n+nn+3+nnn+pp:j+14+n+nn+3+nnn+pp+2]!='y=':
                       #    pp=pp+1
                       ##print(texto[i+14+n+nn:i+14+n+nn+2])
                       ##print(texto[i:i+13])
                       #ppp=0
                       #while texto[j+14+n+nn+3+nnn+pp+3+ppp]!='"':
                       #    ppp=ppp+1
                       ##print('y=',texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                       #lchave1.append(texto[j+14+n+nn+3+nnn+pp+3:j+14+n+nn+3+nnn+pp+3+ppp])
                    if chave1==texto[j:j+9]:
                        break
                    #nn=0
                    #while texto[i+10+n:i+10+n+9]!=chave1:
                    #nn=0
                    #while texto[i+10+n+nn:i+10+n+nn+9]!=chave2:
                    #    nn=nn+1
                    #    ##print(texto[i+14+n+nn:i+14+n+nn+2])
                    #    ##print(texto[i:i+13])
                    #nnn=0
                    #while texto[i+10+n+nn+10+nnn]!='"':
                    #    nnn=nnn+1
                    #    ##print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                    #lchave1.append(texto[i+10+n+nn+10:i+10+n+nn+10+nnn])
        return lchave1        
    
    def le_arquivo4(self):
        arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3kE\\floresta2.net.xml','r')
        #arquivoTT.close()
       #arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3k\\dadostraci1201e2e3sc\\aT1_'+str(narquivo)+'.m','a+')
        texto=arquivoTT.read()
        #print('texto=',texto)
        arquivoTT.close()
        chave1='<edge id='
        #chave1='<junction id='
        chave2='<lane id='
        lchave1=[]
        lchave2=[]
        for i in range(0,len(texto)-9):
            #print(texto[i:i+8])
            if chave1==texto[i:i+9]:
                #print(texto[i:i+13])
                n=0
                while texto[i+10+n]!='"':
                    n=n+1
                #if  texto[i+10]!=':' and texto[i+10]!='-':
                #    lchave1.append(texto[i+10:i+10+n])
                for j in range(i+9,len(texto)-9):
                    if chave2==texto[j:j+9]:
                       k=0
                       while texto[j+10+k]!='"':
                           k=k+1
                       #print('   chave2=',texto[j:j+9],':',texto[j+10:j+10+k])
                       if  texto[j+10]!=':' and texto[j+10]!='-':
                           #print('    ',texto[j+10:j+10+k])
                           lchave1.append(texto[j+10:j+10+k])
                       nn=0
                       while texto[j+14+n+nn:j+14+n+nn+6]!='shape=':
                           nn=nn+1
                       #print(texto[i+14+n+nn:i+14+n+nn+2])
                       #print(texto[i:i+13])
                       nnn=0
                       while texto[j+14+n+nn+7+nnn]!='"' and nnn<29:
                           nnn=nnn+1
                       #print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                       if  texto[j+10]!=':' and texto[j+10]!='-':
                           lchave2.append(texto[j+14+n+nn+7:j+14+n+nn+7+nnn])
                       #pp=0
                       #while texto[j+14+n+nn+3+nnn+pp:j+14+n+nn+3+nnn+pp+2]!='y=':
                       #    pp=pp+1
                       ##print(texto[i+14+n+nn:i+14+n+nn+2])
                       ##print(texto[i:i+13])
                       #ppp=0
                       #while texto[j+14+n+nn+3+nnn+pp+3+ppp]!='"':
                       #    ppp=ppp+1
                       ##print('y=',texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                       #lchave1.append(texto[j+14+n+nn+3+nnn+pp+3:j+14+n+nn+3+nnn+pp+3+ppp])
                    if chave1==texto[j:j+9]:
                        break
                    #nn=0
                    #while texto[i+10+n:i+10+n+9]!=chave1:
                    #nn=0
                    #while texto[i+10+n+nn:i+10+n+nn+9]!=chave2:
                    #    nn=nn+1
                    #    ##print(texto[i+14+n+nn:i+14+n+nn+2])
                    #    ##print(texto[i:i+13])
                    #nnn=0
                    #while texto[i+10+n+nn+10+nnn]!='"':
                    #    nnn=nnn+1
                    #    ##print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                    #lchave1.append(texto[i+10+n+nn+10:i+10+n+nn+10+nnn])
        return lchave1,lchave2

    def le_arquivo5(self):#idcruzamento e tv de cada fase
        arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3kE\\floresta2.net.xml','r')
        #arquivoTT.close()
       #arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3k\\dadostraci1201e2e3sc\\aT1_'+str(narquivo)+'.m','a+')
        texto=arquivoTT.read()
        #print('texto=',texto)
        arquivoTT.close()
        #chave1='<edge id='
        chave1='<tlLogic id='
        #chave1='<junction id='
        #chave2='<lane id='
        chave2='<phase duration='
        lchave1=[]
        for i in range(0,len(texto)-9):
            #print(texto[i:i+8])
            #if chave1==texto[i:i+9]:
            if chave1==texto[i:i+12]:
                #print(texto[i:i+13])
                n=0
                #while texto[i+10+n]!='"':
                while texto[i+13+n]!='"':
                    n=n+1
                #if  texto[i+10]!=':' and texto[i+10]!='-':
                if  texto[i+13]!=':' and texto[i+13]!='-':
                    #lchave1.append(texto[i+10:i+10+n])
                    lchave1.append(texto[i+13:i+13+n])
                #for j in range(i+9,len(texto)-9):
                for j in range(i+13,len(texto)-9):
                    #if chave2==texto[j:j+9]:
                    if chave2==texto[j:j+16]:
                       k=0
                       #while texto[j+10+k]!='"':
                       while texto[j+17+k]!='"':
                           k=k+1
                       #print('   chave2=',texto[j:j+9],':',texto[j+10:j+10+k])
                       #if  texto[j+10]!=':' and texto[j+10]!='-':
                       if  texto[j+17]!=':' and texto[j+17]!='-':
                           #print('    ',texto[j+10:j+10+k])
                           #lchave1.append(texto[j+10:j+10+k])
                           lchave1.append(texto[j+17:j+17+k])
                       #nn=0
                       #while texto[j+17+k+nn:j+17+k+nn+16]!='<phase duration=':
                       #    nn=nn+1
                       ##print(texto[i+14+n+nn:i+14+n+nn+2])
                       ##print(texto[i:i+13])
                       #nnn=0
                       ##while texto[j+14+n+nn+17+nnn]!='"':
                       ##    nnn=nnn+1
                       ##print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                       #lchave1.append(texto[j+14+n+nn+17:j+14+n+nn+17+nnn])
                       #pp=0
                       #while texto[j+14+n+nn+3+nnn+pp:j+14+n+nn+3+nnn+pp+2]!='y=':
                       #    pp=pp+1
                       ##print(texto[i+14+n+nn:i+14+n+nn+2])
                       ##print(texto[i:i+13])
                       #ppp=0
                       #while texto[j+14+n+nn+3+nnn+pp+3+ppp]!='"':
                       #    ppp=ppp+1
                       ##print('y=',texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                       #lchave1.append(texto[j+14+n+nn+3+nnn+pp+3:j+14+n+nn+3+nnn+pp+3+ppp])
                    #if chave1==texto[j:j+13]:
                    if texto[j:j+10]=='</tlLogic>':
                        break
                    #nn=0
                    #while texto[i+10+n:i+10+n+9]!=chave1:
                    #nn=0
                    #while texto[i+10+n+nn:i+10+n+nn+9]!=chave2:
                    #    nn=nn+1
                    #    ##print(texto[i+14+n+nn:i+14+n+nn+2])
                    #    ##print(texto[i:i+13])
                    #nnn=0
                    #while texto[i+10+n+nn+10+nnn]!='"':
                    #    nnn=nnn+1
                    #    ##print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                    #lchave1.append(texto[i+10+n+nn+10:i+10+n+nn+10+nnn])
        return lchave1    
    
    def le_arquivo6(self):
        arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3kE\\floresta2.net.xml','r')
        #arquivoTT.close()
       #arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3k\\dadostraci1201e2e3sc\\aT1_'+str(narquivo)+'.m','a+')
        texto=arquivoTT.read()
        #print('texto=',texto)
        arquivoTT.close()
        chave='<edge id='
        chave1='<junction id='
        chave2='<lane id='
        chave3='incLanes='
        chave4='intLanes='
        lchave1=[]
        for i in range(0,len(texto)-9):
            #print(texto[i:i+8])
            if chave1==texto[i:i+13]:
                #print(texto[i:i+13])
                n=0
                while texto[i+14+n]!='"':
                    n=n+1
                #if  texto[i+14]!=':':
                if  texto[i+14]!=':' and texto[i+14]!='-':
                    lchave1.append(texto[i+14:i+14+n])
                nn=0
                while texto[i+14+n+nn:i+14+n+nn+2]!='x=':
                    nn=nn+1
                #print(texto[i+14+n+nn:i+14+n+nn+2])
                #print(texto[i:i+13])
                nnn=0
                while texto[i+14+n+nn+3+nnn]!='"':
                        nnn=nnn+1
                #print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                if  texto[i+14+n+nn+3]!=':' and texto[i+14+n+nn+3]!='-':
                    lchave1.append(texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                pp=0
                while texto[i+14+n+nn+3+nnn+pp:i+14+n+nn+3+nnn+pp+2]!='y=':
                    pp=pp+1
                #print(texto[i+14+n+nn:i+14+n+nn+2])
                #print(texto[i:i+13])
                ppp=0
                while texto[i+14+n+nn+3+nnn+pp+3+ppp]!='"':
                        ppp=ppp+1
                #print('y=',texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                if  texto[i+14+n+nn+3+nnn+pp+3]!=':' and texto[i+14+n+nn+3+nnn+pp+3]!='-':
                    lchave1.append(texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                #pp=0
                pp2=0
                while texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2:i+14+n+nn+3+nnn+pp+3+ppp+pp2+9]!=chave3:
                    pp2=pp2+1
                #print(texto[i+14+n+nn:i+14+n+nn+2])
                #print(texto[i:i+13])
                ppp2=0
                while texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2]!='"':
                        ppp2=ppp2+1
                #print('y=',texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                if  texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10]!=':' and texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10]!='-':
                    lchave1.append(texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10:i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2])
                pp3=0
                while texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3:i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3+9]!=chave4:
                    pp3=pp3+1
                ##print(texto[i+14+n+nn:i+14+n+nn+2])
                ##print(texto[i:i+13])
                ppp3=0
                while texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3+10+ppp3]!='"':
                    ppp3=ppp3+1
                ##print('y=',texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                if  texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3+10]!=':' and texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3+10]!='-':
                    lchave1.append(texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3+10:i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3+10+ppp3])
                #    #if  texto[i+3]!=':':
                #print(texto[i+14+nn+3:i+14+nn+nnn])
                #lchave1.append(texto[i+14+nn+3:i+14+nn+nnn])
                #lchave1.append('1')
            #if texto[i:i+2]=='y=':
            #    #print(texto[i:i+13])
            #    n=0
            #    while texto[i+3+n]!='"':
            #        n=n+1
            #    lchave1.append(texto[i+3:i+3+n])
            #    #lchave1.append('2')
            #if chave==texto[i:i+9]:
            #    m=0
            #    while texto[i+10+m]!='"':
            #        m=m+1
                #print('chave1=',texto[i:i+9],':',texto[i+10:i+10+m])
                #lchave1.append(texto[i+10:i+10+m])
            #    for j in range(i+9,len(texto)-9):
            #        if chave2==texto[j:j+9]:
            #            k=0
            #            while texto[j+10+k]!='"':
            #                k=k+1
                        #print('   chave2=',texto[j:j+9],':',texto[j+10:j+10+k])
                        #print('    ',texto[j:j+12])
            #        if chave==texto[j:j+9]:
            #            break
        return lchave1
    
    
    def le_arquivo7(self):
        arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3kE\\floresta2.net.xml','r')
        #arquivoTT.close()
       #arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3k\\dadostraci1201e2e3sc\\aT1_'+str(narquivo)+'.m','a+')
        texto=arquivoTT.read()
        #print('texto=',texto)
        arquivoTT.close()
        #chave1='<edge id='
        chave1='<tlLogic id='
        #chave1='<junction id='
        #chave2='<lane id='
        #chave2='<phase duration='
        chave2='state='
        lchave1=[]
        for i in range(0,len(texto)-9):
            #print(texto[i:i+8])
            #if chave1==texto[i:i+9]:
            if chave1==texto[i:i+12]:
                #print(texto[i:i+13])
                n=0
                #while texto[i+10+n]!='"':
                while texto[i+13+n]!='"':
                    n=n+1
                #if  texto[i+10]!=':' and texto[i+10]!='-':
                if  texto[i+13]!=':' and texto[i+13]!='-':
                    #lchave1.append(texto[i+10:i+10+n])
                    lchave1.append(texto[i+13:i+13+n])
                #for j in range(i+9,len(texto)-9):
                for j in range(i+13,len(texto)-9):
                    #if chave2==texto[j:j+9]:
                    #if chave2==texto[j:j+16]:
                    if chave2==texto[j:j+6]:
                       k=0
                       #while texto[j+10+k]!='"':
                       #while texto[j+17+k]!='"':
                       while texto[j+7+k]!='"':
                           k=k+1
                       #print('   chave2=',texto[j:j+9],':',texto[j+10:j+10+k])
                       #if  texto[j+10]!=':' and texto[j+10]!='-':
                       #if  texto[j+17]!=':' and texto[j+17]!='-':
                       if  texto[j+7]!=':' and texto[j+7]!='-':
                           #print('    ',texto[j+10:j+10+k])
                           #lchave1.append(texto[j+10:j+10+k])
                           #lchave1.append(texto[j+17:j+17+k])
                           lchave1.append(texto[j+7:j+7+k])
                       #nn=0
                       #while texto[j+17+k+nn:j+17+k+nn+16]!='<phase duration=':
                       #    nn=nn+1
                       ##print(texto[i+14+n+nn:i+14+n+nn+2])
                       ##print(texto[i:i+13])
                       #nnn=0
                       ##while texto[j+14+n+nn+17+nnn]!='"':
                       ##    nnn=nnn+1
                       ##print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                       #lchave1.append(texto[j+14+n+nn+17:j+14+n+nn+17+nnn])
                       #pp=0
                       #while texto[j+14+n+nn+3+nnn+pp:j+14+n+nn+3+nnn+pp+2]!='y=':
                       #    pp=pp+1
                       ##print(texto[i+14+n+nn:i+14+n+nn+2])
                       ##print(texto[i:i+13])
                       #ppp=0
                       #while texto[j+14+n+nn+3+nnn+pp+3+ppp]!='"':
                       #    ppp=ppp+1
                       ##print('y=',texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                       #lchave1.append(texto[j+14+n+nn+3+nnn+pp+3:j+14+n+nn+3+nnn+pp+3+ppp])
                    #if chave1==texto[j:j+13]:
                    if texto[j:j+10]=='</tlLogic>':
                        break
                    #nn=0
                    #while texto[i+10+n:i+10+n+9]!=chave1:
                    #nn=0
                    #while texto[i+10+n+nn:i+10+n+nn+9]!=chave2:
                    #    nn=nn+1
                    #    ##print(texto[i+14+n+nn:i+14+n+nn+2])
                    #    ##print(texto[i:i+13])
                    #nnn=0
                    #while texto[i+10+n+nn+10+nnn]!='"':
                    #    nnn=nnn+1
                    #    ##print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                    #lchave1.append(texto[i+10+n+nn+10:i+10+n+nn+10+nnn])
        return lchave1    
    
    def le_arquivo8(self,chave,fase):
        lchave1=self.le_arquivo7()
        i=0
        while lchave1[i] != chave:
            i=i+1
            #print(lchave1[i-1])
            #j=0
            #while j!=fase:
            #    j=j+1
        #        for j in range(i,i+6):
        #            if i-j==fase:
        #                lchave=lchave1[j]
        #            else:
        #                lchave=0
        #    else:
        #        lchave=0
        lchave=lchave1[i+fase]
        return lchave    
    
    def le_arquivo9(self,nchave,fase):
        lchave1=self.le_arquivo7()
        i=0
        while i != nchave:
            i=i+1
            #print(lchave1[i-1])
            #j=0
            #while j!=fase:
            #    j=j+1
        #        for j in range(i,i+6):
        #            if i-j==fase:
        #                lchave=lchave1[j]
        #            else:
        #                lchave=0
        #    else:
        #        lchave=0
        lchave=lchave1[i+fase]
        return lchave    
    
    #def conta_cruzamentos(self):
    #    lchave1=self.le_chave7()
    #    icross=0
    #    ncross=0
    #    while len(lchave1[icross])>:
            
    def retpos2(self,valor,ncross):            
        return valor
    
    def le_arquivo10(self):
        arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3kE\\floresta2.net.xml','r')
        #arquivoTT.close()
       #arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3k\\dadostraci1201e2e3sc\\aT1_'+str(narquivo)+'.m','a+')
        texto=arquivoTT.read()
        #print('texto=',texto)
        arquivoTT.close()
        #chave1='<edge id='
        chave1='<tlLogic id='
        #chave1='<junction id='
        #chave2='<lane id='
        #chave2='<phase duration='
        chave2='state='
        lchave1=[]
        for i in range(0,len(texto)-9):
            #print(texto[i:i+8])
            #if chave1==texto[i:i+9]:
            if chave1==texto[i:i+12]:
                #print(texto[i:i+13])
                n=0
                #while texto[i+10+n]!='"':
                while texto[i+13+n]!='"':
                    n=n+1
                #if  texto[i+10]!=':' and texto[i+10]!='-':
                if  texto[i+13]!=':' and texto[i+13]!='-':
                    #lchave1.append(texto[i+10:i+10+n])
                    lchave1.append(texto[i+13:i+13+n])
                #for j in range(i+9,len(texto)-9):
                for j in range(i+13,len(texto)-9):
                    #if chave2==texto[j:j+9]:
                    #if chave2==texto[j:j+16]:
                    if chave2==texto[j:j+6]:
                       k=0
                       #while texto[j+10+k]!='"':
                       #while texto[j+17+k]!='"':
                       while texto[j+7+k]!='"':
                           k=k+1
                       #print('   chave2=',texto[j:j+9],':',texto[j+10:j+10+k])
                       #if  texto[j+10]!=':' and texto[j+10]!='-':
                       #if  texto[j+17]!=':' and texto[j+17]!='-':
                       #if  texto[j+7]!=':' and texto[j+7]!='-':
                           #print('    ',texto[j+10:j+10+k])
                           #lchave1.append(texto[j+10:j+10+k])
                           #lchave1.append(texto[j+17:j+17+k])
                           #lchave1.append(texto[j+7:j+7+k])
                       #nn=0
                       #while texto[j+17+k+nn:j+17+k+nn+16]!='<phase duration=':
                       #    nn=nn+1
                       ##print(texto[i+14+n+nn:i+14+n+nn+2])
                       ##print(texto[i:i+13])
                       #nnn=0
                       ##while texto[j+14+n+nn+17+nnn]!='"':
                       ##    nnn=nnn+1
                       ##print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                       #lchave1.append(texto[j+14+n+nn+17:j+14+n+nn+17+nnn])
                       #pp=0
                       #while texto[j+14+n+nn+3+nnn+pp:j+14+n+nn+3+nnn+pp+2]!='y=':
                       #    pp=pp+1
                       ##print(texto[i+14+n+nn:i+14+n+nn+2])
                       ##print(texto[i:i+13])
                       #ppp=0
                       #while texto[j+14+n+nn+3+nnn+pp+3+ppp]!='"':
                       #    ppp=ppp+1
                       ##print('y=',texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                       #lchave1.append(texto[j+14+n+nn+3+nnn+pp+3:j+14+n+nn+3+nnn+pp+3+ppp])
                    #if chave1==texto[j:j+13]:
                    if texto[j:j+10]=='</tlLogic>':
                        break
                    #nn=0
                    #while texto[i+10+n:i+10+n+9]!=chave1:
                    #nn=0
                    #while texto[i+10+n+nn:i+10+n+nn+9]!=chave2:
                    #    nn=nn+1
                    #    ##print(texto[i+14+n+nn:i+14+n+nn+2])
                    #    ##print(texto[i:i+13])
                    #nnn=0
                    #while texto[i+10+n+nn+10+nnn]!='"':
                    #    nnn=nnn+1
                    #    ##print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                    #lchave1.append(texto[i+10+n+nn+10:i+10+n+nn+10+nnn])
        return lchave1    
    
    
    def le_arquivo11(self,nchave):
        lchave1=self.le_arquivo5()#retorna o id da junção e a duração das fases
        lchave2=self.le_arquivo10()#le todas as chaves dos planos semafóricos
        i=0
        while lchave1[i] != lchave2[nchave]:
            i=i+1
            #print(lchave1[i-1])
            #j=0
            #while j!=fase:
            #    j=j+1
        #        for j in range(i,i+6):
        #            if i-j==fase:
        #                lchave=lchave1[j]
        #            else:
        #                lchave=0
        #    else:
        #        lchave=0
        lchave=[]
        j=i+1
        while int(lchave1[j])<1000:
            lchave.append(lchave1[j])
            j=j+1
        return lchave        
    
    def grava_arquivo(self):
        (lista,lista2)=self.le_arquivo13()
        lv=self.le_arquivo19()
        arquivoT1=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3kE\\dadostraci1201e2e3sc\\floresta3.add.xml','w')
        arquivoT1.close()
        arquivoT1=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3kE\\dadostraci1201e2e3sc\\floresta3.add.xml','a+')
        arquivoT1.write("<additional>\n")
        for i in range(0,len(lista)):
            #for j in range(0,len(lv)):
            #for i in range(0,4):
            #arquivoT1.write("	<inductionLoop id=\"mL1i_0e\" lane=\"224943518#3_1\" pos=\"45\" freq=\"900\" file=\"dadostraci11/out1i_0e.xml\"/>\n")
            #if lista2[i]==lv[j]:# and float(lista2[i])>=20:
            #if float(lista2[i])>=20:
                #print("	<inductionLoop id=\"" + str(self.retira_caracteres(lista[i])) +  "in\" lane=\""+ lista[i]+"\" pos=\""+str(.1*float(lista2[i]))+"\" freq=\"900\" file=\"dadostraci11/in"+str(self.retira_caracteres(lista[i]))+ ".xml\"/>\n")                        
            arquivoT1.write("	<inductionLoop id=\"" + str(self.retira_caracteres(lista[i])) +  "in\" lane=\""+ lista[i]+"\" pos=\""+str(.1*float(lista2[i]))+"\" freq=\"900\" file=\"dadostraci11/in"+str(self.retira_caracteres(lista[i]))+ ".xml\"/>\n")                        
            arquivoT1.write("	<inductionLoop id=\"" + str(self.retira_caracteres(lista[i])) +  "out\" lane=\""+ lista[i]+"\" pos=\""+str(.8*float(lista2[i]))+"\" freq=\"900\" file=\"dadostraci11/out"+str(self.retira_caracteres(lista[i]))+ ".xml\"/>\n")
        arquivoT1.write("</additional>\n")                        
        #arquivoT1.write("...")                        
        arquivoT1.close()
        
    def grava_arquivoM(self):
        (lista,lista2)=self.le_arquivo13()
        #arquivoT1=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3kE\\dadostraci1201e2e3sc\\floresta3.add.xml','w')
        #arquivoT1.close()
        #arquivoT1=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3kE\\dadostraci1201e2e3sc\\floresta3.add.xml','a+')
        #arquivoT1.write("<additional>\n")
        lv=self.le_arquivo19()
        lista_sensoresin=[]
        lista_sensoresout=[]
        lista_lane=[]
        for i in range(0,len(lista)):
            for j in range(0,len(lv)):
        #for i in range(0,4):
            #arquivoT1.write("	<inductionLoop id=\"mL1i_0e\" lane=\"224943518#3_1\" pos=\"45\" freq=\"900\" file=\"dadostraci11/out1i_0e.xml\"/>\n")
                if lista2[i]==lv[j]:# and float(lista2[i])>=20:
                    #arquivoT1.write("	<inductionLoop id=\"" + str(self.retira_caracteres(lista[i])) +  "in\" lane=\""+ lista[i]+"\" pos=\""+str(.1*float(lista2[i]))+"\" freq=\"900\" file=\"dadostraci11/in"+str(self.retira_caracteres(lista[i]))+ ".xml\"/>\n")                        
                    print(str(self.retira_caracteres(lista[i]))+'in')
                    lista_sensoresin.append(str(self.retira_caracteres(lista[i]))+'in')
                    #arquivoT1.write("	<inductionLoop id=\"" + str(self.retira_caracteres(lista[i])) +  "out\" lane=\""+ lista[i]+"\" pos=\""+str(.8*float(lista2[i]))+"\" freq=\"900\" file=\"dadostraci11/out"+str(self.retira_caracteres(lista[i]))+ ".xml\"/>\n")
                    lista_sensoresout.append(str(self.retira_caracteres(lista[i]))+'out')
                    lista_lane.append(lista[i])
        #arquivoT1.write("</additional>\n")                        
        #arquivoT1.write("...")                        
        #arquivoT1.close()        
        return lista_sensoresin,lista_sensoresout,lista_lane
        
    def retira_caracteres(self,num):
        numR=0
        base=10
        expoente=len(num)-1
        for i in range(0,len(num)):
            if num[i]=='#' or num[i]=='_':
                #if num[i] =='#':
                #i=0
                numR=numR+0*base**expoente
                expoente=expoente-1
                #numR[i]='_'
            else:
                numR=numR+int(num[i])*base**expoente
                expoente=expoente-1
                #numR.append('_')
                #numR[i]=int(num[i])
            #else:
                #numR.append(num[i])
        #i=2
        #numR.append(num[0][i-1])
        return numR
    
    def le_arquivo12(self):
        arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3kE\\floresta2.net.xml','r')
        #arquivoTT.close()
       #arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3k\\dadostraci1201e2e3sc\\aT1_'+str(narquivo)+'.m','a+')
        texto=arquivoTT.read()
        #print('texto=',texto)
        arquivoTT.close()
        chave1='<edge id='
        #chave1='<junction id='
        chave2='<lane id='
        lchave1=[]
        for i in range(0,len(texto)-9):
            #print(texto[i:i+8])
            if chave1==texto[i:i+9]:
                #print(texto[i:i+13])
                n=0
                while texto[i+10+n]!='"':
                    n=n+1
                #if  texto[i+10]!=':' and texto[i+10]!='-':
                    #lchave1.append(texto[i+10:i+10+n])
                for j in range(i+9,len(texto)-9):
                    if chave2==texto[j:j+9]:
                       k=0
                       while texto[j+10+k]!='"':
                           k=k+1
                       #print('   chave2=',texto[j:j+9],':',texto[j+10:j+10+k])
                       if  texto[j+10]!=':' and texto[j+10]!='-':
                           #print('    ',texto[j+10:j+10+k])
                           lchave1.append(texto[j+10:j+10+k])
                       nn=0
                       while texto[j+14+n+nn:j+14+n+nn+6]!='shape=':
                           nn=nn+1
                       #print(texto[i+14+n+nn:i+14+n+nn+2])
                       #print(texto[i:i+13])
                       nnn=0
                       while texto[j+14+n+nn+7+nnn]!='"':
                           nnn=nnn+1
                       #print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                       #lchave1.append(texto[j+14+n+nn+7:j+14+n+nn+7+nnn])
                       #pp=0
                       #while texto[j+14+n+nn+3+nnn+pp:j+14+n+nn+3+nnn+pp+2]!='y=':
                       #    pp=pp+1
                       ##print(texto[i+14+n+nn:i+14+n+nn+2])
                       ##print(texto[i:i+13])
                       #ppp=0
                       #while texto[j+14+n+nn+3+nnn+pp+3+ppp]!='"':
                       #    ppp=ppp+1
                       ##print('y=',texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                       #lchave1.append(texto[j+14+n+nn+3+nnn+pp+3:j+14+n+nn+3+nnn+pp+3+ppp])
                    if chave1==texto[j:j+9]:
                        break
                    #nn=0
                    #while texto[i+10+n:i+10+n+9]!=chave1:
                    #nn=0
                    #while texto[i+10+n+nn:i+10+n+nn+9]!=chave2:
                    #    nn=nn+1
                    #    ##print(texto[i+14+n+nn:i+14+n+nn+2])
                    #    ##print(texto[i:i+13])
                    #nnn=0
                    #while texto[i+10+n+nn+10+nnn]!='"':
                    #    nnn=nnn+1
                    #    ##print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                    #lchave1.append(texto[i+10+n+nn+10:i+10+n+nn+10+nnn])
        return lchave1    

    def le_arquivo13(self):
        arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3kE\\floresta2.net.xml','r')
        #arquivoTT.close()
       #arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3k\\dadostraci1201e2e3sc\\aT1_'+str(narquivo)+'.m','a+')
        texto=arquivoTT.read()
        #print('texto=',texto)
        arquivoTT.close()
        chave1='<edge id='
        #chave1='<junction id='
        chave2='<lane id='
        #chave3='length='
        lchave1=[]
        lchave2=[]
        for i in range(0,len(texto)-9):
            #print(texto[i:i+8])
            if chave1==texto[i:i+9]:
                #print(texto[i:i+13])
                n=0
                while texto[i+10+n]!='"':
                    n=n+1
                #if  texto[i+10]!=':' and texto[i+10]!='-':
                    #lchave1.append(texto[i+10:i+10+n])
                for j in range(i+9,len(texto)-9):
                    if chave2==texto[j:j+9]:
                       k=0
                       while texto[j+10+k]!='"':
                           k=k+1
                       #print('   chave2=',texto[j:j+9],':',texto[j+10:j+10+k])
                       if  texto[j+10]!=':' and texto[j+10]!='-':
                           #print('    ',texto[j+10:j+10+k])
                           lchave1.append(texto[j+10:j+10+k])
                           nn=0
                           while texto[j+14+n+nn:j+14+n+nn+7]!='length=':
                               nn=nn+1
                       #print(texto[i+14+n+nn:i+14+n+nn+2])
                       #print(texto[i:i+13])
                           nnn=0
                           while texto[j+14+n+nn+8+nnn]!='"':
                               nnn=nnn+1
                       #print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                           lchave2.append(texto[j+14+n+nn+8:j+14+n+nn+8+nnn])
                       #pp=0
                       #while texto[j+14+n+nn+3+nnn+pp:j+14+n+nn+3+nnn+pp+2]!='y=':
                       #    pp=pp+1
                       ##print(texto[i+14+n+nn:i+14+n+nn+2])
                       ##print(texto[i:i+13])
                       #ppp=0
                       #while texto[j+14+n+nn+3+nnn+pp+3+ppp]!='"':
                       #    ppp=ppp+1
                       ##print('y=',texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                       #lchave1.append(texto[j+14+n+nn+3+nnn+pp+3:j+14+n+nn+3+nnn+pp+3+ppp])
                    if chave1==texto[j:j+9]:
                        break
                    #nn=0
                    #while texto[i+10+n:i+10+n+9]!=chave1:
                    #nn=0
                    #while texto[i+10+n+nn:i+10+n+nn+9]!=chave2:
                    #    nn=nn+1
                    #    ##print(texto[i+14+n+nn:i+14+n+nn+2])
                    #    ##print(texto[i:i+13])
                    #nnn=0
                    #while texto[i+10+n+nn+10+nnn]!='"':
                    #    nnn=nnn+1
                    #    ##print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                    #lchave1.append(texto[i+10+n+nn+10:i+10+n+nn+10+nnn])
        return lchave1,lchave2    


    def extrai_xy(self,lista):
        tamanho=len(lista)
        #base=10
        #expoente=0
        sx0=[]
        sy0=[]
        sx1=[]
        sy1=[]
        i=0
        while(lista[i]!=','):
            sx0.append(lista[i])
            i=i+1
        x0=float(lista[0:i])
        i=i+1
        j=i
        while(lista[i]!=' '):
            sy0.append(lista[i])
            i=i+1
        y0=float(lista[j:i])
        i=i+1
        j=i
        while(lista[i]!=','):
            sx1.append(lista[i])
            i=i+1
        x1=float(lista[j:i])
        i=i+1
        j=i
        while(i<tamanho):
            sy1.append(lista[i])
            i=i+1
        y1=float(lista[j:i])
        return x0,y0,x1,y1
    
    def retorna_lane(self,chave):
        (lista1,lista2)=self.le_arquivo4()
        (x0,y0,x1,y1)=self.extrai_xy(lista2[chave])
        return lista1[chave],x0,y0,x1,y1
        
    def retorna_junctions(self):
        arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3kE\\floresta2.net.xml','r')
        #arquivoTT.close()
       #arquivoTT=open('c:\\install\\sumo\\tutorial_04ceem4vC1vC2kC3k\\dadostraci1201e2e3sc\\aT1_'+str(narquivo)+'.m','a+')
        texto=arquivoTT.read()
        #print('texto=',texto)
        arquivoTT.close()
        #chave1='<edge id='
        chave1='<junction id='
        chave2='<lane id='
        chave3='incLanes='
        chave4='intLanes='
        testej=0
        testex=0
        testey=0
        testeinc=0
        testeint=0
        ljunction=[]
        lx=[]
        ly=[]
        lincLanes=[]
        lintLanes=[]
        for i in range(0,len(texto)-9):
            #print(texto[i:i+8])
            testej=0
            testex=0
            testey=0
            testeinc=0
            testeint=0
            if chave1==texto[i:i+13]:
                #print(texto[i:i+13])
                n=0
                while texto[i+14+n]!='"':
                    n=n+1
                #if  texto[i+14]!=':':
                if  texto[i+14]!=':' and texto[i+14]!='-':
                    testej=1
                    #ljunction.append(texto[i+14:i+14+n])
                #nn=0
                    nn=0
                #while texto[i+14+n+nn:i+14+n+nn+2]!='x=':
                    while texto[i+14+n+nn:i+14+n+nn+2]!='x=':
                    #nn=nn+1
                        nn=nn+1
                #print(texto[i+14+n+nn:i+14+n+nn+2])
                #print(texto[i:i+13])
                #nnn=0
                    nnn=0
                #while texto[i+14+n+nn+3+nnn]!='"':
                    while texto[i+14+n+nn+3+nnn]!='"':
                    #nnn=nnn+1
                        nnn=nnn+1
                #print('x=',texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                #if  texto[i+14+n+nn+3]!=':' and texto[i+14+n+nn+3]!='-':
                    if  texto[i+14+n+nn+3]!=':' and texto[i+14+n+nn+3]!='-':
                    #lx.append(texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                        testex=1
                        #lx.append(texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                #pp=0
                    pp=0
                #while texto[i+14+n+nn+3+nnn+pp:i+14+n+nn+3+nnn+pp+2]!='y=':
                    while texto[i+14+n+nn+3+nnn+pp:i+14+n+nn+3+nnn+pp+2]!='y=':
                    #pp=pp+1
                        pp=pp+1
                #print(texto[i+14+n+nn:i+14+n+nn+2])
                #print(texto[i:i+13])
                #ppp=0
                    ppp=0
                #while texto[i+14+n+nn+3+nnn+pp+3+ppp]!='"':
                    while texto[i+14+n+nn+3+nnn+pp+3+ppp]!='"':
                    #ppp=ppp+1
                        ppp=ppp+1
                #print('y=',texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                #if  texto[i+14+n+nn+3+nnn+pp+3]!=':' and texto[i+14+n+nn+3+nnn+pp+3]!='-':
                    if  texto[i+14+n+nn+3+nnn+pp+3]!=':' and texto[i+14+n+nn+3+nnn+pp+3]!='-':
                    #ly.append(texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                        testey=1
                        #ly.append(texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                #pp=0
                #pp2=0
                    pp2=0
                #while texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2:i+14+n+nn+3+nnn+pp+3+ppp+pp2+9]!=chave3:
                    while texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2:i+14+n+nn+3+nnn+pp+3+ppp+pp2+9]!=chave3:
                    #pp2=pp2+1
                        pp2=pp2+1
                #print(texto[i+14+n+nn:i+14+n+nn+2])
                #print(texto[i:i+13])
                #ppp2=0
                    ppp2=0
                #while texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2]!='"':
                    while texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2]!='"':
                    #ppp2=ppp2+1
                        ppp2=ppp2+1
                #print('y=',texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                #if  texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10]!=':' and texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10]!='-':
                    if  texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10]!=':' and texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10]!='-' and len(texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10:i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2])>=7:
                    #lincLanes.append(texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10:i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2])
                        testeinc=1
                        #lincLanes.append(texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10:i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2])
                #pp3=0
                    #print('testeinc=',testeinc)
                    pp3=0
                #while texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3:i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3+9]!=chave4:
                    while texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3:i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3+9]!=chave4:
                    #pp3=pp3+1
                        pp3=pp3+1
                ##print(texto[i+14+n+nn:i+14+n+nn+2])
                ##print(texto[i:i+13])
                #ppp3=0
                    ppp3=0
                #while texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3+10+ppp3]!='"':
                    while texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3+10+ppp3]!='"':
                    #ppp3=ppp3+1
                        ppp3=ppp3+1
                ##print('y=',texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                #if  texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3+10]!=':' and texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3+10]!='-':
                    if  texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3+10]!=':' and texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3+10]!='-':
                    #lintLanes.append(texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3+10:i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3+10+ppp3])
                        testeint=1
                    if testej==1 and testex==1 and testey==1 and testeinc==1:
                        ljunction.append(texto[i+14:i+14+n])
                        lx.append(texto[i+14+n+nn+3:i+14+n+nn+3+nnn])
                        ly.append(texto[i+14+n+nn+3+nnn+pp+3:i+14+n+nn+3+nnn+pp+3+ppp])
                        lincLanes.append(texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10:i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2])
                        lintLanes.append(texto[i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3+10:i+14+n+nn+3+nnn+pp+3+ppp+pp2+10+ppp2+pp3+10+ppp3])
                #    #if  texto[i+3]!=':':
                #print(texto[i+14+nn+3:i+14+nn+nnn])
                #lchave1.append(texto[i+14+nn+3:i+14+nn+nnn])
                #lchave1.append('1')
            #if texto[i:i+2]=='y=':
            #    #print(texto[i:i+13])
            #    n=0
            #    while texto[i+3+n]!='"':
            #        n=n+1
            #    lchave1.append(texto[i+3:i+3+n])
            #    #lchave1.append('2')
            #if chave==texto[i:i+9]:
            #    m=0
            #    while texto[i+10+m]!='"':
            #        m=m+1
                #print('chave1=',texto[i:i+9],':',texto[i+10:i+10+m])
                #lchave1.append(texto[i+10:i+10+m])
            #    for j in range(i+9,len(texto)-9):
            #        if chave2==texto[j:j+9]:
            #            k=0
            #            while texto[j+10+k]!='"':
            #                k=k+1
                        #print('   chave2=',texto[j:j+9],':',texto[j+10:j+10+k])
                        #print('    ',texto[j:j+12])
            #        if chave==texto[j:j+9]:
            #            break
        return ljunction,lx,ly,lincLanes,lintLanes
    


    def le_arquivo14(self):
        (junction,x,y,ic,it)=self.retorna_junctions()
        l=[]
        ll=[]
        for i in range(0,len(junction)):
            l=[]
            l.append(junction[i])
            l.append(x[i])
            l.append(y[i])
            #print(len(ic[i]))
            icr=self.extrai_lane(ic[i])
            for j in range(0,len(icr)):
                l.append(icr[j])
            ll.append(l)
        return ll
        


    def le_arquivo15(self):#id cruzamento e tv de cada fase em lista
        lista=self.le_arquivo5()
        lchave1=[]
        lchave2=[]
        for i in range(0,len(lista)-1):
               lchave1=[]
               if len(lista[i])>5 and i<len(lista):
                      lchave1.append(lista[i])
                      i=i+1
                      while len(lista[i])<5 and i<len(lista)-1:
                             lchave1.append(lista[i])
                             i=i+1
               if len(lchave1)>0:
                     lchave2.append(lchave1)
        return lchave2

    def extrai_lane(self,lista):
        tamanho=len(lista)
        #base=10
        #expoente=0
        listaS=[]
        i0=0
        i=0
        while(i<len(lista)):
            if lista[i]==' ':
                listaS.append(lista[i0:i])
                i=i+1
                i0=i
            if i==len(lista)-1:
                listaS.append(lista[i0:i+1])
                i=i+1
                i0=i
            i=i+1
        return listaS
        
    def retorna_xylane(self,idlane):
        (lchave1,lchave2)=self.le_arquivo4()
        for i in range(0,len(lchave1)):
            if idlane==lchave1[i]:
                #print('lchave2[0]=',lchave2[0])
                #(x0,y0,x1,y1)=self.extrai_xy(lchave2[0])
                (x0,y0,x1,y1)=self.extrai_xy(lchave2[i])
        return x0,y0,x1,y1    
    
    def retorna_fase(self, chave,nfase):
            lista17=self.le_arquivo17()
            for i in range(0,len(lista17)):
                if len(lista17[i])>1:
                    return lista17[i][nfase]
                     
    def retorna_fase2(self, chave,nfase):
            lista20=self.le_arquivo20()
            for i in range(0,len(lista20)):
                if chave==lista20[i][0]:
                    return lista20[i][nfase+1]
                     
    def le_arquivo17(self):#id cruzamento e tv de cada fase em lista
        lista=self.le_arquivo7()
        lchave1=[]
        lchave2=[]
        for i in range(0,len(lista)-1):
               lchave1=[]
               if len(lista[i])>9 and i<len(lista):
                      lchave1.append(lista[i])
                      i=i+1
                      while len(lista[i])<5 and i<len(lista)-1:
                             lchave1.append(lista[i])
                             i=i+1
               if len(lchave1)>0:
                     lchave2.append(lchave1)
        return lchave2       
            
    def le_arquivo18(self):#lista valida
        l15=self.le_arquivo15()
        l14=self.le_arquivo14()
        lv=[]
        for i in range(0,len(l15)):
            for j in range(0,len(l14)):
               #print('i=',i,'l[i]=',l[i])
               if l15[i][0]==l14[j][0]:
                   lv.append(l15[i][0])
        return lv

    def le_arquivo19(self):#lista valida
        lv=self.le_arquivo18()
        lLane=[]
        for i in range(0,len(lv)):
            l16=self.le_arquivo16(lv[0])
            for j in range(3,len(l16)):
                   lLane.append(l16[j]) 
        return lLane

    def retorna_tv(self,idcross):
        lista=self.le_arquivo15()
        mtlLogicdv=[]
        for i in range(0,len(lista)):
               if idcross==lista[i][0]:
                      j=1
                      mtlLogicdv=[]
                      while len(lista[i])>j:
                             mtlLogicdv.append(lista[i][j])
                             j=j+1
        return mtlLogicdv
 
    def le_arquivo16(self,idcross):
        l14=self.le_arquivo14()
        for i in range(0,len(l14)):
               #print('i=',i,'l[i]=',l[i])
               if l14[i][0]==idcross:
                      return l14[i]
               #       return l[i]
               #else:
               #       return l[i]
              
    #def le_arquivo17(self,nidcross):
           

    def converte_mtv2tlLogicdv(self,mtv):
           tlLogicdv=[]
           for i in range(0,len(mtv)):
                  tlLogicdv.append(int(mtv[i]))
           return tlLogicdv
       
    def converte_tlLogicdv2tlLogicdv(self,mtv,steptv):
           tlLogicdv=[steptv]
           sumtl=sum(mtv)
           sumR=sum(mtv[1:len(mtv)])
           for i in range(1,len(mtv)):
                  tlLogicdv.append(int((sumtl-steptv)*mtv[i]/sumR))
           return tlLogicdv
       

    def le_arquivo20(self):#id cruzamento e tv de cada fase em lista
        lista7=self.le_arquivo7()
        lchave1=[]
        lchave2=[]
        lista18=self.le_arquivo18()
        #for i in range(0,len(lista)-(j+1)):
        #for i in range(0,14):
        #for i in range(0,len(lista18)-1):
        for i in range(0,len(lista18)):
            lchave1=[]
            #print('i=',i,'lista18[i]=',lista18[i])
            for j in range(0,len(lista7)-1):
                #print('j=',j,'lista7[j]=',lista7[j])
                if lista7[j]==lista18[i]:
                    if self.teste_numero(lista7[j][0])==1:
                        lchave1.append(lista7[j])
                        j=j+1
                        while self.teste_numero(lista7[j][0])==0 and j<len(lista7)-1:
                            lchave1.append(lista7[j]);
                            j=j+1
                        #print(lista7[j])
                        lchave2.append(lchave1)
                        #break
            #print(lchave2)
        return lchave2       

    def teste_numero(self,numero):
        if numero=='0' or numero=='1' or numero=='2' or numero=='3' or numero=='4' or numero=='5' or numero=='6' or numero=='7' or numero=='8' or numero=='9':
            return 1
        else:
            return 0
        
        
    def le_arquivo21(self):
        (junction,x,y,ic,it)=self.retorna_junctions()
        l=[]
        ll=[]
        lista18=self.le_arquivo18()
        for i in range(0,len(lista18)):
            for j in range(0,len(junction)):
                if junction[j]==lista18[i]:
                    l=[]
                    l.append(junction[j])
                    l.append(x[j])
                    l.append(y[j])
                    #print(len(ic[i]))
                    icr=self.extrai_lane(ic[j])
                    for k in range(0,len(icr)):
                        l.append(icr[k])
                    ll.append(l)
        return ll
                
                
    def le_arquivo14(self):
        (junction,x,y,ic,it)=self.retorna_junctions()
        l=[]
        ll=[]
        for i in range(0,len(junction)):
            l=[]
            l.append(junction[i])
            l.append(x[i])
            l.append(y[i])
            #print(len(ic[i]))
            icr=self.extrai_lane(ic[i])
            for j in range(0,len(icr)):
                l.append(icr[j])
            ll.append(l)
        return ll                
    
    def le_arquivo22(self,idcross):
        l20=self.le_arquivo20()
        for i in range(0,len(l20)):
            #print('i=',i,'l[i]=',l[i])
            if l20[i][0]==idcross:
                return l20[i]
               #       return l[i]
               #else:
               #       return l[i]
              
    #def le_arquivo17(self,nidcross):
           
    def le_arquivo23(self,):#id cruzamento e tv de cada fase em lista
        lista7=self.le_arquivo7()
        lista18=self.le_arquivo18()
        lchave1=[]
        lchave2=[]
        for i in range(0,len(lista18)):
            for j in range(0,len(lista7)):
               lchave1=[]
               if len(lista18[i])>5 and i<len(lista18)-1:
                      lchave1.append(lista18[i])
                      i=i+1
                      while len(lista18[i])<5 and i<len(lista18)-1:
                             lchave1.append(lista18[i])
                             i=i+1
               if len(lchave1)>0:
                     lchave2.append(lchave1)
        return lchave2
    
    
    def teste_dict(self):
#Lembrete de listas
        #dados=list()
        #dados.append('Pedro')
        #dados.append(25)
        #print(dados[0])#mostra Pedro
        #Tuplas são identificadas por ()
        #Listas são identificadas por []
        #Dicionários são identificados por {}
        #dados=dict()
        #ou dados={'nome':'Pedro','idade':25}
        #print(dados['nome'])=>Pedro
        # No lugar do append  das listas insere-se um campo com:
        #dados['sexo']='M'
        #para retirar um campo:
        #del dados['idade']
        #Ex.:
        #filme={'titulo':'Star Wars',
        #'ano':1977,
        #'diretor':'George Lucas'
        #}
        #print(filme.values())
        #print(filme.keys())
        #print(filme.items())#imprime tanto values quanto keys
        #for k,v in filme.items():
        # print(f 'O {k} é {v}') resulta O título é Star Wars e assim por diante
        #locadora=list()
        #locadora.append(dados)
        filme={'titulo':'Star Wars',
        'ano':1977,
        'diretor':'George Lucas'
        }
        locadora=[]
        locadora.append(filme)
        print(filme.items())
        filme={'titulo':'Avengers',
        'ano':2012,
        'diretor':'Joss Whedon'
        }
        locadora.append(filme)
        filme={'titulo':'Matrix',
        'ano':1999,
        'diretor':'Wachowski',
        'tipo':'Ação',
        'tipo':'Ficção'
        }     
        locadora.append(filme)
        print(locadora)
        t={'titulo':'Star Wars'}
        a={'ano':1977}
        d={'diretor':'George Lucas'}
        t1={'tipo':'Ação'}
        filme=[t,
        a,
        d,
        t1
        ]
        locadora=[]
        locadora.append(filme)
        #print(filme.items()) produz erro pois filme não é mais um dicionário
        t={'titulo':'Avengers'}
        a={'ano':2012}
        d={'diretor':'Joss Whedon'}
        t1={'tipo':'Ação'}
        filme=[t,
        a,
        d,
        t1
        ]
        locadora.append(filme)
        t={'titulo':'Matrix'}
        a={'ano':1999}
        d={'diretor':'Wachowski'}
        t1={'tipo':'Ação'}
        t2={'tipo':'Ficção'}
        filme=[t,
        a,
        d,
        t1,
        t2
        ]     
        locadora.append(filme)
        print(locadora)
        return locadora
    
    def primitivas(self):
        #from pylab import *
        x,y = ogrid[-1:1:.01,-1:1:.01]
        z=6*x**2+6*y**2+cos(16*sqrt(x**2+y**2)+3*arctan2(x,y))
        ext=[-1,1,-1,1]
        imshow(z,origin='lower',extent=ext)
        #contour(x,origin='lower',extent=ext)
        
        xlabel('x')
        ylabel('y')
        title('6*x**2 + 6*y**2 + cos(16*sqrt(x**2 + y**2) + 3*arctan2(x,y))')
        savefig('graf.png')
        
        
    def primitivas1(self,x0,y0):
        #from pylab import *
        import seaborn as sns
        x,y = ogrid[-1:1:.01,-1:1:.01]
        z=matlib.zeros((max(x.shape),max(y.shape)))
        #z=6*x**2+6*y**2+cos(16*sqrt(x**2+y**2)+3*arctan2(x,y))
        #for cx in range(0,len(x)):
        #    for cy in range(0,len(y)):
        for cx in range(0,max(x.shape)):
            for cy in range(0,max(y.shape)):
                #z[cx,cy]=6*math.exp(-(x[cx,0]-x0)**2/(.5**2))*math.exp(-(y[0,cy]-y0)**2/(.5**2))
                z[cy,cx]=6*math.exp(-(x[cx,0]-x0)**2/(.5**2))*math.exp(-(y[0,cy]-y0)**2/(.5**2))
        #z=6*math.exp(-(x-.5)**2/(.1**2))*math.exp(-(y-.5)**2/(.1**2))
        ext=[-1,1,-1,1]
        #ext=[-10,10,-10,10]
        imshow(z,origin='lower',extent=ext)
        #contour(x,origin='lower',extent=ext)
        xx=[x0,x0+.1*x0]
        yy=[y0,y0+.1*y0]
        e=1#=10*math.sqrt((float(xx[1])-float(xx[0]))**2+(float(yy[1])-float(yy[0]))**2)
        angulo=.5#math.atan2((m[ncel,2]*math.sin(m[ncel,4])),m[ncel,2]*math.cos(m[ncel,4]))
        sns.lineplot(x=xx,y=yy,size_norm=e)
        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo+5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo+5*math.pi/6)],size_norm=1)
        sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo-5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo-5*math.pi/6)],size_norm=1)
        
        xlabel('x')
        ylabel('y')
        title('6*x**2 + 6*y**2 + cos(16*sqrt(x**2 + y**2) + 3*arctan2(x,y))')
        savefig('graf.png')
        plt.show()
        return z
        
    def primitivas1b(self,ncelulas):
        #from pylab import *
        import seaborn as sns
        var1=5e2
        var2=5e2
        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
                  #[294.40,276.59,5000,7e1]#,
                  #[404.40,576.59,5000,7e3]#,
             #[442.93,875.61,5000,7e3]#,
             #[446.85,741.11,5000,7e4]])#C3_7x5
#             [1160.1,728.8,2437.9,var1,-2.4],
#             [1076.1,1168.7,3475.7,var1,-1.6],
#             #[1076.1,1168.7,99475.7,var1,-1.6],#alterado
#             [1272.2,897.7,3682.2,var2,-0.3],
#             [1334.3,865.5,2898.9,var2,-1.8],
#             [1479.9,871.7,3910.9,var2,3.1],
#             [3029.3,1221.5,5088.7,var2,-2.8],
#             [1160.8,727.6,3785.4,var2,-2.7],
#             [1235.9,723.9,3150.7,var2,-0.9],
#             [1276.0,645.5,2806.3,var2,-1.8],
#             [1350.5,871.0,4509.9,var2,2.2],
#             [1139.7,694.1,3607.7,var2,0.6],
#             [1554.3,687.2,4038.5,var2,2.9],
#             [1689.9,285.7,4155.9,var1,2.1]
             #
#             [1539.4,499.9,2418.4,500.0,2.2],#raio=1000
#             [3029.3,1221.5,5088.7,500.0,-2.8],
#             [1537.7,498.7,2420.2,500.0,2.2]
             [1388.8,714.1,1641.8,500.0,2.5],#raio=500
             [3029.3,1221.5,5088.7,500.0,-2.8],
             [1385.5,711.7,1651.8,500.,2.6],
             [1689.9,285.7,4155.9,500.0,2.1]
#             [60.1,728.8,2437.9,var1,-2.4],
#             [76.1,168.7,3475.7,var1,-1.6],
             #[1076.1,1168.7,99475.7,var1,-1.6],#alterado
#             [72.2,1897.7,3682.2,var2,-0.3],
#             [2334.3,65.5,2898.9,var2,-1.8],
#             [2479.9,71.7,3910.9,var2,3.1],
#             [2029.3,21.5,5088.7,var2,-2.8],
#             [60.8,27.6,3785.4,var2,-2.7],
#             [35.9,23.9,3150.7,var2,-0.9],
#             [76.0,45.5,2806.3,var2,-1.8],
#             [2350.5,871.0,4509.9,var2,2.2],
#             [2139.7,694.1,3607.7,var2,0.6],
#             [2554.3,687.2,4038.5,var2,2.9],
#             [2689.9,285.7,4155.9,var1,2.1]
             ])
        xmin=float(min(m[:,0]))
        xmax=float(max(m[:,0]))
        ymin=float(min(m[:,1]))
        ymax=float(max(m[:,1]))
        (linhas,colunas)=m.shape
        #x,y = ogrid[-1:1:.01,-1:1:.01]
        x,y = ogrid[xmin:xmax:(xmax-xmin)/ncelulas,ymin:ymax:(ymax-ymin)/ncelulas]
        #x,y = ogrid[xmin-(xmax-xmin)/2:xmax+(xmax-xmin)/2:(xmax-xmin)/ncelulas,ymin-(ymax-ymin)/2:ymax+(ymax-ymin)/2:(ymax-ymin)/ncelulas]
        #y=y[0,0:max(y.shape)-1]
        z=matlib.zeros((max(x.shape),max(y.shape)-1))
        #z=6*x**2+6*y**2+cos(16*sqrt(x**2+y**2)+3*arctan2(x,y))
        #for cx in range(0,len(x)):
        #    for cy in range(0,len(y)):
        hmax=sqrt((xmax-xmin)**2+(ymax-ymin)**2)
        emax=max(m[:,2])
        nlane=0
        v=5e1
        #v=emax#statistics.mean(m[:,2])
        epsilon=1e2
        #for nlane in range(0,1):
        for nlane in range(0,linhas):
            #contour(x,origin='lower',extent=ext)
            h=float(.1*hmax*m[nlane,2]/emax)
            #xx=[m[nlane,0],m[nlane,0]+float(h*math.cos(m[nlane,4]))]
            #yy=[m[nlane,1],m[nlane,1]+float(h*math.sin(m[nlane,4]))]
            e=h#=10*math.sqrt((float(xx[1])-float(xx[0]))**2+(float(yy[1])-float(yy[0]))**2)
            angulo=m[nlane,4]#math.atan2((m[ncel,2]*math.sin(m[ncel,4])),m[ncel,2]*math.cos(m[ncel,4]))
            #print('e=',e,'xx=',xx,'yy=',yy,'angulo=',angulo)            
            for cx in range(0,max(x.shape)-1):
                for cy in range(0,max(y.shape)-1):
                    print('x[cx,0]=',x[cx,0],'m[nlane,0]=',m[nlane,0],'y[0,cy]=',y[0,cy],'m[nlane,1]=',m[nlane,1],'normax=',math.sqrt((x[cx,0]-m[nlane,0])**2),'normay=',math.sqrt((y[0,cy]-m[nlane,1])**2))
                    print('len(x)=',len(x),'len(y)=',len(y),'len(z)=',len(z),'cx=',cx,'cy=',cy)
                    print('max(x.shape)=',max(x.shape),'max(y.shape)=',max(y.shape))
                    #z[cx,cy]=z[cx,cy]+h*math.exp(-(x[cx,0]-m[nlane,0])**2/(v**2))*math.exp(-(y[0,cy]-m[nlane,1])**2/(v**2))
                    z[cy,cx]=z[cy,cx]+h*math.exp(-(x[cx,0]-m[nlane,0])**2/(v**2))*math.exp(-(y[0,cy]-m[nlane,1])**2/(v**2))
                    #z[cx,cy]=z[cx,cy]+h*math.exp(-(x[cx,0]-m[nlane,1])**2/(v**2))*math.exp(-(y[0,cy]-m[nlane,0])**2/(v**2))
                    #z[cx,cy]=z[cx,cy]+h*math.exp(-(x[cx,0]-600)**2/(v**2))*math.exp(-(y[0,cy]-700)**2/(v**2))
                    #z=6*math.exp(-(x-.5)**2/(.1**2))*math.exp(-(y-.5)**2/(.1**2))
                    #ext=[-1,1,-1,1]
                    #if math.sqrt((x[cx,0]-m[nlane,0])**2)<epsilon and math.sqrt((y[0,cy]-m[nlane,1])**2)<epsilon:
#                        ext=[xmin,xmax,ymin,ymax]
#                        #ext=[-10,10,-10,10]
#                        imshow(z,origin='lower',extent=ext)                        
                        #xx=[m[nlane,0],m[nlane,0]+float(h*math.cos(m[nlane,4]))]
                        #yy=[m[nlane,1],m[nlane,1]+float(h*math.sin(m[nlane,4]))]
                        #sns.lineplot(x=xx,y=yy,size_norm=e)
                        #sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo+5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo+5*math.pi/6)],size_norm=1)
                        #sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo-5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo-5*math.pi/6)],size_norm=1)
#
            ext=[xmin,xmax,ymin,ymax]
            #ext=[xmin-(xmax-xmin)/2,xmax+(xmax-xmin)/2,ymin-(ymax-ymin)/2,ymax+(ymax-ymin)/2]
            #ext=[-10,10,-10,10]
            imshow(z,origin='lower',extent=ext)
            xx=[m[nlane,0],m[nlane,0]+float(h*math.cos(m[nlane,4]))]
            yy=[m[nlane,1],m[nlane,1]+float(h*math.sin(m[nlane,4]))]
            sns.lineplot(x=xx,y=yy,size_norm=e)
            sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo+5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo+5*math.pi/6)],size_norm=1)
            sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo-5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo-5*math.pi/6)],size_norm=1)
        
        xlabel('xlon')
        ylabel('ylat')
        #title('6*x**2 + 6*y**2 + cos(16*sqrt(x**2 + y**2) + 3*arctan2(x,y))')
        title('densidade de movimento (energia)')
        savefig('graf.png')
        plt.show()
        return z
    
    def primitivas2(self,ncelulas):#mapa de calor
        #from pylab import *
        import seaborn as sns
        (dados_brutos,m,xmin,xmax,ymin,ymax,ncelulas)=self.extrai_pontos0(ncelulas)
        #x,y = ogrid[-1:1:.01,-1:1:.01]
        x,y = ogrid[xmin:xmax:(xmax-xmin)/ncelulas,ymin:ymax:(ymax-ymin)/ncelulas]
        #z=6*x**2+6*y**2+cos(16*sqrt(x**2+y**2)+3*arctan2(x,y))
        z=dados_brutos
        #ext=[-1,1,-1,1]
        ext=[xmin,xmax,ymin,ymax]
        sns.lineplot(x=[xmin,xmax],y=[ymin,ymax],size_norm=e)
        imshow(z,origin='lower',extent=ext)
        xlabel('xlon')
        ylabel('ylat')
        title('Mapa de calor de densidade de fluxo')
        savefig('graf1.png')        
#        (zmin,zmax)=self.min_dados(dados_brutos)
#        ext=[xmax,xmax+.05*xmax,zmin,zmax]
#        print('zmin=',zmin,'zmax=',zmax)
#        (lz,cz)=z.shape
#        valor=zmin
#        for clz in range(0,lz):
#            valor=valor+(zmax-zmin)/ncelulas
#            z[clz,:]=valor
#        imshow(z,origin='lower',extent=ext)
#        #contour(x,origin='lower',extent=ext)
#        
#        xlabel('')
#        ylabel('')
#        title('')
#        savefig('graf2.png')
        plt.show()
        

    def primitivas2b(self,ncelulas):#barra estreita à direita do mapa de calor
        #from pylab import *
        import seaborn as sns
        (dados_brutos,m,xmin,xmax,ymin,ymax,ncelulas)=self.extrai_pontos0(ncelulas)
        #x,y = ogrid[-1:1:.01,-1:1:.01]
        x,y = ogrid[xmin:xmax:(xmax-xmin)/ncelulas,ymin:ymax:(ymax-ymin)/ncelulas]
        #z=6*x**2+6*y**2+cos(16*sqrt(x**2+y**2)+3*arctan2(x,y))
        z=dados_brutos
        #ext=[-1,1,-1,1]
        ext=[xmin,xmax,ymin,ymax]
        sns.lineplot(x=[xmin,xmax],y=[ymin,ymax],size_norm=e)
        imshow(z,origin='lower',extent=ext)
        xlabel('xlon')
        ylabel('ylat')
        title('Mapa de calor de densidade de fluxo')
        savefig('graf1.png')        
        (zmin,zmax)=self.min_dados(dados_brutos)
        ext=[xmax,xmax+.005*xmax,zmin,zmax]
        print('zmin=',zmin,'zmax=',zmax)
        (lz,cz)=z.shape
        valor=zmin
        for clz in range(0,lz):
            valor=valor+(zmax-zmin)/ncelulas
            z[clz,:]=valor
        imshow(z,origin='lower',extent=ext)
        #contour(x,origin='lower',extent=ext)
        
        xlabel('')
        ylabel('')
        title('')
        savefig('graf2.png')
        plt.show()


        
    def extrai_pontos0(self,ncelulas):
        #m=matrix([[294.40,876.59,5000,7e4],#xlon,ylat,E,var,D
        #          [294.40,276.59,5000,7e3],
        #          [404.40,576.59,5000,7e3],
        #     [442.93,875.61,5000,7e4],
        #     [446.85,741.11,5000,7e4]])#C3_7x5
#        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
#                  #[294.40,276.59,5000,7e1]#,
#                  #[404.40,576.59,5000,7e3]#,
#             #[442.93,875.61,5000,7e3]#,
#             #[446.85,741.11,5000,7e4]])#C3_7x5
#             [880,440,5000,7e2],
#             [440,880,5000,7e2],
#             [440,440,5000,7e3],
#             [880,880,5000,7e2]
#             ])
#        var1=7e1
#        var2=7e3
#        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
#                  #[294.40,276.59,5000,7e1]#,
#                  #[404.40,576.59,5000,7e3]#,
#             #[442.93,875.61,5000,7e3]#,
#             #[446.85,741.11,5000,7e4]])#C3_7x5
#             [880,440,5000,var2],
#             [440,880,5000,var1],
#             [440,440,5000,var1],
#             [880,880,5000,var1]
#             ])
#        var1=7e-1
#        var2=7e-1
#        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
#                   #[294.40,276.59,5000,7e1]#,
#                   #[404.40,576.59,5000,7e3]#,
#              #[442.93,875.61,5000,7e3]#,
#              #[446.85,741.11,5000,7e4]])#C3_7x5
#              [1.1601,0.7288,2.4379,var1,-0.0024],
#              [1.0761,1.1687,3.4757,var1,-0.0016],
#              [1.2722,0.8977,3.6822,var2,-0.0003],
#              [1.3343,0.8655,2.8989,var2,-0.0018],
#              [1.4799,0.8717,3.9109,var2,0.0031],
#              [3.0293,1.2215,5.0887,var2,-0.0028],
#              [1.1608,0.7276,3.7854,var2,-0.0027],
#              [1.2359,0.7239,3.1507,var2,-0.0009],
#              [1.2760,0.6455,2.8063,var2,-0.0018],
#              [1.3505,0.8710,4.5099,var2,0.0022],
#              [1.1397,0.6941,3.6077,var2,0.0006],
#              [1.5543,0.6872,4.0385,var2,0.0029],
#              [1.6899,0.2857,4.1559,var1,0.0021]
#              ])
        var1=1e2
        var2=1e2
        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
                  #[294.40,276.59,5000,7e1]#,
                  #[404.40,576.59,5000,7e3]#,
             #[442.93,875.61,5000,7e3]#,
             #[446.85,741.11,5000,7e4]])#C3_7x5
             [1160.1,728.8,2437.9,var1,-2.4],
             [1076.1,1168.7,3475.7,var1,-1.6],
             #[1076.1,1168.7,99475.7,var1,-1.6],#alterado
             [1272.2,897.7,3682.2,var2,-0.3],
             [1334.3,865.5,2898.9,var2,-1.8],
             [1479.9,871.7,3910.9,var2,3.1],
             [3029.3,1221.5,5088.7,var2,-2.8],
             [1160.8,727.6,3785.4,var2,-2.7],
             [1235.9,723.9,3150.7,var2,-0.9],
             [1276.0,645.5,2806.3,var2,-1.8],
             [1350.5,871.0,4509.9,var2,2.2],
             [1139.7,694.1,3607.7,var2,0.6],
             [1554.3,687.2,4038.5,var2,2.9],
             [1689.9,285.7,4155.9,var1,2.1]
             ])
        #m=matrix([[1555.04,690.13,4699.612806597489,7e3,2.8896096688675086],#0_1
        #          [1555.04,690.13,742.8886410821425,7e3,2.8896096688675086],#1_1
        #          [1555.04,690.13,5271.083729712643,7e3,2.8896096688675086],#2_1
        #          [1555.04,690.13,2725.239656558208,7e3,2.8896096688675086],#3_1
        #          [1555.04,690.13,1044.9348806980345,7e3,2.8896096688675086],#4_1
        #          [1555.04,690.13,5623.1102290741765,7e3,2.8896096688675086],#5_1
        #          [0,0,0,0,0],#6_1
        #          [1555.04,690.13,1766.511028259003,7e3,2.8896096688675086],#7_1
        #          [0,0,0,0,0],#8_1
        #          [1555.04,690.13,4503.995771674371,7e3,2.8896096688675086],#9_1
        #          [0,0,0,0,0],#10_1
        ##          [1555.04,690.13,1241.2930646677798,7e3,2.8896096688675086],#11_1
        #         [0,0,0,0,0],#12_1
        #         [0,0,0,0,0]])#13_1
        xmin=float(min(m[:,0]))
        xmax=float(max(m[:,0]))
        ymin=float(min(m[:,1]))
        ymax=float(max(m[:,1]))
        (linhas,colunas)=m.shape
        #ncelulas=33
        #dados_brutos=matlib.zeros((ncelulas*linhas,ncelulas*linhas))
        dados_brutos=matlib.zeros((ncelulas,ncelulas))
        ncoluna=0
        #lin=ymax*1.1
        lin=ymin*.9
        #for lin in range(ymax*1.1,ymin*.9,-(ymax*1.1-ymin*.9)/ncelulas):
        for clin in range(0,ncelulas):
            lin=lin+(ymax*1.1-ymin*.9)/ncelulas
            #lin=lin+(xmax*1.1-xmin*.9)/ncelulas
            nlinha=0
            col=xmin*.9
            #for col in range(xmin*.9,xmax*1.1,(xmax*1.1-xmin*.9)/ncelulas):
            for ccol in range(0,ncelulas):
                col=col+(xmax*1.1-xmin*.9)/ncelulas
                #col=col+(ymax*1.1-ymin*.9)/ncelulas
                linha=0
                dados_brutos[nlinha,ncoluna]=m[linha,2]*math.exp(-(lin-m[linha,0])**2/m[linha,3]**2)*math.exp(-(col-m[linha,1])**2/m[linha,3]**2)
                #print(dados_brutos[nlinha,ncoluna])
                for linha in range(1,linhas):
                    dados_brutos[nlinha,ncoluna]=dados_brutos[nlinha,ncoluna]+m[linha,2]*math.exp(-(lin-m[linha,0])**2/m[linha,3]**2)*math.exp(-(col-m[linha,1])**2/m[linha,3]**2)
                    #print(dados_brutos[nlinha,ncoluna])
                dados_brutos[nlinha,ncoluna]=dados_brutos[nlinha,ncoluna]/linhas
                nlinha=nlinha+1
            ncoluna=ncoluna+1
        #dfb=pd.DataFrame(data,columns=['x','y','z'])
        #exec('data={\'x\':[\'x1\',\'x1\',\'x1\',\'x2\',\'x2\',\'x2\',\'x3\',\'x3\',\'x3\'],\'y\':[\'y3\',\'y2\',\'y1\',\'y3\',\'y2\',\'y1\',\'y3\',\'y2\',\'y1\'],\'z\':[1,2,3,4,5,6,7,8,9]}')
        #df=dfb.pivot(index='y',columns='x',values='z')
        #self.plota_mapa_de_calor(df)
        return dados_brutos,m,xmin,xmax,ymin,ymax,ncelulas
        
    
    def extrai_pontos0b(self,ncelulas):
        #m=matrix([[294.40,876.59,5000,7e4],#xlon,ylat,E,var,D
        #          [294.40,276.59,5000,7e3],
        #          [404.40,576.59,5000,7e3],
        #     [442.93,875.61,5000,7e4],
        #     [446.85,741.11,5000,7e4]])#C3_7x5
#        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
#                  #[294.40,276.59,5000,7e1]#,
#                  #[404.40,576.59,5000,7e3]#,
#             #[442.93,875.61,5000,7e3]#,
#             #[446.85,741.11,5000,7e4]])#C3_7x5
#             [880,440,5000,7e2],
#             [440,880,5000,7e2],
#             [440,440,5000,7e3],
#             [880,880,5000,7e2]
#             ])
#        var1=7e1
#        var2=7e3
#        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
#                  #[294.40,276.59,5000,7e1]#,
#                  #[404.40,576.59,5000,7e3]#,
#             #[442.93,875.61,5000,7e3]#,
#             #[446.85,741.11,5000,7e4]])#C3_7x5
#             [880,440,5000,var2],
#             [440,880,5000,var1],
#             [440,440,5000,var1],
#             [880,880,5000,var1]
#             ])
#        var1=7e-1
#        var2=7e-1
#        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
#                   #[294.40,276.59,5000,7e1]#,
#                   #[404.40,576.59,5000,7e3]#,
#              #[442.93,875.61,5000,7e3]#,
#              #[446.85,741.11,5000,7e4]])#C3_7x5
#              [1.1601,0.7288,2.4379,var1,-0.0024],
#              [1.0761,1.1687,3.4757,var1,-0.0016],
#              [1.2722,0.8977,3.6822,var2,-0.0003],
#              [1.3343,0.8655,2.8989,var2,-0.0018],
#              [1.4799,0.8717,3.9109,var2,0.0031],
#              [3.0293,1.2215,5.0887,var2,-0.0028],
#              [1.1608,0.7276,3.7854,var2,-0.0027],
#              [1.2359,0.7239,3.1507,var2,-0.0009],
#              [1.2760,0.6455,2.8063,var2,-0.0018],
#              [1.3505,0.8710,4.5099,var2,0.0022],
#              [1.1397,0.6941,3.6077,var2,0.0006],
#              [1.5543,0.6872,4.0385,var2,0.0029],
#              [1.6899,0.2857,4.1559,var1,0.0021]
#              ])
        var1=5e2
        var2=5e2
        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
                  #[294.40,276.59,5000,7e1]#,
                  #[404.40,576.59,5000,7e3]#,
             #[442.93,875.61,5000,7e3]#,
             #[446.85,741.11,5000,7e4]])#C3_7x5
#             [1160.1,728.8,2437.9,var1,-2.4],
#             [1076.1,1168.7,3475.7,var1,-1.6],
             #[1076.1,1168.7,99475.7,var1,-1.6],#alterado
#             [1272.2,897.7,3682.2,var2,-0.3],
#             [1334.3,865.5,2898.9,var2,-1.8],
#             [1479.9,871.7,3910.9,var2,3.1],
#             [3029.3,1221.5,5088.7,var2,-2.8],
#             [1160.8,727.6,3785.4,var2,-2.7],
#             [1235.9,723.9,3150.7,var2,-0.9],
#             [1276.0,645.5,2806.3,var2,-1.8],
#             [1350.5,871.0,4509.9,var2,2.2],
#             [1139.7,694.1,3607.7,var2,0.6],
#             [1554.3,687.2,4038.5,var2,2.9],
#             [1689.9,285.7,4155.9,var1,2.1]
             #
             [60.1,728.8,2437.9,var1,-2.4],
             [76.1,168.7,3475.7,var1,-1.6],
             #[1076.1,1168.7,99475.7,var1,-1.6],#alterado
             [72.2,1897.7,3682.2,var2,-0.3],
             [2334.3,65.5,2898.9,var2,-1.8],
             [2479.9,71.7,3910.9,var2,3.1],
             [2029.3,21.5,5088.7,var2,-2.8],
             [60.8,27.6,3785.4,var2,-2.7],
             [35.9,23.9,3150.7,var2,-0.9],
             [76.0,45.5,2806.3,var2,-1.8],
             [2350.5,871.0,4509.9,var2,2.2],
             [2139.7,694.1,3607.7,var2,0.6],
             [2554.3,687.2,4038.5,var2,2.9],
             [2689.9,285.7,4155.9,var1,2.1]
             ])
        #m=matrix([[1555.04,690.13,4699.612806597489,7e3,2.8896096688675086],#0_1
        #          [1555.04,690.13,742.8886410821425,7e3,2.8896096688675086],#1_1
        #          [1555.04,690.13,5271.083729712643,7e3,2.8896096688675086],#2_1
        #          [1555.04,690.13,2725.239656558208,7e3,2.8896096688675086],#3_1
        #          [1555.04,690.13,1044.9348806980345,7e3,2.8896096688675086],#4_1
        #          [1555.04,690.13,5623.1102290741765,7e3,2.8896096688675086],#5_1
        #          [0,0,0,0,0],#6_1
        #          [1555.04,690.13,1766.511028259003,7e3,2.8896096688675086],#7_1
        #          [0,0,0,0,0],#8_1
        #          [1555.04,690.13,4503.995771674371,7e3,2.8896096688675086],#9_1
        #          [0,0,0,0,0],#10_1
        ##          [1555.04,690.13,1241.2930646677798,7e3,2.8896096688675086],#11_1
        #         [0,0,0,0,0],#12_1
        #         [0,0,0,0,0]])#13_1
#        xmin=float(min(m[:,0]))
#        xmax=float(max(m[:,0]))
#        ymin=float(min(m[:,1]))
#        ymax=float(max(m[:,1]))
#        xmin=float(min(m[:,0])-(max(m[:,0])-min(m[:,0]))/2)
#        xmax=float(max(m[:,0])+(max(m[:,0])-min(m[:,0]))/2)
#        ymin=float(min(m[:,1])-(max(m[:,1])-min(m[:,1]))/2)
#        ymax=float(max(m[:,1])+(max(m[:,1])-min(m[:,1]))/2)
        xmin=float(min(m[:,0])-(max(m[:,0])-min(m[:,0])))
        xmax=float(max(m[:,0])+(max(m[:,0])-min(m[:,0])))
        ymin=float(min(m[:,1])-(max(m[:,1])-min(m[:,1])))
        ymax=float(max(m[:,1])+(max(m[:,1])-min(m[:,1])))
        (linhas,colunas)=m.shape
        #ncelulas=33
        #dados_brutos=matlib.zeros((ncelulas*linhas,ncelulas*linhas))
        #dados_brutos=matlib.zeros((2*ncelulas,2*ncelulas))
        dados_brutos=matlib.zeros((ncelulas,ncelulas))
        for linha in range(0,linhas):
            #ncoluna=0
            nlinha=0
            #lin=ymax*1.1
            lin=ymin*.9
            #for lin in range(ymax*1.1,ymin*.9,-(ymax*1.1-ymin*.9)/ncelulas):
            for clin in range(0,ncelulas):
                lin=lin+(ymax*1.1-ymin*.9)/ncelulas
                #lin=lin+(xmax*1.1-xmin*.9)/ncelulas
                #nlinha=0
                ncoluna=0
                col=xmin*.9
                #for col in range(xmin*.9,xmax*1.1,(xmax*1.1-xmin*.9)/ncelulas):
                for ccol in range(0,ncelulas):
                    col=col+(xmax*1.1-xmin*.9)/ncelulas
                    #col=col+(ymax*1.1-ymin*.9)/ncelulas
                    #linha=0
                    #dados_brutos[nlinha,ncoluna]=m[linha,2]*math.exp(-(lin-m[linha,0])**2/m[linha,3]**2)*math.exp(-(col-m[linha,1])**2/m[linha,3]**2)
                    #print(dados_brutos[nlinha,ncoluna])
                    #print('nlinha=',nlinha,'ncoluna=',ncoluna,'linha=',linha)
                    #dados_brutos[nlinha,ncoluna]=dados_brutos[nlinha,ncoluna]+m[linha,2]*math.exp(-(lin-m[linha,0])**2/m[linha,3]**2)*math.exp(-(col-m[linha,1])**2/m[linha,3]**2)
                    #dados_brutos[nlinha,ncoluna]=max(dados_brutos[nlinha,ncoluna],m[linha,2]*math.exp(-(lin-m[linha,0])**2/m[linha,3]**2)*math.exp(-(col-m[linha,1])**2/m[linha,3]**2))
                    dados_brutos[nlinha,ncoluna]=max(dados_brutos[nlinha,ncoluna],m[linha,2]*math.exp(-(lin-m[linha,1])**2/m[linha,3]**2)*math.exp(-(col-m[linha,0])**2/m[linha,3]**2))
                    #print(dados_brutos[nlinha,ncoluna])
                    #dados_brutos[nlinha,ncoluna]=dados_brutos[nlinha,ncoluna]/linhas
                    ncoluna=ncoluna+1
                nlinha=nlinha+1
            z=dados_brutos
            ext=[xmin,xmax,ymin,ymax]
            #ext=[xmin-(xmax-xmin)/2,xmax+(xmax-xmin)/2,ymin-(ymax-ymin)/2,ymax+(ymax-ymin)/2]
            imshow(z,origin='lower',extent=ext)
            plt.show()
        #dfb=pd.DataFrame(data,columns=['x','y','z'])
        #exec('data={\'x\':[\'x1\',\'x1\',\'x1\',\'x2\',\'x2\',\'x2\',\'x3\',\'x3\',\'x3\'],\'y\':[\'y3\',\'y2\',\'y1\',\'y3\',\'y2\',\'y1\',\'y3\',\'y2\',\'y1\'],\'z\':[1,2,3,4,5,6,7,8,9]}')
        #df=dfb.pivot(index='y',columns='x',values='z')
        #self.plota_mapa_de_calor(df)
        return dados_brutos,m,xmin,xmax,ymin,ymax,ncelulas
    
    def primitivas3(self,ncelulas):
        #from pylab import *
        import seaborn as sns
        #(dados_brutos,m,xmin,xmax,ymin,ymax,ncelulas)=self.extrai_pontos0(ncelulas)
        (dados_brutos,m,xmin,xmax,ymin,ymax,ncelulas)=self.extrai_pontos0b(ncelulas)
        #(dados_brutos,m,xmin,xmax,ymin,ymax,ncelulas)=self.extrai_pontos07(ncelulas)
        #x,y = ogrid[-1:1:.01,-1:1:.01]
        #x,y = ogrid[xmin-(xmax-xmin):xmax+(xmax-xmin):3*(xmax-xmin)/ncelulas,ymin-(ymax-ymin):ymax+(ymax-ymin):3*(ymax-ymin)/ncelulas]
        x,y = ogrid[xmin:xmax:(xmax-xmin)/ncelulas,ymin:ymax:(ymax-ymin)/ncelulas]
        #z=6*x**2+6*y**2+cos(16*sqrt(x**2+y**2)+3*arctan2(x,y))
        z=dados_brutos
        #ext=[-1,1,-1,1]
        #ext=[.9*xmin,1.1*xmax,.9*ymin,1.1*ymax]
        ext=[xmin,xmax,ymin,ymax]
        #ext=[xmin-(xmax-xmin)/2,xmax+(xmax-xmin)/2,ymin-(ymax-ymin)/2,ymax+(ymax-ymin)/2]
        imshow(z,origin='lower',extent=ext)
        #contour(x,origin='lower',extent=ext)
        
        xlabel('')
        ylabel('')
        title('')
        savefig('graf2.png')
        #plt.show()
        ncel=5
        #ext=[xmin,xmax,ymin,ymax]
        ext=[xmin-(xmax-xmin),xmax+(xmax-xmin),ymin-(ymax-ymin),ymax+(ymax-ymin)]
        #xt=[xmin,xmax,ymin,ymax]
        #xx=[(ncelulas-1)*(m[ncel,0]-xmin)/(xmax-xmin)+1,m[ncel,2]*math.cos(m[ncel,4])+(ncelulas-1)*(m[ncel,0]-xmin)/(xmax-xmin)+1]
        #yy=[(ncelulas-1)*(m[ncel,1]-ymin)/(ymax-ymin)+1,m[ncel,2]*math.sin(m[ncel,4])+(ncelulas-1)*(m[ncel,1]-ymin)/(ymax-ymin)+1]
        (lm,cm)=m.shape
        hmax=math.sqrt((xmax-xmin)**2+(ymax-ymin)**2)
        emax=max(m[:,2])
        for ncel in range(0,lm):
            #xx=[m[ncel,0],float(m[ncel,0]+m[ncel,2]/max(m[:,2])*min((xmax-xmin),(ymax-ymin))*math.cos(m[ncel,4]))]
            #yy=[m[ncel,1],float(m[ncel,1]+m[ncel,2]/max(m[:,2])*min((xmax-xmin),(ymax-ymin))*math.sin(m[ncel,4]))]
            #print('xx=',xx,'yy=',yy)
            #e=math.sqrt((m[ncel,2]*math.cos(m[ncel,4])**2+(m[ncel,2]*math.sin(m[ncel,4]))**2))
            #e=math.sqrt((float(xx[1])-float(xx[0]))**2+(float(yy[1])-float(yy[0]))**2)
            h=hmax*m[ncel,2]/emax
            #angulo=math.atan2((m[ncel,2]*math.sin(m[ncel,4])),m[ncel,2]*math.cos(m[ncel,4]))
            angulo=m[ncel,4]
            e=h
            xx=[m[ncel,0],float(m[ncel,0]+h*math.cos(angulo))]
            yy=[m[ncel,1],float(m[ncel,1]+h*math.sin(angulo))]
            sns.lineplot(x=xx,y=yy,size_norm=e)
            #sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo+5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo+5*math.pi/6)],size_norm=1)
            sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo+5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo+5*math.pi/6)],size_norm=.2*e)
            #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo-5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo-5*pi/6)],cor);
            #sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo-5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo-5*math.pi/6)],size_norm=1)
            sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo-5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo-5*math.pi/6)],size_norm=.2*e)
        plt.show()

    def primitivas4(self,ncelulas):
        #from pylab import *
        import seaborn as sns
        #(dados_brutos,m,xmin,xmax,ymin,ymax,ncelulas)=self.extrai_pontos0(ncelulas)
        (dados_brutos,m,xmin,xmax,ymin,ymax,ncelulas)=self.extrai_pontos07(ncelulas)
        #x,y = ogrid[-1:1:.01,-1:1:.01]
        #x,y = ogrid[xmin-(xmax-xmin):xmax+(xmax-xmin):3*(xmax-xmin)/ncelulas,ymin-(ymax-ymin):ymax+(ymax-ymin):3*(ymax-ymin)/ncelulas]
        x,y = ogrid[xmin:xmax:(xmax-xmin)/ncelulas,ymin:ymax:(ymax-ymin)/ncelulas]
        #z=6*x**2+6*y**2+cos(16*sqrt(x**2+y**2)+3*arctan2(x,y))
        dados_brutos=matlib.zeros((ncelulas,ncelulas))
        dados_brutos=m[0,2]*math.exp(-(xmin-m[0,0])**2/m[0,3])*math.exp(-(ymin-m[0,1])**2/m[0,3])
        for clin in range(1,ncelulas-1):
            dados_brutos=dados_brutos+m[clin,2]*math.exp(-(xmin-m[clin,0])**2/m[clin,3])*math.exp(-(ymin-m[clin,1])**2/m[clin,3])
        z=dados_brutos
        #ext=[-1,1,-1,1]
        ncel=5
        #ext=[xmin,xmax,ymin,ymax]
        ext=[xmin-(xmax-xmin),xmax+(xmax-xmin),ymin-(ymax-ymin),ymax+(ymax-ymin)]
        #xt=[xmin,xmax,ymin,ymax]
        #xx=[(ncelulas-1)*(m[ncel,0]-xmin)/(xmax-xmin)+1,m[ncel,2]*math.cos(m[ncel,4])+(ncelulas-1)*(m[ncel,0]-xmin)/(xmax-xmin)+1]
        #yy=[(ncelulas-1)*(m[ncel,1]-ymin)/(ymax-ymin)+1,m[ncel,2]*math.sin(m[ncel,4])+(ncelulas-1)*(m[ncel,1]-ymin)/(ymax-ymin)+1]
        (lm,cm)=m.shape
        for ncel in range(0,lm):
            xx=[m[ncel,0],float(m[ncel,0]+m[ncel,2]/max(m[:,2])*min((xmax-xmin),(ymax-ymin))*math.cos(m[ncel,4]))]
            yy=[m[ncel,1],float(m[ncel,1]+m[ncel,2]/max(m[:,2])*min((xmax-xmin),(ymax-ymin))*math.sin(m[ncel,4]))]
            #print('xx=',xx,'yy=',yy)
            #e=math.sqrt((m[ncel,2]*math.cos(m[ncel,4])**2+(m[ncel,2]*math.sin(m[ncel,4]))**2))
            e=math.sqrt((float(xx[1])-float(xx[0]))**2+(float(yy[1])-float(yy[0]))**2)
            angulo=math.atan2((m[ncel,2]*math.sin(m[ncel,4])),m[ncel,2]*math.cos(m[ncel,4]))
            sns.lineplot(x=xx,y=yy,size_norm=e)
            sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo+5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo+5*math.pi/6)],size_norm=1)
            #plot([xO+e*cos(angulo),xO+e*cos(angulo)+.1*e*cos(angulo-5*pi/6)],[yO+e*sin(angulo),yO+e*sin(angulo)+.1*e*sin(angulo-5*pi/6)],cor);
            sns.lineplot(x=[xx[1],xx[1]+.2*e*math.cos(angulo-5*math.pi/6)],y=[yy[1],yy[1]+.2*e*math.sin(angulo-5*math.pi/6)],size_norm=1)



        #xx=15-xx
        #yy=15-yy
        #xx=[50,10]
        #yy=[20,50]
        #xx=33-[xx[1],xx[0]]
        #xx=[xx[0]+25,xx[1]+25]
        #yy=[yy[1],yy[0]]
        #e=math.sqrt((float(xx[1])-float(xx[0]))**2+(float(yy[1])-float(yy[0]))**2)
        #angulo=math.atan2((m[ncel,2]*math.sin(m[ncel,4])),m[ncel,2]*math.cos(m[ncel,4]))
        #angulo=math.atan2((yy[1]-yy[0]),(xx[1]-xx[0]))
        #e=math.sqrt((yy[1]-yy[0])**2+(xx[1]-xx[0])**2)
        sns.lineplot(x=xx,y=yy,size_norm=e)
        #sns.lineplot(x=[xmin,xmax],y=[ymin,ymax],size_norm=e)
        imshow(z,origin='lower',extent=ext)
        xlabel('xlon')
        ylabel('ylat')
        title('Mapa de calor de densidade de fluxo')
        savefig('graf1.png')        
#        (zmin,zmax)=self.min_dados(dados_brutos)
#        ext=[xmax,xmax+.05*xmax,zmin,zmax]
#        print('zmin=',zmin,'zmax=',zmax)
#        (lz,cz)=z.shape
#        valor=zmin
#        for clz in range(0,lz):
#            valor=valor+(zmax-zmin)/ncelulas
#            z[clz,:]=valor
#        imshow(z,origin='lower',extent=ext)
#        #contour(x,origin='lower',extent=ext)
#        
#        xlabel('')
#        ylabel('')
#        title('')
#        savefig('graf2.png')
        plt.show()


    def extrai_pontos07(self,ncelulas):
        #m=matrix([[294.40,876.59,5000,7e4],#xlon,ylat,E,var,D
        #          [294.40,276.59,5000,7e3],
        #          [404.40,576.59,5000,7e3],
        #     [442.93,875.61,5000,7e4],
        #     [446.85,741.11,5000,7e4]])#C3_7x5
#        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
#                  #[294.40,276.59,5000,7e1]#,
#                  #[404.40,576.59,5000,7e3]#,
#             #[442.93,875.61,5000,7e3]#,
#             #[446.85,741.11,5000,7e4]])#C3_7x5
#             [880,440,5000,7e2],
#             [440,880,5000,7e2],
#             [440,440,5000,7e3],
#             [880,880,5000,7e2]
#             ])
#        var1=7e1
#        var2=7e3
#        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
#                  #[294.40,276.59,5000,7e1]#,
#                  #[404.40,576.59,5000,7e3]#,
#             #[442.93,875.61,5000,7e3]#,
#             #[446.85,741.11,5000,7e4]])#C3_7x5
#             [880,440,5000,var2],
#             [440,880,5000,var1],
#             [440,440,5000,var1],
#             [880,880,5000,var1]
#             ])
#        var1=7e-1
#        var2=7e-1
#        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
#                   #[294.40,276.59,5000,7e1]#,
#                   #[404.40,576.59,5000,7e3]#,
#              #[442.93,875.61,5000,7e3]#,
#              #[446.85,741.11,5000,7e4]])#C3_7x5
#              [1.1601,0.7288,2.4379,var1,-0.0024],
#              [1.0761,1.1687,3.4757,var1,-0.0016],
#              [1.2722,0.8977,3.6822,var2,-0.0003],
#              [1.3343,0.8655,2.8989,var2,-0.0018],
#              [1.4799,0.8717,3.9109,var2,0.0031],
#              [3.0293,1.2215,5.0887,var2,-0.0028],
#              [1.1608,0.7276,3.7854,var2,-0.0027],
#              [1.2359,0.7239,3.1507,var2,-0.0009],
#              [1.2760,0.6455,2.8063,var2,-0.0018],
#              [1.3505,0.8710,4.5099,var2,0.0022],
#              [1.1397,0.6941,3.6077,var2,0.0006],
#              [1.5543,0.6872,4.0385,var2,0.0029],
#              [1.6899,0.2857,4.1559,var1,0.0021]
#              ])
        var1=1e4
        var2=1e4
        m=matrix([#[294.40,876.59,5000,7e1]#,#xlon,ylat,E,var,D
                  #[294.40,276.59,5000,7e1]#,
                  #[404.40,576.59,5000,7e3]#,
             #[442.93,875.61,5000,7e3]#,
             #[446.85,741.11,5000,7e4]])#C3_7x5
             [1160.1,728.8,2437.9,var1,-2.4],
             [1076.1,1168.7,3475.7,var1,-1.6],
             [1272.2,897.7,3682.2,var2,-0.3],
             [1334.3,865.5,2898.9,var2,-1.8],
             [1479.9,871.7,3910.9,var2,3.1],
             [3029.3,1221.5,5088.7,var2,-2.8],
             [1160.8,727.6,3785.4,var2,-2.7],
             [1235.9,723.9,3150.7,var2,-0.9],
             [1276.0,645.5,2806.3,var2,-1.8],
             [1350.5,871.0,4509.9,var2,2.2],
             [1139.7,694.1,3607.7,var2,0.6],
             [1554.3,687.2,4038.5,var2,2.9],
             [1689.9,285.7,4155.9,var1,2.1]
             ])
        #m=matrix([[1555.04,690.13,4699.612806597489,7e3,2.8896096688675086],#0_1
        #          [1555.04,690.13,742.8886410821425,7e3,2.8896096688675086],#1_1
        #          [1555.04,690.13,5271.083729712643,7e3,2.8896096688675086],#2_1
        #          [1555.04,690.13,2725.239656558208,7e3,2.8896096688675086],#3_1
        #          [1555.04,690.13,1044.9348806980345,7e3,2.8896096688675086],#4_1
        #          [1555.04,690.13,5623.1102290741765,7e3,2.8896096688675086],#5_1
        #          [0,0,0,0,0],#6_1
        #          [1555.04,690.13,1766.511028259003,7e3,2.8896096688675086],#7_1
        #          [0,0,0,0,0],#8_1
        #          [1555.04,690.13,4503.995771674371,7e3,2.8896096688675086],#9_1
        #          [0,0,0,0,0],#10_1
        ##          [1555.04,690.13,1241.2930646677798,7e3,2.8896096688675086],#11_1
        #         [0,0,0,0,0],#12_1
        #         [0,0,0,0,0]])#13_1
        xmin=float(min(m[:,0]))
        xmax=float(max(m[:,0]))
        ymin=float(min(m[:,1]))
        ymax=float(max(m[:,1]))
        (linhas,colunas)=m.shape
        #ncelulas=33
        #dados_brutos=matlib.zeros((ncelulas*linhas,ncelulas*linhas))
#        dados_brutos=matlib.zeros((ncelulas,ncelulas))
#        ncoluna=0
#        #lin=ymax*1.1
#        lin=ymin*.9
#        #for lin in range(ymax*1.1,ymin*.9,-(ymax*1.1-ymin*.9)/ncelulas):
#        for clin in range(0,ncelulas):
#            lin=lin+(ymax*1.1-ymin*.9)/ncelulas
#            nlinha=0
#            col=xmin*.9
#            #for col in range(xmin*.9,xmax*1.1,(xmax*1.1-xmin*.9)/ncelulas):
#            for ccol in range(0,ncelulas):
#                col=col+(xmax*1.1-xmin*.9)/ncelulas
#                linha=0
#                dados_brutos[nlinha,ncoluna]=m[linha,2]*math.exp(-(lin-m[linha,0])**2/m[linha,3])*math.exp(-(col-m[linha,1])**2/m[linha,3])
#                #print(dados_brutos[nlinha,ncoluna])
#                for linha in range(1,linhas):
#                    dados_brutos[nlinha,ncoluna]=dados_brutos[nlinha,ncoluna]+m[linha,2]*math.exp(-(lin-m[linha,0])**2/m[linha,3])*math.exp(-(col-m[linha,1])**2/m[linha,3])
#                    #print(dados_brutos[nlinha,ncoluna])
#                dados_brutos[nlinha,ncoluna]=dados_brutos[nlinha,ncoluna]/linhas
#                nlinha=nlinha+1
#            ncoluna=ncoluna+1
        dados_brutos=m[0,2]*math.exp(-(xmin-m[0,0])**2/m[0,3])*math.exp(-(ymin-m[0,1])**2/m[0,3])
        for clin in range(1,3):
            dados_brutos=dados_brutos+m[clin,2]*math.exp(-(xmin-m[clin,0])**2/m[clin,3])*math.exp(-(ymin-m[clin,1])**2/m[clin,3])
        #dfb=pd.DataFrame(data,columns=['x','y','z'])
        #exec('data={\'x\':[\'x1\',\'x1\',\'x1\',\'x2\',\'x2\',\'x2\',\'x3\',\'x3\',\'x3\'],\'y\':[\'y3\',\'y2\',\'y1\',\'y3\',\'y2\',\'y1\',\'y3\',\'y2\',\'y1\'],\'z\':[1,2,3,4,5,6,7,8,9]}')
        #df=dfb.pivot(index='y',columns='x',values='z')
        #self.plota_mapa_de_calor(df)
        return dados_brutos,m,xmin,xmax,ymin,ymax,ncelulas
        

        
    def min_dados(self,dados_brutos):
        (nl,nc)=dados_brutos.shape
        mindb=dados_brutos[0,0]
        maxdb=dados_brutos[0,0]
        for cnl in range(0,nl):
            for cnc in range(0,nc):
                if dados_brutos[cnl,cnc]<mindb:
                    mindb=dados_brutos[cnl,cnc]
                if dados_brutos[cnl,cnc]>maxdb:
                    maxdb=dados_brutos[cnl,cnc]
        return mindb,maxdb
#    def mapas(self):
#        #from mpl_toolkits.basemap import Basemap
#        #from matplotlib import pyplot
#        #from numpy import arange
#        mapa = Basemap(projection='ortho', lat_0=-20, lon_0=-50,
#        resolution='l', area_thresh=1e3)
#        mapa.bluemarble()
#        mapa.drawcoastlines(color='#777799')
#        mapa.drawcountries(color='#ccccee')
#        mapa.drawmapboundary()
#        mapa.drawmeridians(arange(0,360,30), color='#ccccee')
#        mapa.drawparallels(arange(-90,90,30), color='#ccccee')
#        x,y = mapa([-43.1],[-22.6])
#        mapa.plot(x, y,'w^')
#        pyplot.text(x[0]+2e5, y[0]-6e5, 'Rio\nde\nJaneiro',
#        color='#eeeecc')
#        pyplot.savefig('mapa.png')
        
    def max_lanes(self):
        l18=self.le_arquivo18()
        conta_lanes=0
        for cncross in range(0,len(l18)):
            l16=self.le_arquivo16(l18[cncross])
            if conta_lanes<len(l16)-3:
                conta_lanes=len(l16)-3
        return conta_lanes
