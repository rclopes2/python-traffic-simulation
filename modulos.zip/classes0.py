#class Meu_Objeto:
#class Meu_Objeto():
#cloass Meu_Objeto(object):
class Meu_Objeto:
	def __init__(self):
		self.nome='Pedro'
		self.idade=45
		print('Construtor chamado com sucesso')
	def imprime(self):
		print('Olá meu nome é %s e eu tenho %d'%(self.nome,self.idade))
#edro=Meu_Objeto()
#Pedro.imprime()		