class matriz0:
	def __init__(self):
		self.linha0=0
		self.coluna0=0
		#print('Construtor chamado com sucesso')
	def retorna_matriz(self,linha,coluna):
		contador=0
		manipulador=open('regressores.txt','r')
		for linha in manipulador:
			linha=linha.rstrip()
			#print(linha)
			contador+=1
			if contador==posicao:
				break
		manipulador.close()
		return linha
    def tf2ssR(self,R01a):
        #,R01b,ns,ni,no,madj):
        A=R01a#;B=1;C=1;D=1;
        return A#,B,C,D                

        #A=zeros(ns,ns);
        #for(i=1:ns):
        #    A(i,i)=-R01b;
        #B=zeros(ns,ni);
        #LB=1;
        #CB=1;
        #[Lmadj,Cmadj]=size(madj);
        #for(cCmadj=1:Cmadj):
        #    for(cLmadj=1:Lmadj):
        #        if(madj(cLmadj,cCmadj)==1):
        #            B(LB,CB)=R01a;
        #            LB=LB+1;
        #    CB=CB+1;
        #C=zeros(no,ns);
        #CC=1;
        #for(cCmadj=1:Cmadj):
        #    for(cLmadj=1:Lmadj):
        #        if(madj(cLmadj,cCmadj)==1):
        #            C(cLmadj,CC)=1;
        #            CC=CC+1;
        #D=zeros(no,ni);        
        #A=R01a#;B=1;C=1;D=1;
        #return A#,B,C,D        