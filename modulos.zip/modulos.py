#from numpy import matrix
#from numpy import matlib
#from numpy import math
class arquivo1:
	def __init__(self):
		self.posicao0='Pedro'
		self.regressor0=45
		print('Construtor chamado com sucesso')
	def retorna_regressor(self,posicao):
        #manipulador=open('regressores.txt','r')
		#for linha in range(1,posicao+1):
        for linha in manipulador:
            linha.rstrip()
			print(linha)
            #print(linha.rstrip())
		manipulador.close()
        #return 0
	def retorna_referencia(self,narq):
        manipulador=open(narq,'r')
		#for linha in range(1,posicao+1):
        for linha in manipulador:
            linha.rstrip()
			print(linha)
            #print(linha.rstrip())
		manipulador.close()        