from numpy import matrix
from numpy import matlib
from numpy import math
import numpy as np
import matplotlib.pyplot as plt
#from modulos0 import arquivo
#from modulos.modulos1 import arquivo2
font = {'family': 'serif',
        'color':  'darkred',
        'weight': 'normal',
        'size': 16,
        }
#aa1b=arquivo()
#aa2=arquivo2()
class arquivo2:
    def __init__(self):
        self.posicao0='Pedro'
        self.regressor0=45
        #print('Construtor chamado com sucesso')
        #def zeros(self,n_linhas, n_colunas):
        #madj=matrix([[0,0,0],[0,0,0],[0,0,0]])        #print(matriz(5,4))    
        #for linha in range(1,2):
        #    for coluna in range(1,2):
        #madj[[linha][coluna]]=1
        #madj[[1],[1]]=1
        #matriz = [] # Matriz
        #linha = [] # Linha

        #while len(matriz) != n_linhas: # Quando o número de elementos da matriz(linhas) forem diferentes da quantidade máxima definida pelo usuário, ele ficará rodando.
        #    n = 0 # Utilizei random para adicionar os valores
        #    linha.append(n) # Adiciono n à linha

        #    if len(linha) == n_colunas: # Se a quantidade de elementos for igual à quantidade de colunas definida pelo usuário :
        #        matriz.append(linha) # Adiciono a linha à matriz
        #        linha = [] # E zero a "linha" para adicionar outra à matriz
        #return madj # Retorno a mesma
 
    def teste_dict(self):
#Lembrete de listas
        #dados=list()
        #dados.append('Pedro')
        #dados.append(25)
        #print(dados[0])#mostra Pedro
        #Tuplas são identificadas por ()
        #Listas são identificadas por []
        #Dicionários são identificados por {}
        #dados=dict()
        #ou dados={'nome':'Pedro','idade':25}
        #print(dados['nome'])=>Pedro
        # No lugar do append  das listas insere-se um campo com:
        #dados['sexo']='M'
        #para retirar um campo:
        #del dados['idade']
        #Ex.:
        #filme={'titulo':'Star Wars',
        #'ano':1977,
        #'diretor':'George Lucas'
        #}
        #print(filme.values())
        #print(filme.keys())
        #print(filme.items())#imprime tanto values quanto keys
        #for k,v in filme.items():
        # print(f 'O {k} é {v}') resulta O título é Star Wars e assim por diante
        #locadora=list()
        #locadora.append(dados)
        filme={'titulo':'Star Wars',
        'ano':1977,
        'diretor':'George Lucas'
        }
        locadora=[]
        locadora.append(filme)
        print(filme.items())
        filme={'titulo':'Avengers',
        'ano':2012,
        'diretor':'Joss Whedon'
        }
        locadora.append(filme)
        filme={'titulo':'Matrix',
        'ano':1999,
        'diretor':'Wachowski',
        'tipo':'Ação',
        'tipo':'Ficção'
        }     
        locadora.append(filme)
        print(locadora)
        t={'titulo':'Star Wars'}
        a={'ano':1977}
        d={'diretor':'George Lucas'}
        t1={'tipo':'Ação'}
        filme=[t,
        a,
        d,
        t1
        ]
        locadora=[]
        locadora.append(filme)
        #print(filme.items()) produz erro pois filme não é mais um dicionário
        t={'titulo':'Avengers'}
        a={'ano':2012}
        d={'diretor':'Joss Whedon'}
        t1={'tipo':'Ação'}
        filme=[t,
        a,
        d,
        t1
        ]
        locadora.append(filme)
        t={'titulo':'Matrix'}
        a={'ano':1999}
        d={'diretor':'Wachowski'}
        t1={'tipo':'Ação'}
        t2={'tipo':'Ficção'}
        filme=[t,
        a,
        d,
        t1,
        t2
        ]     
        locadora.append(filme)
        print(locadora)
        return locadora
    def retorna_fase(self, chave,nfase):
            lista=self.le_arquivo17()
            for i in range(0,len(lista)):
                if len(lista[i])>1:
                    return lista[i][nfase]
                     
    def le_arquivo17(self):#id cruzamento e tv de cada fase em lista
        lista=self.le_arquivo7()
        lchave1=[]
        lchave2=[]
        for i in range(0,len(lista)-1):
               lchave1=[]
               if len(lista[i])>9 and i<len(lista):
                      lchave1.append(lista[i])
                      i=i+1
                      while len(lista[i])<5 and i<len(lista)-1:
                             lchave1.append(lista[i])
                             i=i+1
               if len(lchave1)>0:
                     lchave2.append(lchave1)
        return lchave2       
            
    def le_arquivo18(self):#lista valida
        l15=self.le_arquivo15()
        l14=self.le_arquivo14()
        lv=[]
        for i in range(0,len(l15)):
            for j in range(0,len(l14)):
               #print('i=',i,'l[i]=',l[i])
               if l15[i][0]==l14[j][0]:
                   lv.append(l15[i][0])
        return lv

    def le_arquivo19(self):#lista valida
        lv=self.le_arquivo18()
        lLane=[]
        for i in range(0,len(lv)):
            l16=self.le_arquivo16(lv[0])
            for j in range(3,len(l16)):
                   lLane.append(l16[j]) 
        return lLane

    def retorna_tv(self,idcross):
        lista=self.le_arquivo15()
        mtlLogicdv=[]
        for i in range(0,len(lista)):
               if idcross==lista[i][0]:
                      j=1
                      mtlLogicdv=[]
                      while len(lista[i])>j:
                             mtlLogicdv.append(lista[i][j])
                             j=j+1
        return mtlLogicdv
 
    def le_arquivo16(self,idcross):
        l=self.le_arquivo14()
        for i in range(0,len(l)):
               #print('i=',i,'l[i]=',l[i])
               if l[i][0]==idcross:
                      return l[i]
               #       return l[i]
               #else:
               #       return l[i]
              
    #def le_arquivo17(self,nidcross):
           

    def converte_mtv2tlLogicdv(self,mtv):
           tlLogicdv=[]
           for i in range(0,len(mtv)):
                  tlLogicdv.append(int(mtv[i]))
           return tlLogicdv